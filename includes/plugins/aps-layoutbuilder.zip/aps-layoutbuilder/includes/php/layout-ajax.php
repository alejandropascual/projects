<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }


// UTILES
//Convierte un string en html de imagenes para componer el layout
//Ejemplo compose
//image-1,header-2,slider-0,content-2,footer-1,socket-1
function aps_dame_layout($compose)
{
	//echo '<h1>COMPONIENDO: '.$compose.'</h1>';
	$items = preg_split('/,/', $compose);
	$html = '';
	$http = APS_LAYOUTS_DIR_URI.'includes/images/';
	foreach($items as $item)
	{
		//No es vacio -0
		if (!strpos($item, '-0') && $item!='')
			$html .= '<img src='.$http.'layout-'.$item.'.jpg>';
	}
	return $html;
}

add_action('wp_ajax_aps_dame_layout','aps_dame_layout_ajax');

function aps_dame_layout_ajax()
{
	$compose = $_REQUEST['compose'];
	echo aps_dame_layout($compose);

	die();
}



add_filter('aps_layout', 'aps_get_default_layout', 10, 1);

/*

Las opciones default son:

post
blog
blog archive
pages

project
project list
project taxonomy

 */


function aps_get_default_layout( $layout )
{
    if (preg_match('/^layout_default_(.+)/',$layout,$matches))
    {
        if (function_exists('aps_get_option')) {
            return aps_get_option( $layout );
        } else {
            echo '<div style="color:red;">Activate theme to define default layouts</div>';
            //return null;
        }

    }
    else if  (preg_match('/default-(.+)/',$layout,$matches))
    {
        $name = 'layout_default_'.$matches[1];
        if (function_exists('aps_get_option')) {
            return aps_get_option($name);
        } else {
            echo '<div style="color:red;">Activate theme to define default layouts</div>';;
            $layout = $name;
            //return null;
        }

    }
    return $layout;

}




add_action('wp_ajax_aps_dame_layout_from_id', 'aps_dame_layout_ajax_from_id');

function aps_dame_layout_ajax_from_id()
{
    $layout_id = apply_filters('aps_layout', $_REQUEST['id']);

    if ($layout_id==false){
        echo '<p>No default layout created yet. Create a new <a href="'.admin_url().'post-new.php?post_type=aps_layout">layout now</a></p>';
        die();
    }

    echo aps_html_layout_with_link_for_id($layout_id);
    die();
}


add_action('wp_ajax_aps_dame_layout_y_responsive_from_id', 'aps_dame_layout_y_responsive_ajax_from_id');

function aps_dame_layout_y_responsive_ajax_from_id()
{
    $layout_id = apply_filters('aps_layout', $_REQUEST['id']);

    if ($layout_id==false){
        echo '<p>No default layout created yet. Create a new <a href="'.admin_url().'post-new.php?post_type=aps_layout">layout now</a></p>';
        die();
    }

    echo aps_html_layout_with_link_for_id($layout_id);
    echo '<small>Boxed / Full-width style:</small>';
    echo aps_html_imagen_layout_responsive($layout_id);
    die();
}


