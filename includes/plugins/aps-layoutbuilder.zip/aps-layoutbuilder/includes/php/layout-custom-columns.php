<?php


// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }


// CUSTOM COLUMNS

//aps_layout custom post
add_filter('manage_aps_layout_posts_columns', 'aps_add_aps_layout_columns');
add_filter('manage_aps_layout_posts_custom_column', 'aps_show_aps_layout_column',100,3);

//Pages
add_filter('manage_pages_columns', 'aps_add_pages_layout_columns');
add_filter('manage_pages_custom_column', 'aps_show_pages_layout_column',100,3);

//Posts
add_filter('manage_post_posts_columns', 'aps_add_pages_layout_columns');
add_filter('manage_post_posts_custom_column', 'aps_show_pages_layout_column',100,3);

//aps_project custom post
add_filter('manage_aps_project_posts_columns', 'aps_add_pages_layout_columns');
add_filter('manage_aps_project_posts_custom_column', 'aps_show_pages_layout_column',100,3);


function aps_add_pages_layout_columns( $columns )
{
    $columns['layout'] = __('Layout page',APS_LB_LANG);
    $columns['boxed'] = __('Boxed/Full',APS_LB_LANG);
    $date = $columns['date'];
    unset($columns['date']);
    $columns['date'] = $date;
    return $columns;
}

function aps_show_pages_layout_column( $column, $post_id)
{
    if ($column == 'layout' || $column == 'boxed')
    {
        $layout_id = get_post_meta($post_id,'layout_id',true);

        //echo '<h2>'.$layout_id.'</h2>';


        if ($layout_id == null) {

            echo '<small>Not defined yet.<br>Default layout will be used</small>';

        } else {

            //Puede ser id-56 o puede ser id-default-post etc

            //Obtengo el verdadero id
            $real_layout_id = apply_filters('aps_layout', $layout_id);

            //Si es un default no lo dibujo, solo pongo el link
            if (preg_match('/default-(.+)/',$layout_id))
            {
                $link_edit = admin_url().'post.php?post='.$real_layout_id.'&action=edit';
                $title = get_post_field('post_title',$real_layout_id);
                echo '<small><a href="'.$link_edit.'">[ Default layout ]</small><br>'.$title.' (ID '.$real_layout_id.')</a>';
                return;
            }

            //Dibujo el layout
            $title = get_post_field('post_title',$real_layout_id);
            $link_edit = admin_url().'post.php?post='.$real_layout_id.'&action=edit';

            if ($column == 'layout') {
                echo '<a href="'.$link_edit.'">'.$title.' (ID '.$real_layout_id.')</a>';
                echo '<div style="max-width:100px">'.aps_html_layout_with_link_for_id($real_layout_id).'</div>';
            } else if ($column == 'boxed') {
                echo '<div style="max-width:110px">'.aps_html_imagen_layout_responsive($real_layout_id).'</div>';
            }


        }
    }
}


function aps_add_aps_layout_columns( $columns )
{
	$columns['layout'] = __('LAYOUT',APS_LB_LANG);
    $columns['boxed'] = __('Boxed / Full-width',APS_LB_LANG);
	$date = $columns['date'];
	unset($columns['date']);
	$columns['date'] = $date;
	return $columns;
}

function aps_show_aps_layout_column( $column, $post_id)
{
	if ($column == 'layout')
	{
		echo aps_html_layout_with_link_for_id($post_id);
	}
    else if ($column == 'boxed')
    {
        echo '<div style="max-width:200px">'.aps_html_imagen_layout_responsive($post_id).'</div>';
    }
}

function aps_html_layout_for_id($post_id)
{
	$compose = 	aps_dame_layout_compose_for_post($post_id);
	$html = '<div class="aps-layout-custom-column">';
	$html .= aps_dame_layout($compose);
	$html .= '</div>';
	return $html;
}


function aps_html_layout_with_link_for_id($post_id)
{
	$link_edit = admin_url().'post.php?post='.$post_id.'&action=edit';
	$html = '<a href="'.$link_edit.'">';
	$html .= aps_html_layout_for_id($post_id);
	$html .= '</a>';
	return $html;
}

function aps_dame_layout_compose_for_post($post_id)
{
	$compose = array();
	$compose[] = get_post_meta($post_id,'layout_slider1',true);
	$compose[] = get_post_meta($post_id,'layout_header',true);
	$compose[] = get_post_meta($post_id,'layout_slider2',true);
	//$compose[] = get_post_meta($post_id,'layout_title',true);
	$compose[] = get_post_meta($post_id,'layout_content',true);
	$compose[] = get_post_meta($post_id,'layout_footer',true);
	$compose[] = get_post_meta($post_id,'layout_socket',true);
	return implode(',', $compose);
}

function aps_html_imagen_layout_responsive($post_id)
{
    $responsive = get_post_meta($post_id,'layout_responsive',true);
    $image_src = '';

    switch ($responsive) {
        case 'boxed display-extend-no':
            $image_src = APS_LAYOUTS_DIR_URI.'includes/images/layout-boxed.png';
            break;
        case 'boxed display-extend-yes':
            $image_src = APS_LAYOUTS_DIR_URI.'includes/images/layout-boxed-extend.png';
            break;
        case 'fullwidth-1260 display-extend-no':
            $image_src = APS_LAYOUTS_DIR_URI.'includes/images/layout-max.png';
            break;
        case 'fullwidth-1260 display-extend-yes':
            $image_src = APS_LAYOUTS_DIR_URI.'includes/images/layout-max-extend.png';
            break;
        case 'fullwidth':
            $image_src = APS_LAYOUTS_DIR_URI.'includes/images/layout-fullwidth.png';
            break;
        default:
            $image_src = '';
            break;
    }
    return '<div class="aps-layout-custom-column"><img src="'.$image_src.'"></div>';

}

//http://stackoverflow.com/questions/3559935/wordpress-is-there-a-way-to-adjust-the-column-width-for-the-post-table

