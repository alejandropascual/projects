<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

add_action('delete_post', 'aps_layout_delete');

function aps_layout_delete($post_id)
{
    $post_type = get_post_type($post_id);

    if ($post_type=='aps_layout'){
        //echo '<h1>Borrando '.$post_id.'</h1>';

        global $wpdb;
        //Actualizo los post, pages y aps_project que tengan este layout

        //PENDIENTE

    }
}