<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

// UTIL ratios proporcion para imagen
if ( !function_exists('aps_get_image_ratio_array')):
    function aps_get_image_ratio_array($min=1,$max=20)
    {
        $list = array();
        for($i=$min;$i<=$max;$i++)
        {
            $list['ratio-'.$i] = '1/'.$i;
        }
        return $list;
    }
endif;

//UTIL listado nav menus
if ( !function_exists('aps_get_list_menus')):
    function aps_get_list_menus()
    {
        $menus = get_terms( 'nav_menu', array( 'hide_empty' => false ) );

        $options = array();
        foreach($menus as $menu){
            //echo '<pre>'; print_r($menu); echo '</pre>';
            $options['menu-'.$menu->term_id] = 'MENU: '.$menu->name;
        }
        return $options;
    }
endif;


//UTIL listado custom post types
if ( !function_exists('aps_get_list_custom_post_types')):
    function aps_get_list_custom_post_types()
    {
        $listado = get_post_types('','names');
        //echo '<pre>'; print_r($listado); echo '</pre>';
        return $listado;
    }
endif;
//echo '<pre>'; print_r(aps_get_list_custom_post_types()); echo '</pre>';



//Listado de opciones para el header
$array_options_header = array(
    'logo'					=> __('LOGO',APS_LB_LANG),
    'site_title' 		    => __('Site title',APS_LB_LANG),
    'site_tagline'	        => __('Site Tagline',APS_LB_LANG),
    'site_title_tagline'	=> __('Site Title + Tagline',APS_LB_LANG),
    'contact'				=> __('Contact data',APS_LB_LANG),
    'social' 				=> __('Social icons',APS_LB_LANG),
    'copyright' 		    => __('Copyright',APS_LB_LANG),
    'search'				=> __('Search Bar',APS_LB_LANG),
    ''		  				=> __('None',APS_LB_LANG)
);
$array_options_header = array_merge(aps_get_list_menus(),$array_options_header);

//echo '<pre>'; print_r(aps_get_list_menus()); echo '</pre>';




// Configuracion metaboxes para el layout

//global $aps_config;

$boxes = array(
    array(
        'id' 		=> 'box_layout_final',
        'title' 	=> __('LAYOUT', APS_LB_LANG),
        'page' 		=> array('aps_layout'),
        'context' 	=> 'normal',
        'priority'	=> 'high'
    ),
    array(
        'id' 		=> 'box_layout_options',
        'title' 	=> __('LAYOUT options',APS_LB_LANG),
        'page' 		=> array('aps_layout'),
        'context' 	=> 'normal',
        'priority'	=> 'high'
    ),


    //Seleccionar layout en pages y posts
    array(
        'id' 		=> 'box_layout_page',
        'title' 	=> __('PAGE LAYOUT',APS_LB_LANG),
        'page' 		=> array('post','page','aps_project'),
        'context' 	=> 'side',
        'priority'	=> 'high'
    ),


);

//$aps_config['metabox_fields'] =
$fields = array(



    //LAYOUTS
    array(
        'box_id'	=> 'box_layout_final',
        'id'		=> 'layout_layout',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'type' 		=> 'layout',
        'layouts'	=> array(
            'layout_slider1',
            'layout_header',
            'layout_slider2',
            //'layout_title',
            'layout_content',
            'layout_footer',
            'layout_socket'),
        //Por defecto al principio
        'value'		=> 'image-1,header-1,slider-1,content-1,footer-1,socket-1',
        'comments' => __('This layout can be applied to pages, posts, etc.', APS_LB_LANG).'</br>'.__('You define here:', APS_LB_LANG).'<ul ><li>- '.__('The components of the layout',APS_LB_LANG).'<li>- '.__('The content of each component (image, header, slider, widgets areas and socket)',APS_LB_LANG).'<li>- '.__('The main content is defined in the page or post to which this layout is applied',APS_LB_LANG).'</ul>'.'In'.' <a href="'.admin_url().'admin.php?page=aps_op_general">'.__('Theme options',APS_LB_LANG).'</a> '.__('you can define which layout can be the default one to be applied for each page.',APS_LB_LANG)
    ),
    //La imagen encima del menu (image or slider)
    array(
        'box_id'	=> 'box_layout_final',
        'id'		=> 'layout_slider1',
        'title'		=> __('Image/Slider/Shortcode', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'type' 		=> 'radio_image',
        'value'		=> 'image-1',
        'options'	=>  array(
            ''	=> '',
            'image-1' 	=> '',
            'slider-1'	=> ''
        ),
        'images'	=> array(
            APS_LAYOUTS_DIR_URI.'includes/images/layout-image-0.jpg',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-image-1.jpg',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-slider-1.jpg'
        ),
        'class'		=> 'aps-layout no_border image_border_white small_image'
    ),
    array(
        'box_id'	=> 'box_layout_final',
        'id'		=> 'layout_header',
        'title'		=> __('Header', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'type' 		=> 'radio_image',
        'value'		=> 'header-1',
        'options'	=>  array(
            ''	=> '',
            'header-1'	=> '',
            'header-2' 	=> '',
            'header-3' 	=> '',
            'header-4'	=> ''
        ),
        'images'	=> array(
            APS_LAYOUTS_DIR_URI.'includes/images/layout-header-0.jpg',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-header-1.jpg',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-header-2.jpg',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-header-3.jpg',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-header-4.jpg'
        ),
        'class'		=> 'aps-layout no_border image_border_white small_image'
    ),
    //El slider debajo del menu (image or slider)
    array(
        'box_id'	=> 'box_layout_final',
        'id'		=> 'layout_slider2',
        'title'		=> __('Image/Slider/Shortcode', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'type' 		=> 'radio_image',
        'value'		=> 'slider-1',
        'options'	=>  array(
            ''	=> '',
            'image-1' => '',
            'slider-1' 	=> ''
        ),
        'images'	=> array(
            APS_LAYOUTS_DIR_URI.'includes/images/layout-image-0.jpg',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-image-1.jpg',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-slider-1.jpg'
        ),
        'class'		=> 'aps-layout no_border image_border_white small_image'
    ),
    array(
        'box_id'	=> 'box_layout_final',
        'id'		=> 'layout_content',
        'title'		=> __('Content', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'type' 		=> 'radio_image',
        'value'		=> 'content-1',
        'options'	=>  array(
            'content-1'		=> '',
            'content-2' 	=> '',
            'content-3' 	=> '',
            'content-4' 	=> ''
        ),
        'images'	=> array(
            APS_LAYOUTS_DIR_URI.'includes/images/layout-content-1.jpg',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-content-2.jpg',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-content-3.jpg',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-content-4.jpg'
        ),
        'class'		=> 'aps-layout no_border image_border_white small_image'
    ),
    array(
        'box_id'	=> 'box_layout_final',
        'id'		=> 'layout_footer',
        'title'		=> __('Footer', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'type' 		=> 'radio_image',
        'value'		=> 'footer-1',
        'options'	=>  array(
            ''	=> '',
            'footer-1' 	=> '',
            'footer-2' 	=> '',
            'footer-3' 	=> '',
            'footer-4' 	=> ''
        ),
        'images'	=> array(
            APS_LAYOUTS_DIR_URI.'includes/images/layout-footer-0.jpg',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-footer-1.jpg',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-footer-2.jpg',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-footer-3.jpg',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-footer-4.jpg'
        ),
        'class'		=> 'aps-layout no_border image_border_white small_image'
    ),
    array(
        'box_id'	=> 'box_layout_final',
        'id'		=> 'layout_socket',
        'title'		=> __('Socket', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'type' 		=> 'radio_image',
        'value'		=> 'socket-1',
        'options'	=>  array(
            ''	=> '',
            'socket-1' 	=> ''
        ),
        'images'	=> array(
            APS_LAYOUTS_DIR_URI.'includes/images/layout-socket-0.jpg',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-socket-1.jpg'
        ),
        'class'		=> 'aps-layout no_border image_border_white small_image'
    ),


    //OPCIONES TITULO
    array(
        'box_id'	=> 'box_layout_options',
        'id'        => 'kk',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('Select the content for each area of the layout', APS_LB_LANG) ,
        'type' 		=> 'desc',
        'value'		=> '',
        'class'		=> 'no-hr',
    ),



    //OPCIONES IMAGE-SLIDER ENCIMA DE MENU
    // Layout-image encima de menu
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_slider1_group',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'type' 		=> 'select_image_box',
        'value'		=> '',
        'class'		=> '',
        'required'  => array('layout_slider1','image-1'),
        'fields'    => array(
            array(
                'box_id'	=> 'box_layout_options',
                'id'		=> 'layout_slider1_image',
                'title'		=> __('Image', APS_LB_LANG) ,
                'desc'		=> __('', APS_LB_LANG) ,
                'type' 		=> 'image_with_size',
                'value'		=> '',
                'class'		=> '',
                //'required'  => array('layout_image','{true}')
            ),


            /*array(
                'box_id'	=> 'box_layout_options',
                'id'		=> 'layout_slider1_ratio',
                'title'		=> __('Image aspect ratio height/width', APS_LB_LANG) ,
                'desc'		=> __('1/1 = square, 1/10 = landscape<br>Image will be centered in the box', APS_LB_LANG) ,
                'type' 		=> 'select',
                'options'	=> aps_get_image_ratio_array(1,10),
                'value'		=> '1/10',
                'class'		=> 'color-white',
                //'required'  => array('layout_image','{true}')
            ),*/
        )
    ),
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_slider1_input',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'type' 		=> 'select_slider_box',
        'value'		=> '',
        'class'		=> '',
        'required'  => array('layout_slider1','slider-1'),
    ),





    //OPCIONES HEADER MENU
    //Layout-menu
    //top bar
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_header_box_top',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'type'		=> 'header_box_2el',
        'class_select' => 'select-header-top-bar',
        'required'	=> array('layout_header','header-2,header-4'),
        'options'	=> array(
            $array_options_header,
            $array_options_header
        )
    ),


    //center bar
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_header_box_center',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'type'		=> 'header_box_2el',
        'class_select' => 'select-header-center-bar',
        'required'	=> array('layout_header','header-1,header-2,header-3,header-4'),
        'options'	=> array(
            $array_options_header,
            $array_options_header
        )
    ),
    /*
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_header_box_center2',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'type'		=> 'header_box_2el',
        'class_select' => 'select-header-center-bar',
        'required'	=> array('layout_header','header-3,header-4'),
        'options'	=> array(
                            array('-'=>'LOGO'),
                            array(
                                'contact'=> 'Contact data',
                                'social' => 'Social icons',
                                'copyright' => 'Copyright',
                                ''		  => 'None')
                       )
    ),
    */

    //bottom bar
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_header_box_bottom',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'type'		=> 'header_box_2el',
        'class_select' => 'select-header-top-bar',
        'required'	=> array('layout_header','header-3,header-4'),
        'options'	=> array(
            $array_options_header,
            $array_options_header
        )
    ),


    //OPCIONES SLIDER debajo del menu
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_slider2_group',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'type' 		=> 'select_image_box',
        'value'		=> '',
        'class'		=> '',
        'required'  => array('layout_slider2','image-1'),
        'fields'    => array(
            array(
                'box_id'	=> 'box_layout_options',
                'id'		=> 'layout_slider2_image',
                'title'		=> __('Image', APS_LB_LANG) ,
                'desc'		=> __('', APS_LB_LANG) ,
                'type' 		=> 'image_with_size',
                'value'		=> '',
                'class'		=> '',
                //'required'  => array('layout_image','{true}')
            ),
            /*
			array(
				'box_id'	=> 'box_layout_options',
				'id'		=> 'layout_slider2_ratio',
				'title'		=> __('Image aspect ratio height/width', APS_LB_LANG) ,
				'desc'		=> __('1/1 = square, 1/10 = landscape<br>Image will be centered in the box', APS_LB_LANG) ,
				'type' 		=> 'select',
				'options'	=> aps_get_image_ratio_array(1,10),
				'value'		=> '1/10',
				'class'		=> 'color-white',
				//'required'  => array('layout_image','{true}')
			)*/
        )
    ),
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_slider2_input',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'type' 		=> 'select_slider_box',
        'value'		=> '',
        'class'		=> '',
        'required'  => array('layout_slider2','slider-1')
    ),




    //OPCIONES CONTENT
    //content-1 content-2 content-3 content-4
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_content_widgets1',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'required'  => array('layout_content','content-1'),
        'type'		=> 'content_box_widgets',
        'n_widgets'	=> 'content-1'
    ),
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_content_widgets2',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'required'  => array('layout_content','content-2'),
        'type'		=> 'content_box_widgets',
        'n_widgets'	=> 'content-2'
    ),
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_content_widgets3',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'required'  => array('layout_content','content-3'),
        'type'		=> 'content_box_widgets',
        'n_widgets'	=> 'content-3'
    ),
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_content_widgets4',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'required'  => array('layout_content','content-4'),
        'type'		=> 'content_box_widgets',
        'n_widgets'	=> 'content-4'
    ),


    //OPCIONES FOOTER
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_footer_widgets1',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'required'  => array('layout_footer','footer-1'),
        'type'		=> 'socket_box_widgets',
        'n_widgets'	=> 1
    ),
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_footer_widgets2',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'required'  => array('layout_footer','footer-2'),
        'type'		=> 'socket_box_widgets',
        'n_widgets'	=> 2
    ),
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_footer_widgets3',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'required'  => array('layout_footer','footer-3'),
        'type'		=> 'socket_box_widgets',
        'n_widgets'	=> 3
    ),
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_footer_widgets4',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        'required'  => array('layout_footer','footer-4'),
        'type'		=> 'socket_box_widgets',
        'n_widgets'	=> 4
    ),


    //SOCKET BAR
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_socket_box',
        'title'		=> __('', APS_LB_LANG) ,
        'desc'		=> __('', APS_LB_LANG) ,
        //'desc'		=> __('Select the content for left and right side of the socket.<br>In <a href="'.admin_url().'admin.php?page=aps_op_general">Theme Options</a> you can fill the data<br>', APS_LB_LANG) ,
        'type'		=> 'header_box_2el',
        'class_select' => 'select-socket-bar',
        'required'	=> array('layout_socket','socket-1'),
        'options'	=> array(
            $array_options_header,
            $array_options_header
        )
    ),

    //BOXED - FULLWIDTH
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_responsive',
        'title'		=> __('BOXED / FULL WIDTH', APS_LB_LANG) ,
        'desc'      => __('You can select here a boxed layout or a full-width layout.', APS_LB_LANG) ,
        'type'      => 'radio_image',
        'value'     => 'boxed display-extend-no',
        'options'	=>  array(
            'boxed display-extend-no' 		 => 'Boxed',
            'boxed display-extend-yes' 		 => 'Boxed extended',
            'fullwidth-1260 display-extend-no' => 'Full-width max 1260px',
            'fullwidth-1260 display-extend-yes' => 'Full-width max 1260px extended',
            'fullwidth' 	 => 'Full-width'
        ),
        'images'	=> array(
            APS_LAYOUTS_DIR_URI.'includes/images/layout-boxed.png',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-boxed-extend.png',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-max.png',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-max-extend.png',
            APS_LAYOUTS_DIR_URI.'includes/images/layout-fullwidth.png'
        ),
        'class'		=> 'aps_layout_boxed no_border '
    ),

    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_use_background',
        'title'		=> __('BACKGROUND IMAGE ?', APS_LB_LANG) ,
        'desc'      => __('You can override default style and apply a background image to this layout.', APS_LB_LANG) ,
        'type'      => 'yes_no',
        'class'     => '',
    ),
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_back_image',
        'title'		=> __('Background Image', APS_LB_LANG) ,
        'desc'      => __('', APS_LB_LANG) ,
        'type'      => 'image',
        'class'     => '',
        'required'	=> array('layout_use_background','yes'),
    ),
    array(
        'box_id'	=> 'box_layout_options',
        'id'		=> 'layout_content_transparent',
        'title'		=> __('Background Content transparent', APS_LB_LANG) ,
        'desc'      => __('You can use transparent background for the content, so the content will have the image as its background.', APS_LB_LANG) ,
        'type'      => 'yes_no',
        'class'     => '',
        'required'	=> array('layout_use_background','yes'),
    ),


    //PAGES Y POSTS
    array(
        'box_id'	=> 'box_layout_page',
        'id'		=> 'layout_id',
        'title'		=> __('Layout', APS_LB_LANG) ,
        'desc'      => '<small>'.__('Default layout can be changed in ',APS_LB_LANG).'<a href="'.admin_url().'admin.php?page=aps_op_general">'.__('Theme Options',APS_LB_LANG).'</a></small><br><br>',
        'type' 		=> 'select_layout',
        'value'		=> '',
        'class'		=> ''
    ),

);












































