<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( ! function_exists( 'aps_register_post_type_layout' ) ) :
function aps_register_post_type_layout()
{
	//$path_icons = get_template_directory_uri().'/includes/stylesheets/images/icons/';
	
	$labels = array(
		'name'                  => __('Layouts', APS_LB_LANG),
		'singular_name'         => __('Layout', APS_LB_LANG),
		'add_new'               => __('Add New', APS_LB_LANG),
		'add_new_item'          => __('Add New Layout', APS_LB_LANG),
		'edit_item'             => __('Edit Layout', APS_LB_LANG),
		'new_item'              => __('New Layout', APS_LB_LANG),
		'view_item'             => __('View Layout', APS_LB_LANG),
		'search_items'          => __('Search Layouts', APS_LB_LANG),
		'not_found'             => __('No layouts found', APS_LB_LANG),
		'not_found_in_trash'    => __('No layouts found in Trash', APS_LB_LANG), 
		'parent_item_colon'     => '',
		'menu_name'             => __('Theme Layouts', APS_LB_LANG)
	);
	
	$args = array(
		'labels'                => $labels,
		'public'                => true,
		'exclude_from_search'	=> true,
		'publicly_queryable'    => false,
		'show_ui'               => true,
		'show_in_menu'          => true, 
		'query_var'             => false,
		'rewrite'               => array( 'slug' => 'layout' ),
		'capability_type'       => 'post',
		'has_archive'           => false, 
		'hierarchical'          => false,
		'menu_position'         => 63,
		//'menu_icon'             => $path_icons.'theme_options.png',
		'menu_icon'				=> APS_LAYOUTS_DIR_URI.'includes/images/icon-layout.png',
		'supports'              => array( 'title' )
	);	
	
	register_post_type( 'aps_layout', $args );
	
}
endif;

add_action('init', 'aps_register_post_type_layout');










