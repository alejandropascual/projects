<?php

/*
Plugin Name: ELAP - Layout Builder
Plugin URL: http://elapsl.com
Description: Layout Builder for PROJECTS theme.
Version: 1.0.0
Author: ELAP
Author URI: http://elapsl.com
*/

// =============================================================================
//	Constants
// =============================================================================

define( 'APS_LAYOUTS_URL', plugins_url( '', __FILE__ ) );

if ( !defined( 'APS_LAYOUTS_DIR' ) ) {
	define( 'APS_LAYOUTS_DIR', plugin_dir_path(__FILE__) );
}

if ( !defined( 'APS_LAYOUTS_DIR_URI' ) ) {
	define( 'APS_LAYOUTS_DIR_URI', plugin_dir_url(__FILE__) );
}



// =============================================================================
//	Locale
// =============================================================================

define( 'APS_LB_LANG' , 'aps_layoutbuilder');

function aps_layoutbuilder_load_lang() {
    load_plugin_textdomain('aps_layoutbuilder', false, basename(dirname(__FILE__)) . '/languages/' );
}

add_action('plugins_loaded', 'aps_layoutbuilder_load_lang');

// =============================================================================
//	Require files
// =============================================================================


// CLASSES
require( 'includes/php/class-htmlhelper.php' );
require( 'includes/php/class-metabox.php' );

// HOOKS
require( 'includes/php/layout-hooks.php' );
	
// POST TYPE LAYOUT
require( 'includes/php/layout-ajax.php' );
require( 'includes/php/layout-post-type.php' );
require( 'includes/php/layout-custom-columns.php' );
new APSMetaBox( APS_LAYOUTS_DIR.'/includes/php/layout-metabox.php' );




// =============================================================================
//	Utils
// =============================================================================

function aps_get_list_layouts()
{
    global $wpdb;
    $query = "SELECT ID,post_title FROM $wpdb->posts WHERE post_status='publish' AND post_type='aps_layout' ORDER BY post_date ASC";
    $results = $wpdb->get_results($query);

    $options = array();
    if (false != get_post_type()) {
        $options['default-'.get_post_type()] = 'Default: ('.get_post_type().')';
    }


    foreach($results as $result)
    {
        $options[$result->ID] = $result->post_title;
    }
    return $options;
}