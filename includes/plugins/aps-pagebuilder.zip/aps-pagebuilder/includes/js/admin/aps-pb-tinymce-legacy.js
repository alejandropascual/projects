// =============================================================================
// JS/ADMIN/TINYMCE.JS
// -----------------------------------------------------------------------------
// TinyMCE specific functions.
// =============================================================================

(function($) {

    "use strict";

	var aps_button = 'aps_shortcodes_button';

	tinymce.create('tinymce.plugins.'+aps_button, {

	
	    init : function(editor, url)
	    {
	    	editor.addCommand('apsOpenModalBuilder', function(ui, params){
			  //alert('Open Modal Window Builder');
			  //console.log(params);
			  //console.log(params.el);
			  var modal = new $.APSmodal(params);
			  //console.log(modal);
			  return false;
			});
	    },
	
	    createControl : function(btn, menu)
	    {
	    	//console.log('Creando boton '+btn);
	    	
			if ( btn != aps_button) return null;
	
			var current = this;
	      
			var btn = menu.createSplitButton(aps_button, {
				title: aps_globals.sc[aps_button].title,
				image: aps_globals.sc[aps_button].icon,
				icons: false
			});
				
	
			btn.onRenderMenu.add(function (c, menu) {
	        
				var sc_array_key = aps_globals.sc[aps_button].buttons;
				
				//console.log('ANTES DE ORDENAR');
				//console.log(sc_array_key);
				
				//Pasar a un array para poderlo ordenar
				var sc_array = [];
				for(var i in sc_array_key) {
					sc_array.push(sc_array_key[i]);
				} 

				//Ordernar segun order
				sc_array = sc_array.sort(function(obj1, obj2){
					return obj1.order - obj2.order;
					
				});
				
				//console.log('DESPUES DE ORDENAR');
				//console.log(sc_array);

				//Hallar los tabs que necesito
				var tabs = [];
				for (var i in sc_array)
				{
					if (typeof sc_array[i].tab != 'undefined'){
						tabs[sc_array[i].tab] = [];
					}
				}
				
				//Genero los menus y los almaceno en tabs denuevo
				for (var title in tabs) {
					tabs[title] = menu.addMenu({title: title});	
				}
				//console.log(tabs);
				
				//Para abrir el modal
				for (var i in sc_array) {
					//a.directInsert(menu, sc_array[i]);
					//a.modalInsert(tabs[title], sc_array[i]);
					
					//Dentro de un submenu ?
					var actualmenu = sc_array[i].tab ? tabs[sc_array[i].tab] : menu;
					
					//Codigo directo ?
					if ( typeof sc_array[i].direct_insert != 'undefined' )
					{
						current.directInsert(actualmenu, sc_array[i]);	
					}
					else
					{
						current.modalInsert(actualmenu, sc_array[i]);
					}
					
					
				}
	
			});
			return btn;
	    },

			
		directInsert : function (menu, shortcode)
		{
			menu.add({
				title: shortcode.name,
				onclick: function(){
					var content = shortcode.direct_insert;
					tinyMCE.activeEditor.selection.setContent(content);
			  		return false;
				}
			});
		},
		
		
		modalInsert : function (menu, shortcode)
		{
			menu.add({
				title: shortcode.name,
				onclick: function(){

					tinyMCE.activeEditor.execCommand('apsOpenModalBuilder', false, {
						scope: 			tinyMCE.activeEditor,		
						title:			shortcode.name,
						ajax_hook: 		shortcode.shortcode,
						ajax_param: 	{},
						//on_load: 		shortcode.on_load,
						//before_save: 	'',
						save_param:		'',
						on_save: 		function(values, save_param)
						{
							//Procesar los values antes de insertar
							//Genera el shortcode simple sin cierre
							/*
							if(typeof values != "string") 
							{
								var new_values = '';
								for (var key in values)
								{
									new_values += ' '+key+'="'+values[key]+'"';
								}
								values = '['+shortcode.shortcode+new_values+']';
							}
							*/
							
							//console.log('VALUES');
							//console.log(values);
							
							var line_break = "\n";
							if (shortcode.use_line_break != 'undefined' 
								&& shortcode.use_line_break == 'no') { line_break = ""; }

							
							var html = '';
							if( typeof values == "string") {
								html = values;
							} else {
								var sc = shortcode.shortcode;
								var html = '['+sc;
								var html_content = '';
								for (var key in values)
								{
									//if (key=='content'){
									if (key.indexOf('content')!=-1) {
										html_content += (line_break + values[key] + line_break);
									} else {
										//Campo no vacio
										if (values[key]!='undefined' && values[key]!=''){
											html += " "+key+"='"+values[key]+"'";
										}
									}
								}
								html += ']';
								
								if (html_content != '')
								{
									html_content = html_content.replace(/]/g, "]"+line_break);
									html_content = html_content.replace(/\[/g, line_break+"[");
									html += html_content+'[/'+sc+']';	
								}
							}

							
							html = window.switchEditors.wpautop(html);
							//console.log('Final values');
							//html = html.replace(/\]/g,']</ br>\n');
							//console.log(html);
							
							//Insertar en el editor el resultado
							tinyMCE.activeEditor.execCommand("mceInsertContent", false, html);		
						}
					});
					
					
				}
			});
		}
			
		/*
	    render : function(ed, title, id) {
	      ed.add({
	        title: title,
	        onclick: function () {
	
			  var content = null;
	
	          // Layout columns
						
			  if (id === 'column') {
		          content = '[aps_column type="1_1, 1_2, 1_3, 2_3, 1_4, 3_4, 1_5, 2_5, 3_5, 4_5" responsive=true last=true]Write your content here.[/aps_column]';
	          }
	          
	          
			  if (content!=null)
			  	tinyMCE.activeEditor.selection.setContent(content);
	
	          return false;
	
	        }
	      });
	    }*/
	    
  
	});

	tinymce.PluginManager.add(aps_button, tinymce.plugins[aps_button]);
	//tinymce.PluginManager.add('aps_shortcodes', tinymce.plugins.apsShortcodeMce);

})(jQuery);