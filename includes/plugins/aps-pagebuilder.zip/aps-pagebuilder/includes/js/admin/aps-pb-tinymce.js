// =============================================================================
// JS/ADMIN/TINYMCE.JS WP>=3.9
// -----------------------------------------------------------------------------
// TinyMCE specific functions.
// =============================================================================



(function($) {

    "use strict";

    var aps_button = 'aps_shortcodes_button';
    var aps_button_url_icon = aps_globals.sc['aps_shortcodes_button'].icon;


    //Preparar el menu para el tinymce
    function aps_tinymce_menu( editor )
    {

        //console.log('================ ARRANCANDO EL EDITOR >>>>>>>>>>>>>>>>>>>>>');

        var sc_array_key = aps_globals.sc[aps_button].buttons;

        //Pasar a un array para poderlo ordenar
        var sc_array = [];
        for(var i in sc_array_key) {
            sc_array.push(sc_array_key[i]);
        }

        //Ordernar segun order
        sc_array = sc_array.sort(function(obj1, obj2){
            return obj1.order - obj2.order;

        });

        //$(sc_array).each(function(){
        //   console.log(this.shortcode);
        //});


        //Menu en forma de objeto
        var menu = {};
        for (var i in sc_array) {
            if (typeof sc_array[i].tab != 'undefined')
            {
                var tab = sc_array[i].tab;

                if ( typeof menu[tab] == 'undefined') {
                    menu[tab] = { menu: Array() };

                }

                //Funcion anonima para que no capture variables
                (function add_button( shortcode ){

                    if ( typeof sc_array[i].direct_insert != 'undefined' ) {

                        menu[tab].menu.push({
                            text: shortcode.name,
                            onclick: function(){ editor.insertContent(shortcode.direct_insert); }
                        });

                    } else {

                        //console.log('Insertando '+shortcode.name);

                        menu[tab].menu.push({
                            text: shortcode.name,
                            onclick: function(){

                                editor.execCommand('apsOpenModalBuilder', false, {
                                    scope: 			editor,
                                    title:			shortcode.name,
                                    ajax_hook: 		shortcode.shortcode,
                                    ajax_param: 	{},
                                    //on_load: 		shortcode.on_load,
                                    //before_save: 	'',
                                    save_param:		'',
                                    on_save: function(values, save_param)
                                    {
                                        var line_break = "\n";
                                        if (shortcode.use_line_break != 'undefined'
                                            && shortcode.use_line_break == 'no') { line_break = ""; }

                                        var html = '';
                                        if( typeof values == "string") {
                                            html = values;
                                        } else {
                                            var sc = shortcode.shortcode;
                                            var html = '['+sc;
                                            var html_content = '';
                                            for (var key in values)
                                            {
                                                //if (key=='content'){
                                                if (key.indexOf('content')!=-1) {
                                                    html_content += (line_break + values[key] + line_break);
                                                } else {
                                                    //Campo no vacio
                                                    if (values[key]!='undefined' && values[key]!=''){
                                                        html += " "+key+"='"+values[key]+"'";
                                                    }
                                                }
                                            }
                                            html += ']';

                                            if (html_content != '')
                                            {
                                                html_content = html_content.replace(/]/g, "]"+line_break);
                                                html_content = html_content.replace(/\[/g, line_break+"[");
                                                html += html_content+'[/'+sc+']';
                                            }
                                        }

                                        html = window.switchEditors.wpautop(html);
                                        editor.insertContent(html);

                                    }
                                });

                            }
                        });

                    }

                })(sc_array[i]);

            }
        }
        //console.log(menu);

        //Lo convierto a array
        var menu_array = Array();
        for (var key in menu){
            menu_array.push({
                text: key,
                menu: menu[key].menu
            });
        };
        //console.log(menu_array);

        return menu_array;
    }


    //Añadir boton
    tinymce.PluginManager.add(aps_button, function( editor, url) {

        editor.addCommand( 'apsOpenModalBuilder', function(ui, params){
            var modal = new $.APSmodal(params);
            return false;
        });

        editor.addButton( aps_button, {

            type    : 'menubutton',
            title   : 'Projects Shortcodes',
            text    : '',
            image   : aps_button_url_icon,
            style   : 'background-image: url("' + aps_button_url_icon + '"); background-repeat: no-repeat; background-position: 2px 2px;"',
            icon:   true,
            menu:	aps_tinymce_menu( editor )
        });

    });


})(jQuery);