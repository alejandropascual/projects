(function($)
{

	"use strict";

////////////////////////////////
// APSmodal
////////////////////////////////

	$.APSmodal = function(options) {

		var defaults = {
			title: 'Shortcode',
			scope: this, 				// for the callback
			ajax_hook: '',			// function php ajax
			ajax_param: '',			// params for the hook function
			//on_load: '',			// callback after modal loading
			//before_save: '',		// callback before save data
			on_save: '',			// callback when save button pressed
			save_param: ''
		}
		
		//Añadir al array al inicio
		$.APSmodal.instance.unshift(this);
		
		this.options = $.extend({}, defaults, options);

        //Pruebas
        //this.options.ajax_param.shortcode = "[aps_content_strip container_width='fullwidth' padding_top='40px' padding_bottom='40px' use_border='yes' border='all' bg_type='image' bg_image_src='http://localhost:8888/wp_norvento/wp-content/uploads/2014/04/Health-Center-Velez-Rubio_LosdelDesierto_ELAP_27.jpg' bg_image_id='952' bg_image_size='full' bg_image_scroll='scroll']MI SUPER EJEMPLO[/aps_content_strip]";
        //console.log(this.options);
		
		this.modal = $('<div class="aps-modal"></div>');
		this.modal_backoverlay = $('<div class="aps-modal-backoverlay">');
		
		this.setup();
		//this.execute_callback();
	};
	
	
	$.APSmodal.instance = [];
	
	
	$.APSmodal.prototype = {
	
		setup: function()
		{
			this.create_html();
			this.bind_events();	
			
			//this.execute_callback();	
		},
		
		create_html: function()
		{
			var html = '';
			
			//Modal
			html += '<div class="aps-modal-inner">';
			
			//Header
			html += '<div class="aps-modal-header">';
			html += 	'<div class="aps-modal-title">'+this.options.title+'</div>';
			html += 	'<a href="#close" class="aps-modal-close">x</a>';
			//html += 	'<a href="#save" class="aps-modal-save">Save</a>';
			html += '</div>';
			
			//Content
			html += '<div class="aps-modal-content loading">';
			
			//EJEMPLO
			/*
			html += '<div class="aps-modal-field">';
			html += '	<div class="aps-modal-field-desc">';
			html += '		<div class="title">Description title</div>';
			html += '		<div class="desc">Description description</div>';
			html += '	</div>';
			html += '	<div class="aps-modal-field-form">';
			html += '		<input type="text" name="kk" value="Click me">';
			html += '	</div>';
			html += '</div>';
			*/
			
			html += '</div>';
			
			//Footer
			html += '<div class="aps-modal-footer">';
			html += 	'<a href="#save" class="aps-modal-save">Save</a>';
			html += '</div>';
			
			//Modal cerrar
			html += '</div>';
			
			$('#wpwrap').append(this.modal).append(this.modal_backoverlay);
			this.modal.html(html);
			
			//Fetch content
			this.fetch_content_ajax();
		},
		
		bind_events: function()
		{
			var self = this;
			
			this.modal.on('click','.aps-modal-save', function(){
				self.execute_callback();
				return false;	
			});
			
			this.modal.on('click', '.aps-modal-close', function(){
				self.close();
				return false;
			});
		},
		
		fetch_content_ajax: function()
		{
			var self = this,
				modal_content = this.modal.find('.aps-modal-content');
			
			var action = 'wp_ajax_aps_modal_'+this.options.ajax_hook;
			
			$.ajax({
				type: 'POST',
				url: ajaxurl,
				data:
				{
					//action: 'wp_ajax_my_action',
					action: 'aps_modal_'+this.options.ajax_hook,
					params: this.options.ajax_param
				},
				error: function()
				{
					$.APSmodal.instance[0].close();
					//NOtificar
				},
				success: function(response)
				{					
					if (response==0)
					{ //error
						//alert('AJAX ERROR');
						$.APSmodal.instance[0].close();
					}
					else if (response==-1)
					{ //timeout
						//alert('AJAX TIMEOUT');
						$.APSmodal.instance[0].close();
					}
					else
					{
						modal_content.html(response);
						self.on_load();
					}
				},
				complete: function(response)
				{
					modal_content.removeClass('loading');
				}
			});
		},
		
		
		// despues de cargar compruebo los controles
		on_load: function()
		{
			$.APSmodal.modal_elements.bind_button_idclassstyle.call(this);
			$.APSmodal.modal_elements.bind_colorpicker.call(this);
			$.APSmodal.modal_elements.bind_tinymce.call(this);
			$.APSmodal.modal_elements.bind_required.call(this);
			$.APSmodal.modal_elements.bind_sortable.call(this);
			$.APSmodal.modal_elements.bind_select_image.call(this);
			$.APSmodal.modal_elements.bind_select_gallery.call(this);
			$.APSmodal.modal_elements.bind_select_iconfont.call(this);
			$.APSmodal.modal_elements.bind_select_chosen.call(this);
            $.APSmodal.modal_elements.bind_select_animation.call(this);
		},
		
		//Despues de fetch
		/*
		on_load: function()
		{
			var self = this,
				callbacks = this.options.on_load,
				index = 0,
				call_func = '';
				
			//alert(callbacks);
			
			if (typeof callbacks == 'string') {
				var list_calls = callbacks.split(",");
				for (index in list_calls)
				{
					call_func = list_calls[index];
					
					if ( typeof $.APSmodal.modal_elements['bind_'+call_func] != 'undefined' )
					{
						//console.log('Llamando a la funcion bind_'+call_func);
						$.APSmodal.modal_elements['bind_'+call_func].call(this);
					}
					else
					{
						console.log('No existe la funcion $.APSmodal.modal_elements.bind_'+call_func);
					}
				}
			}
		},
		*/
		
		
		//Final
		execute_callback: function() 
		{
			//var values = '[aps_modal_shortcode]';
			
			//No quiero los campos que no sean visibles (debido a required)
			//textarea invisible tambien para los campos content que contienen
			//los nested shortcodes
			var values = this.modal.find('input:visible, select:visible, .chosen-select,  radio:visible, textarea:visible, input.use_always_sc, textarea.use_always_sc').serializeArray();

			//console.log('VALUES ANTES DE TRANSFORMAR');
			//console.log(values);
			
			var values_arr = this.convert_values_to_array(values);
			//console.log('DESPUES DE CONVERTIR EN ARRAY');
			//console.log(values_arr);
			
			
			//values = '[ejemplo]';
			var close_after = this.options['on_save'].call(this.options.el, values_arr, this.options.save_param);
			
			if (close_after != false) {
				this.close();
			}
		},
		
		convert_values_to_array: function(v)
		{
			var result = {};
			$.each(v, function()
			{
				if(typeof result[this.name] == 'undefined'){
					result[this.name] = '';
				}
				//if (this.name=='content')
                if ( this.name.indexOf('content') === 0 )
                {
					result[this.name] += this.value;
				} else {
					if (result[this.name]=='') {
                        result[this.name] = this.value;
                    }
					else {
                        result[this.name] += ',' + this.value;
                    }
				}
				
				
			});
			return result;
		},
		
		close: function()
		{
			//Quitar del array
			$.APSmodal.instance.shift();
			
			//Quitar de la pagina
			this.modal.remove();
			this.modal_backoverlay.remove();
			
		},
		
	};





////////////////////////////////
// APSmodal.modal_elements
////////////////////////////////

	
	$.APSmodal.modal_elements = $.APSmodal.modal_elements || {};
	
	$.APSmodal.modal_elements.bind_button_idclassstyle = function()
	{
		this.modal.on('click','.aps-icon-id_class_style', function(e){
			e.preventDefault();
			$(this).parent().toggleClass('open');
		});
	}
	
	$.APSmodal.modal_elements.bind_colorpicker = function()
	{
		var colorpicker = this.modal.find('.aps-modal-field-colorpicker');
		if (colorpicker.length == 0) return false;

		colorpicker.wpColorPicker();
		
	}
	
	$.APSmodal.modal_elements.bind_tinymce = function()
	{
		//console.log('Bind tinymce');
		var tinys = this.modal.find('.aps-modal-field-tinymce');
		if (tinys.length == 0) return false;
		
		//Cargar tinymce
		tinys.each(function(){
			var tiny_id = this.id;
			console.log('tiny_id = '+tiny_id);
			
			var settings	= {
				id: tiny_id ,
				buttons: "strong,em,link,block,del,ins,img,ul,ol,li,code,spell,close"
			};
			
			quicktags(settings);
			QTags._buttonsInit();
			
			//console.log('Arrancando tinyMCE '+tiny_id);
			window.tinyMCE.execCommand("mceAddControl", true, tiny_id);

		});
		
		//Quitar tinymce
		this.modal.find('.aps-modal-save,.aps-modal-close').click(function(){
			tinys.each(function(){
				var tiny_id = this.id;
				window.tinyMCE.execCommand("mceRemoveControl", true, tiny_id);
			});
		});
		
	}
	
	$.APSmodal.modal_elements.bind_required = function()
	{
		function comprobar_required()
		{
			var id = $(this).attr('id');
			var val = $(this).val();
			//console.log('Cambiado select id='+id+'->'+val);

            //Busco todos los campos required para ver quien ha sido afectado por el cambio
            $('.aps-modal-field[data-required]').each(function(){
                var $this = $(this);

                //No comprobar a si mismo
                if (id != $this.attr('id'))
                {
                    //Busco las condiciones de este alemento a ver si ha sido afectado
                    var condiciones = $this.data('required').split(' AND ');
                    //console.log(condiciones);

                    //Solo una condicion
                    if ( condiciones.length == 1)
                    {
                        var data = $this.data('required').split('->');
                        var data_id = data[0];
                        var data_valores = data[1].split(',');

                        //Coincide el valor del required, puedo pasar una lista de valores
                        if (data_id == id)
                        {
                            var coincide = false;
                            $.each(data_valores, function(index, data_valor){
                                if (data_valor == val) { coincide = true; }
                            });
                            if (coincide) { $this.show(300); }
                            else { $this.hide(300); }
                        }
                    }
                    else
                    {
                        //console.log('Comprobando dos condiciones');
                        //console.log(condiciones);

                        var data1 = condiciones[0].split('->');
                        var data1_id = data1[0];

                        var data2 = condiciones[1].split('->');
                        var data2_id = data2[0];

                        if ( id == data1_id || id == data2_id )
                        {
                            var data1_valores = data1[1].split(',');
                            var data2_valores = data2[1].split(',');

                            //Intercambiar condiciones para que el siguente paso no sea duplicar codigo
                            if ( id == data2_id )
                            {
                                var tmp_id = data1_id;
                                var tmp_valores = data1_valores;
                                data1_id = data2_id;
                                data1_valores = data2_valores;
                                data2_id = tmp_id;
                                data2_valores = tmp_valores;
                            }

                            var coincide1 = false;
                            $.each(data1_valores, function(index, data_valor)
                            {
                                if (data_valor == val) { coincide1 = true; }
                            });

                            //La primera condicion vale, busco la segunda
                            if (coincide1) {
                                //Tengo que comprobar la segunda condicion
                                //Busco el elemento y obtengo su valor
                                //console.log('Buscando el campo '+data2_id);

                                //PRESUPONGO UN SELECT
                                var campo = $('#field-'+data2_id+' select');
                                //console.log(campo);

                                //Si encuentra el campo puedo comprobar la segunda condicion
                                if (campo.length)
                                {
                                    var campo_valor = campo.val();
                                    //console.log(campo);
                                    //console.log(campo_valor);

                                    var coincide2 = false;
                                    $.each(data2_valores, function(index, data_valor)
                                    {
                                        if (data_valor == campo_valor) { coincide2 = true; }
                                    });

                                    //console.log('Coincide2 = ' + coincide2);

                                    if (coincide2) { $this.show(300); } //Coinciden ambas condiciones
                                    else { $this.hide(300); }

                                } else
                                {
                                    $this.hide(300);
                                }

                            } else {
                                $this.hide(300);
                            }
                        }
                    }

                };
            });


            /*
            //Pueden existir varias condiciones
            var condiciones = $this.data('required').split(' AND ');
            console.log(condiciones);

            var coincide_todo = false;

            $.each( condiciones, function(index, condicion){

                var datos = $this.data('required').split('->');
                var dato_id = datos[0];
                var dato_valor = datos[1];
                var dato_valores = dato_valor.split(',');

                var condicion_correcta = false;

                //Voy comprobando cada campo
                $('.aps-modal-field[data-required]').each(function(){

                    var $field = $(this);

                    //NO comprobar a si mismo
                    if ( $field.attr['id'] == dato_id )
                    {

                    }

                });


            });
            */

            /*
			$('.aps-modal-field[data-required]').each(function(){
			
				//console.log('Comprobando '+$(this).attr('id'));
				//console.log('required: '+$(this).data('required'));
				
				var $this = $(this);
				//No comprobar a si mismo
				if (id != $this.attr('id'))
                {
					var data = $this.data('required').split('->');
					//Coincide el valor del required
                    //puedo pasar una lista de valores
                    if (data[0]==id) {
                        var items = data[1].split(',');
                        var coincide = false;
                        $.each(items, function(index,item){
                            if (item == val) { coincide = true; }
                        });
                        if (coincide) { $this.show(300); }
                        else { $this.hide(300); }
                    }
				}
			});
            */


		}
		
		this.modal.find('.aps-modal-field-select').on('change', function(){
			comprobar_required.call(this);
		}).trigger('change');
		
	}
	
	$.APSmodal.modal_elements.bind_sortable = function()
	{
		var target = this.modal.find('.aps-modal-group');

		var params = {
			handle: '.aps-modal-group-field-move',
			items: '.aps-modal-group-field',
			tolerance: 'pointer',
			placeholder: 'aps-modal-group-field-highlight',
			forcePlaceholderSize:true,
			start: function( event, ui )
			{
			//$('.aps-modal-group-field-highlight').height(ui.item.outerHeight()).width(ui.item.outerWidth());
			},
			update: function( event, ui )
			{
				
			},
			stop: function( event, ui )
			{
				
			}
		};
		target.sortable(params);
	}
	
	
	$.APSmodal.modal_elements.bind_select_image = function()
	{
		var target = this.modal;
		
		target.on('click','.aps-modal-button-insert-image', function(e)
		{
			var $el = $(this);
			var $parent = $el.closest('.aps-modal-field-form');
			e.preventDefault();
			//alert('Aqui cargo la imagen');
			
			var file_frame = [];
			var frame_key = 'key';
			
			file_frame[frame_key] = wp.media(
			{
				frame:   'select',
				state:	 'aps_insert_image',
				library: { type: 'image' },
				button:  { text: 'Insert Image' },
				className: 'media-frame aps-media-img-only',
				//selection: prefill
			});
			
			var options_library = {type: "image", orderby: "date", query: true};
			
			
			file_frame[frame_key].states.add([
				new wp.media.controller.Library({
					id:         'aps_insert_image',
					title: 'ESCOGE UNA IMAGEN',
					priority:   20,
					toolbar:    'select',
					filterable: 'uploaded',
					library: wp.media.query(options_library),
					multiple:   false,
					editable:   true,
					displayUserSettings: false, 
					displaySettings: true,
					allowLocalEdits: true
				})
			]);
			
			
			file_frame[frame_key].on( 'select update insert', function(e) {
			    var selection, state = file_frame[frame_key].state();
			    selection = state.get('selection').first();
			});
			
			
			
			file_frame[frame_key].on( 'select update insert', function(e) {
			//frame.on('select', function(){
			//	var attachment = frame.state().get('selection').first();
			
				var state = file_frame[frame_key].state();
			    var attachment = state.get('selection').first();
			    
				//console.log(attachment.toJSON());
				
				var element = attachment.toJSON();
				var display = state.display( attachment ).toJSON();
				var preview_img = element.sizes[display.size].url;
				//console.log(preview_img);
				
				
				//alert('Imagen seleccionada: '+attachment.id);
				//Guardo la id
				$parent.find('.preview-image-id').val(attachment.id);
				//$parent.find('.preview-image-src').val(attachment.attributes.url);
				$parent.find('.preview-image-src').val(preview_img);
				$parent.find('.preview-image-size').val(display.size);
				
				//Obtener las imagenes
				$.post(ajaxurl,{
					'action': 'aps_get_image_src',
					'size':	'medium',
					'image_id': attachment.id
				}, function(response){
					//console.log(response);
					if (response==0){
						console.log('ERROR aps_get_image_src');
					} else {
						$parent.find('.aps-modal-preview-image img').attr('src',response);
						$parent.find('.aps-modal-preview-image-wrap').removeClass('without-image');
					}
				});
			});
			
			//frame.open();
			
			
			// Finally, open the modal
			file_frame[frame_key].open();
			
		});
		
		target.on('click','.aps-modal-button-delete-image', function(e)
		{
			var $el = $(this);
			var $parent = $el.closest('.aps-modal-field-form');
			e.preventDefault();
			
			$parent.find('.aps-modal-preview-image img').attr('src','');
			$parent.find('.preview-image-id').val('');
			$parent.find('.aps-modal-preview-image-wrap').addClass('without-image');
		});
		
	}
	
	
	$.APSmodal.modal_elements.bind_select_gallery = function()
	{
		var target = this.modal;
		
		
		target.on('click','.aps-modal-button-insert-gallery', function(e)
		{
			var $el = $(this);
			var $parent = $el.closest('.aps-modal-field-form');
			e.preventDefault();	
			
			//http://stackoverflow.com/questions/13936080/pre-select-images-when-opening-wordpress-3-5-media-manager
			
			var ids_selected = (function(){
				var ids = $parent.find('.preview-gallery-id').val().split(',');
				if (ids.length==0) return null;
				
				var selection = new Array();
				for (var i=0; i<ids.length; i++)
				{
					var id = ids[i];
					var attachment = wp.media.attachment(id);
					attachment.fetch();
					if (attachment) {
						selection.push(attachment);
					}
				}
				return selection;
			})();
			
			var frame = wp.media({
				id:                 'aps_edit_gallery',
				title:              'GALLERY',
				filterable:         'uploaded',
				frame:              'post',
				state:              'gallery-edit',
				library:            { type : 'image' },
				multiple:           true,
				editable:   true,
				editing:            true,
				selection:          ids_selected,
				displayUserSettings: false, 
				displaySettings: false,
				allowLocalEdits: true
			});
			
			frame.on('update', function(){
				var controller = frame.states.get('gallery-edit'),
					library = controller.get('library'),
					ids = library.pluck('id'),
					val = ids.join(',');
					
				$parent.find('.preview-gallery-id').val(val);
				if (val==''){
					$parent.find('.aps-modal-preview-gallery-wrap').html('');
					return;
				};
				
				//Obtener las imagenes
				$.post(ajaxurl,{
					action: 'aps_gallery_preview',
					attachments_ids: val
				}, function(response){
					//console.log(response);
					if (response==0){
						console.log('ERROR obteniendo la galeria de imagenes');
					} else {
						var result = JSON.parse(response);
						if (result.success){
							$parent.find('.aps-modal-preview-gallery-wrap').html(result.output);
						}
					}
				});
				
			});
			
			frame.open();
			
		});
	}
	
	
	
	$.APSmodal.modal_elements.bind_select_iconfont = function()
	{
		var target = this.modal;
		
		target.on('click','.modal-select-icon', function(e){
			e.preventDefault();
			var $parent = $(this).closest('.aps-modal-field-form');
			$parent.find('.icon-selected').removeClass('icon-selected');
			$(this).addClass('icon-selected');
			var icon = $(this).data('icon');
			$parent.find('input.selected-icon').val('fa-'+icon);
			$parent.find('.aps-modal-icon-preview i').removeClass().addClass('fa').addClass('fa-'+icon);
		});
		
		//Al inicio
		target.find('.icon-selected').trigger('click').addClass('icon-selected');
	}
	
	
	$.APSmodal.modal_elements.bind_select_chosen = function()
	{
	   
	   $('.chosen-select').chosen('.chosen-select').change(function(e){
		   //console.log('Chosen has changed ');
		   $('.chosen-select').trigger("chosen:updated");
	   });
	   
	}

    $.APSmodal.modal_elements.bind_select_animation = function()
    {
        $('.select-animation').change(function(e){
            var $self = $(e.target);
            //console.log('Animation changed');
            var $title = $self.parent().find('.animation');
            var animate = $self.val();
            setTimeout(function(){
                $title.removeClass().addClass('animation aps_animated aps_onScreen aps_'+animate);
            },300);
        });

    }

	
	
	
////////////////////////////////
// APSbuilder
// APSbuilder.helpers
////////////////////////////////
	
	
	$.APSbuilder = function(options) {
		
		var defaults = {
			
		};
		
		this.bind_behavior();
	}
	
	$.APSbuilder.prototype = {
		
		bind_behavior: function()
		{
			var self = this;
			var $body = $('body');
			
			//Edit subelement with modal window
			$body.on('click', '.aps-modal-group-field-inner', function()
			{
				//alert('Abrir submodal');
				
				var item = $(this).parents('.aps-modal-group-field:eq(0)');
				var text_shortcode = item.find('.shortcode-text:eq(0)').val();
				
				var options = {
					scope: item,
					ajax_hook: item.data('modal_ajax_hook'),
					ajax_param: {submodal:true, extract:true, shortcode: text_shortcode},
					on_save: $.APSbuilder.helpers.generateSCInTextarea,
					save_param: item
				};
				
				//console.log('SUBMODAL PARAMS');
				//console.log(options);
				
				var modal = new $.APSmodal(options);
				return false;
			});
			
			//Borrar subelement
			$body.on('click', '.aps-modal-group-field-delete', function(e)
			{
				$.APSbuilder.helpers.deleteModalGroupField(this,e);
			});
			
			//Añadir subelement
			$body.on('click', '.aps-modal-group-field-add', function(e)
			{
				$.APSbuilder.helpers.addModalGroupField(this,e);
			});
		}
		
	};
	

	$.APSbuilder.helpers = $.APSbuilder.helpers || {};
	
	$.APSbuilder.helpers.deleteModalGroupField = function(clicked, e)
	{
		//e.stopImmediatePropagation();
		e.preventDefault();
		var $clicked = $(clicked);
		var el = $(clicked).parents('.aps-modal-group-field:eq(0)');
		
		el.slideUp(300, function(){ el.remove(); });
	}
	
	$.APSbuilder.helpers.addModalGroupField = function(clicked, e)
	{
		e.preventDefault();
		var $clicked = $(clicked),
			wrap = $clicked.parents('.aps-modal-group-wrap:eq(0)'),
			parent = wrap.find('.aps-modal-group'),
			template = wrap.find('.aps-modal-group-field-template');
			
		$(template.html()).appendTo(parent).css({display:'none'}).slideDown(300);
	}
	
	$.APSbuilder.helpers.generateSCInTextarea = function(values, container)
	{
		console.log('generateSCInTextarea');
		console.log(values);
		
		//Transformo el array en shortcode
		var html = '';
		if( typeof values == "string") 
		{
			html = values;
		}
		else
		{
			var sc = container.data('modal_shortcode_nested');
			
			var html = '['+sc;
			var html_content = '';
			
			for (var key in values)
			{
				//if (key=='content'){
				if (key.indexOf('content')!=-1) {
					html_content += values[key];
				} else {
					html += " "+key+"='"+values[key]+"'";
				}
			}
			html += ']';
			
			if (html_content != ''){
				html += html_content+'[/'+sc+']';	
			}
		} 
		
		//console.log(html);
		//console.log(container);
		
		//Guardar en el textarea
		container.find('.shortcode-text').val(html);
		
		//Actualizar el campo en la linea subfield si vengo con values array
		if (typeof values != 'string') {
			var key_to_update = container.find('.title-content').data('update_with');
			//console.log('Key to update = '+key_to_update);
			var title_content = values[key_to_update];
			container.find('.title-content').html(title_content);
		}
	}
	
	$(document).ready(function () 
	{
    	$.apsbuilder = new $.APSbuilder();
	});

})(jQuery);






