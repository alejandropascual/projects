// =============================================================================
// JS/ADMIN/TINYMCE.JS
// -----------------------------------------------------------------------------
// TinyMCE specific functions.
// =============================================================================

(function() {
	
	var aps_button = 'aps_shortcodes_button';

  tinymce.create('tinymce.plugins.apsShortcodeMce', {


    init : function(editor, url){
      editor.addCommand('apsOpenScBuilder', function(ui, params){
					alert('Open Modal Window Builder');
			});
    },

    createControl : function(btn, e) {
    	//console.log('Creando boton '+btn);
    	
    	if ( btn != aps_button) return null;

      var a   = this;
      
      var btn = e.createSplitButton(aps_button, {
					title: aps_globals.sc[aps_button].title,
					image: aps_globals.sc[aps_button].icon,
					icons: false
			});
			

      btn.onRenderMenu.add(function (c, b) {
        
        // Layout
        c = b.addMenu({title:'Layout'});
        cc = c.addMenu({title:'Columns'});
				a.render( cc, 'Column', 'column');

      });
      return btn;

    },

    render : function(ed, title, id) {
      ed.add({
        title: title,
        onclick: function () {

		  var content = null;

          // Layout columns
					
					if (id === 'column') {
	          content = '[aps_column type="1_1, 1_2, 1_3, 2_3, 1_4, 3_4, 1_5, 2_5, 3_5, 4_5" responsive=true last=true]Write your content here.[/aps_column]';
          }
          
          
		  if (content!=null)
		  	tinyMCE.activeEditor.selection.setContent(content);

          return false;

        }
      });
    }
  
  });

	tinymce.PluginManager.add(aps_button, tinymce.plugins.apsShortcodeMce);
  //tinymce.PluginManager.add('aps_shortcodes', tinymce.plugins.apsShortcodeMce);

})();