(function($)
{

    "use strict";

    //=============================================
    // Full screen
    // Fit full height screen for element
    //=============================================

    $('.fit-height-screen').each(function(){

        //Restarle una altura predeterminada
        var minus = $(this).data('minus_height');

        //Restarle la altura del menu
        if ($(this).hasClass('minus-menu-height')) {
            minus = $('#menu-header').height();
        }

        //Evitar error
        if (typeof minus == 'undefined') { minus = 0;}

        var h = $(window).height() - minus;
        h = h+'px';

        $(this).css({
           'height': h,
           'min-height': h
        });
        //$(this).height( $(window).height() - minus);
    });


    //=============================================
    // BigVideo
    //=============================================


    jQuery(document).ready(function() {

        function adjustImagePositioning() {

            var $img = this,
                img = new Image();

            img.src = $img.attr('src');

            var windowWidth = $img.parent().width(),
                windowHeight = $img.parent().height(),
                r_w = windowHeight / windowWidth,
                i_w = img.width,
                i_h = img.height,
                r_i = i_h / i_w,
                new_w, new_h, new_left, new_top;

            if( r_w > r_i ) {
                new_h   = windowHeight;
                new_w   = windowHeight / r_i;
            }
            else {
                new_h   = windowWidth * r_i;
                new_w   = windowWidth;
            }

            $img.css({
                width   : new_w,
                height  : new_h,
                left    : ( windowWidth - new_w ) / 2,
                top     : ( windowHeight - new_h ) / 2
            });
        }


        //Solo un video
        if ($('.aps-bigvideo').length == 1) {

            var $self = $('.aps-bigvideo');
            var $image = $self.find('.bigvideo-image img');
            var video_mp4 = $self.data('video_mp4');

            //Imagen al centro
            $self.imagesLoaded(function(){
                adjustImagePositioning.call($image);
            });
            $(window).on('resize', function(){
                adjustImagePositioning.call($image);
            });

            //Arrancar el video
            var videoContainer = $self;
            var isTouch = Modernizr.touch;
            var BV = new $.BigVideo({
                forceAutoplay: isTouch,
                doLoop: true,
                container: videoContainer,
                shrinkable: false
            });
            BV.init();
            BV.show( video_mp4 );
            BV.getPlayer().on('loadeddata', function(){
                $image.parent().fadeOut(400, function(){
                    $image.parent().remove();
                });
            });
        }
    });


	//=============================================
	// Anchor-Scroll
	//=============================================
	
	$('.anchor-scroll').each(function(){
		var $el = $(this);
		var anchor_id = $el.data('anchor_id');
		
		$(window).scroll(function(){
			var scrollTop = $(window).scrollTop();
			var textoTop = $('#'+anchor_id).offset().top;
			var textoHeight = $('#'+anchor_id).height();
			var iconHeight = $el.height();
			
			if (scrollTop > textoTop) {
				var d = scrollTop-textoTop;
				
				if (d<(textoHeight-iconHeight)){
					$el.css({
						'position':'relative',
						'top':d+'px'
					});
				}
			}
		});
	});


	//=============================================
	// Galeria de imagenes - era antiguo, con Norvento
	//=============================================

    /*
	$.fn.aps_gallery = function(options)
	{
		return this.each(function(){
			
			//console.log('Comenzando aps-gallery');
			
			var $gallery = $(this);
			var $big_image = $gallery.find('.aps-gallery-big');
			var $big_image_img = $gallery.find('.aps-gallery-big .image');
			var $caption = $gallery.find('.aps-gallery-caption');
			//console.log($caption[0].innerText);
			
			if ($big_image.length)
			{	
				//Sobre los thumbs
				$gallery.on('click','.aps-gallery-thumbs a', function(e){
				
					//console.log('Has clikado un thumbnail');
					//console.log(this);
					
					e.preventDefault();
					
					var self = this;
					
					var newImg = self.getAttribute('data-preview');
					var oldImg = $big_image.find('img').attr('src');
					
					if (oldImg != newImg)
					{
						$big_image.attr('href',self.href);
						$big_image.attr('title',self.title);
						
						var n_img = new Image();
						n_img.src = newImg;
						if ($caption.length)
							$caption.addClass('hide');
						
						$big_image_img.stop().animate({opacity:0}, function(){
							$big_image_img.html(n_img);
							$big_image_img.animate({opacity:1},function(){
								
								//La descripcion de la imagen
								if ($caption.length){
									$caption[0].innerText = self.title;
									if (self.title.length>2){
										$caption.removeClass('hide');
									}
								}
								
								
							});
						});
					}
					
					
				});
			}
			
			
		});//return
		
	}//aps_gallery()

	jQuery(document).ready(function(){
		$('.aps-gallery').aps_gallery();

		//Boxer ya no lo uso
		//$('.boxer').boxer();
	});
	*/
	
	
	//=============================================
	// Galeria de videos - mediaelement - pendiente
	//=============================================
	
	/*
	$.fn.aps_gallery_videos = function(options)
	{
		return this.each(function(){
			
			var $gallery = $(this);
			
			//Si pulso la imagen arranca el primer video
			$gallery.on('click','.image.poster', function(e){
				$gallery.find('.aps-gallery-thumbs-video a:first-child').trigger('click');
			});
			
			//Cada thumbnail corresponde a un video
			$gallery.on('click','.aps-gallery-thumbs-video a', function(e){
					
					e.preventDefault();
					
					var self = this;
					var $self = $(this);
					
					var mp4 = $self.data('mp4');
					var ogv = $self.data('ogv');
					var webm= $self.data('webm');
					
					//Quitar el antiguo
					$gallery.find('.poster').remove();
					$gallery.find('.mejs-video').remove();
					if (mejs){ mejs.players = []; }		
		
					//Generar el nuevo
					var html = '<video width="100%" height="100%" style="width:100%; height:100%;">';
					html += '<source type="video/mp4" src="'+mp4+'">';
					
					html += '</video>';
		
					//Añadir y arrancar
					$gallery.find('.video-wrapper').append(html);
					$gallery.find('video').mediaelementplayer({
						videoWidth:'100%',
						videoHeight:'100%',
						features: ['playpause','progress','volume','fullscreen'],
						success: function(mediaElement, domObject){
							mediaElement.play();
							
							//Scroll to element
							var posx = $gallery[0].offsetLeft;
							var posy = $gallery[0].offsetTop;
							window.scrollTo(posx, posy-20);
						}
					});
			
			});
			
		});
		
	}
	
	jQuery(document).ready(function(){
		$('.aps-gallery-video').aps_gallery_videos();
	});
	*/
	
	
	
	//=============================================
	// Image marker
	//=============================================

    jQuery(document).ready(function(){

        $('.marker').popover({ html: true });


        //Ocultar los otros popover si estan abiertos
        $('.marker').on('show.bs.popover', function () {
            //console.log(this);
            $(this).addClass('open');//Es para girar el icono
            var el = this;
            $('.marker').each(function(index,item){
                if (el.className != item.className) {
                    $(item).popover('hide').removeClass('open');
                }
            });
            //$('.marker').popover('hide');
            //$(this).popover('show');
        });
        $('.marker').on('hide.bs.popover', function () {
            $(this).removeClass('open');//Para desgirar el icono
        });

        //Ocultar al tocar la imagen
        $('.aps-image-marker .image-poster').click(function(){
            $(this).parent().find('.marker').popover('hide');
        });


    });
	
	
	
	
	//=============================================
	// Tabs
	//=============================================
	
	jQuery(document).ready(function(){
		
		//Activar los tabs
		$('.aps-nav-tabs-item a').click(function (e) {
		  e.preventDefault();
		  $(this).tab('show');
		})
		
		
	});
	
	//=============================================
	// Tooltips
	//=============================================

	jQuery(document).ready(function(){
		
		$('.aps-tooltip').tooltip();
		
	});

    //=============================================
    // Gallery template, abrir ligtbox duando se pulsa directamente la imagen
    // en vez de usar la cortina
    //=============================================

    jQuery(document).ready(function(){

        $('.aps-gallery-template').on('click','.post-grid.image-direct-link-yes', function(){
            //alert ('CLicked image to open lightbox');
            //Arrancar lightbox como si se pulsara el icono
            $(this).find('a.popup').trigger('click');
        });
    });


    //=============================================
    // Image360
    //=============================================

    var image360 = function (){


        var $self = this;

        var def = {
            el_wrap : this,
            el_id: this.attr('id'),
            url_images:  this.attr('data-url_images'),
            first_image: parseInt( this.attr('data_first_image') ),
            last_image: parseInt( this.attr('data-last_image') ),
            digits: (this.attr('data_first_image')).length,
            image_extension: this.attr('data-image_extension')
        };

        //console.log(def);
        //return;

        var ready = false,
            dragging = false,
            pointerStartPosX = 0,
            pointerEndPosX = 0,
            pointerDistance = 0,
            monitorStartTime = 0,
            monitorInt = 10,
            ticker = 0,
            speedMultiplier = 10,
            spinner,
            firstFrame = def.first_image,
            totalFrames = def.last_image,
            currentFrame = 0,
            frames = [],
            endFrame = 0,
            loadedImages = 0; //first_image-1

        function addSpinner () {
            $self.find('.aps_image_360_spinner').fadeIn("slow");
        };

        function loadImage() {
            var li = document.createElement("li");
            var number = loadedImages+1;

            var str_number = number.toString();
            while (str_number.length < def.digits) { str_number = '0' + str_number;}

            var imageName = def.url_images + str_number + ".jpg";
            var image = $('<img>').attr('src', imageName).addClass("previous-image").appendTo(li);
            frames.push(image);
            $self.find(".aps_image_360_images").append(li);
            $(image).load(function() {
                imageLoaded();
            });
        };

        function imageLoaded() {
            loadedImages++;
            $self.find(".aps_image_360_spinner span").text(Math.floor(loadedImages / totalFrames * 100) + "%");

            if (loadedImages == totalFrames) {
                frames[0].removeClass("previous-image").addClass("current-image");
                $self.find(".aps_image_360_spinner").fadeOut("slow", function(){
                    $self.find(".aps_image_360_spinner").hide();
                    showAllImages();
                    //$self.find('.image_preview').hide();
                });
            } else {
                loadImage();
            }
        };

        function showAllImages () {
            $self.find(".aps_image_360_images").fadeIn("slow");
            ready = true;
            endFrame = -720;
            refresh();
        };

        addSpinner();
        loadImage();

        //return;

        function render () {

            if(currentFrame !== endFrame)
            {
                var frameEasing = endFrame < currentFrame ? Math.floor((endFrame - currentFrame) * 0.1) : Math.ceil((endFrame - currentFrame) * 0.1);
                hidePreviousFrame();
                currentFrame += frameEasing;
                showCurrentFrame();
            } else {
                window.clearInterval(ticker);
                ticker = 0;
            }
        };

        function refresh () {

            if (ticker === 0) {
                ticker = self.setInterval(render, Math.round(1000 / 60)); //60
            }
        };

        function hidePreviousFrame() {
            frames[getNormalizedCurrentFrame()].removeClass("current-image").addClass("previous-image");
        };

        function showCurrentFrame() {
            frames[getNormalizedCurrentFrame()].removeClass("previous-image").addClass("current-image");
        };

        function getNormalizedCurrentFrame() {
            var c = -Math.ceil(currentFrame % totalFrames);
            if (c < 0) c += (totalFrames - 1);
            return c;
        };

        function getPointerEvent(event) {
            return event.originalEvent.targetTouches ? event.originalEvent.targetTouches[0] : event;
        };


        $self.mousedown(function (event) {
            event.preventDefault();
            pointerStartPosX = getPointerEvent(event).pageX;
            dragging = true;
        });

        $(document).mouseup(function (event){
            event.preventDefault();
            dragging = false;
        });

        $(document).mousemove(function (event){
            event.preventDefault();
            trackPointer(event);
        });

        $self.live("touchstart", function (event) {
            event.preventDefault();
            pointerStartPosX = getPointerEvent(event).pageX;
            dragging = true;
        });

        $self.live("touchmove", function (event) {
            event.preventDefault();
            trackPointer(event);
        });

        $self.live("touchend", function (event) {
            event.preventDefault();
            dragging = false;
        });


        function trackPointer(event) {
            if (ready && dragging) {
                pointerEndPosX = getPointerEvent(event).pageX;
                if(monitorStartTime < new Date().getTime() - monitorInt) {
                    pointerDistance = pointerEndPosX - pointerStartPosX;
                    endFrame = currentFrame + Math.ceil((totalFrames - 1) * speedMultiplier * (pointerDistance / $self.width()));
                    refresh();
                    monitorStartTime = new Date().getTime();
                    pointerStartPosX = getPointerEvent(event).pageX;
                }
            }
        };
    };


    $(document).ready(function () {

        //ned360();
        //$('#ned100_360_preview .icon_load_360').click(function(){
        //    $('#ned100_360_preview .icon_load_360').hide();
        //    image360();
        //});

        $('.aps_image_360 .icon_load_360').each(function(){

            $(this).click(function(){
                $(this).hide();
                var $parent = $(this).closest('.aps_image_360');
                image360.call($parent);
            });

            var autoload = $(this).closest('.aps_image_360').attr('data-autoload');

            if (autoload == 'yes') {
                $(this).trigger('click');
            }
        });

    });



}(jQuery));

