<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_accordion' ) ) 
{
	class aps_accordion extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> __('Accordion',APS_PB_LANG),
				'shortcode' => 'aps_accordion',
				'shortcode_nested' => array('aps_accordion_item'),
                'tab' 		=> __('STRUCTURE',APS_PB_LANG),
				'order' 	=> 140
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(				
				array(
					'type' 	=> 'id_class_style',	
				),
				array(
					'label' => __('Items', APS_PB_LANG),
					'desc' 	=> __('Add or remove accordion items here', APS_PB_LANG),
					'id' 	=> 'content_wrap',
					'type' 	=> 'group_fields',
					'value' => array(
						array('title'=>'Title item 1', 'open'=>'yes', 'content_sub'=>'Content accordion item 1'),
						array('title'=>'Title item 2', 'open'=>'no', 'content_sub'=>'Content accordion item 2'),
						array('title'=>'Title item 3', 'open'=>'no', 'content_sub'=>'Content accordion item 3'),
					),
					'subfields' => array(
						array(
							'label' => __('Title', APS_PB_LANG),
							'desc' 	=> __('Enter the title here', APS_PB_LANG),
							'id' 	=> 'title',
							'type' 	=> 'input',
							'value' => 'The accordion item title',
							
						),
						array(
							'label' => __('Opened', APS_PB_LANG),
							'desc' 	=> __('Select if you want this element to be opened at the beginning', APS_PB_LANG),
							'id' 	=> 'open',
							'type' 	=> 'select',
							'options' => array('yes'=>'Yes', 'no'=>'No'),
							'value' => 'no'
						),

						array(
							'label' => __('Content', APS_PB_LANG),
							'desc' 	=> __('Enter the content here. You can edit after in the rich editor', APS_PB_LANG),
							'id' 	=> 'content_sub',
							'type' 	=> 'textarea',
							'value' => 'The accordion content goes here'
						),
						
					)
				),
				
				array(
					'label' => __('Panel header color', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'color_toggle',
					'type' 	=> 'colorpicker',
					'value' => '#000000',
				),
				array(
					'label' => __('Panel header background color', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'bg_color_toggle',
					'type' 	=> 'colorpicker',
					'value' => '#ffffff',
				),
                array(
                    'label' => __('Size accordion', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'size',
                    'type' 	=> 'select',
                    'value' => 'normal',
                    'options' => array('size-normal'=>'Normal','size-small'=>'Small')
                )

			);
		}
		
		function shortcode_handler($atts, $content='')
		{
			extract( shortcode_atts( array(
			  'id'    => uniqid(),
			  'class' => '',
			  'style' => '',
			  'color_toggle' => '',
			  'bg_color_toggle' => '',
              'size' => 'size-normal'
			), $atts ) );
			
			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? 'aps-panel-group ' . esc_attr( $class ) : 'aps-panel-group';
			$style = ( $style != '' ) ? 'style="' . $style . '"' : '';
			
			$cadena = 'parent_'.$id;
			if ($color_toggle!='') 
				$cadena .= ' color_toggle="'.$color_toggle.'"';
			if ($bg_color_toggle!='')
				$cadena .= ' bg_color_toggle="'.$bg_color_toggle.'"';
				
			$content = $this->add_to_shortcode($content, 'aps_accordion_item', $cadena);
			$html = "<div {$id} class=\"{$class} {$size}\" {$style}>" . do_shortcode( $content ) . "</div>";
			
			return $html;
		}
		
		
		
	}
}











if ( !class_exists( 'aps_accordion_item' ) ) 
{
	class aps_accordion_item extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Accordion Item',
				'shortcode' => 'aps_accordion_item',
				'tab' 		=> __('Wrap-Content',APS_PB_LANG),
				'order' 	=> 30,
				'direct_insert' => '[aps_accordion_item]Content here[/aps_accordion_item]',
				'hidden' => 'yes'
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array();
		}
		
		
		function shortcode_handler($atts, $content='')
		{
			extract( shortcode_atts( array(
			 	'id'        => '',
			 	'class'     => '',
				'style'     => '',
				'parent_id' => '',
				'title'     => '',
				'open'      => '',
				'color_toggle' => '',
				'bg_color_toggle' => '',
			), $atts ) );
			
			$id        = ( $id        != ''     ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class     = ( $class     != ''     ) ? 'panel aps-panel ' . esc_attr( $class ) : 'panel aps-panel';
			$style     = ( $style     != ''     ) ? 'style="' . $style . '"' : '';
			$parent_id = ( $parent_id != ''     ) ? 'data-parent="#' . $parent_id . '"' : '';
			$title     = ( $title     != ''     ) ? $title : '';
			$open      = ( $open      == 'yes' ) ? 'in' : 'collapse';
			$class_open= ( $open 	  == 'in' ) ? '' : 'collapsed';
			
			$color_toggle = ( $color_toggle!='') ? $color_toggle = 'color:'.$color_toggle.';' : '';
			$bg_color_toggle = ( $bg_color_toggle!='') ? $bg_color_toggle = ' background-color:'.$bg_color_toggle.';' : '';
			$style_toggle = " style=\"{$color_toggle}{$bg_color_toggle}\"";
			
			static $count = 0; $count++;
			
			$html = "<div {$id} class=\"{$class}\" {$style}>"
		          . '<div class="aps-panel-heading">'
		          	//.'<div class="panel-title">'
		            	. "<a class=\"aps-panel-toggle {$class_open}\" data-toggle=\"collapse\" href=\"#collapse-{$count}\" {$parent_id}{$style_toggle}>{$title}</a>"
		            //. '</div>'
		          . '</div>'
		          . "<div id=\"collapse-{$count}\" class=\"panel-collapse {$open}\">"
		            . '<div class="aps-panel-body">'
		              . do_shortcode( $content )
		            . '</div>'
		          . '</div>'
		        . "</div>";
		  
		  return $html;
		}
		
		
		
		
	}
}