<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_alertbox' ) ) {
    class aps_alertbox extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Alert Box',
                'shortcode' => 'aps_alertbox',
                'tab' => __('CONTENT', APS_PB_LANG),
                'order' => 90
            );

        }

        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),
                array(
                    'label'	=> __('Type', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'type',
                    'type' 	=> 'select',
                    'value' => 'h1',
                    'options' => array(
                        'success'   => 'Success',
                        'info'      => 'Info',
                        'warning'   => 'Warning',
                        'danger'    => 'Danger',
                        'global'    => 'General',
                    )
                ),
                array(
                    'label'	=> __('Text', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'content_sc',
                    'type' 	=> 'textarea',
                    'value' => 'Text here'
                ),
                array(
                    'label'	=> __('Align text', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'align',
                    'type' 	=> 'select',
                    'value' => 'left',
                    'options' => array(
                        'left'   => 'left',
                        'center'   => 'center',
                        'right'   => 'right'
                    )
                ),
                array(
                    'label'	=> __('Display Icon ?', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'use_icon',
                    'type' 	=> 'select',
                    'value' => 'yes',
                    'options' => array('yes'=>'YES','no'=>'NO')
                ),
                array(
                    'label'	=> __('Dissmisable ?', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'dismissable',
                    'type' 	=> 'select',
                    'value' => 'no',
                    'options' => array('yes'=>'YES','no'=>'NO')
                ),
            );

        }

        function shortcode_handler($atts, $content='')
        {
            extract(shortcode_atts(array(
                'id' => '',
                'class' => '',
                'style' => '',
                'align' => '',
                'type' => 'global', //global,sucess,info,warning,danger
                'use_icon' => 'yes',
                'dismissable' => 'yes'
            ), $atts));

            $id = ( $id != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $style = ( $style != '' ) ? 'style="' . $style . '"' : '';

            //Icon
            $html_icon = '';
            if ( $use_icon == 'yes' )
            {
                if ( $type == 'success' ) {
                    $icon = 'fa-flag';
                } else if ( $type == 'info' ) {
                    $icon = 'fa-bullhorn';
                } else if ( $type == 'warning' ) {
                    $icon = 'fa-fire-extinguisher';
                } else if ( $type == 'danger' ) {
                    $icon = 'fa-fire';
                } else {
                    $icon = 'fa-file-o';
                }
                $html_icon = "<span class=\"fa {$icon}\"></span>";
            }

            $html = '';

            $html .= "<div {$id} {$style} class=\"alert alert-{$type} {$class}\">";
            $html .= $html_icon;
            if ($dismissable == 'yes') {
                $html .= "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>";
            }
            $html .= "<div class=\"align-{$align} alert-content\">";
            $html .= do_shortcode($content);
            $html .= "</div>";
            $html .= "</div>";

            return $html;
        }
    }
}