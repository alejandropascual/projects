<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_animation' ) ) {
    class aps_animation extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Animation',
                'shortcode' => 'aps_animation',
                'tab' => __('EFFECTS', APS_PB_LANG),
                'order' => 100
            );

        }

        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),
                array(
                    'label'	=> __('Type', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'type',
                    'type' 	=> 'select_animation',
                    'value' => 'fadeInUp',
                ),
                array(
                    'label'	=> __('Delay', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'delay',
                    'type' 	=> 'select',
                    'value' => '0',
                    'options' => array(
                        '0'      => 'Animate when appears on screen',
                        '300'    => '300 ms',
                        '600'    => '600 ms',
                        '1000'   => '1000 ms',
                        '1500'   => '1500 ms',
                        '2000'   => '2000 ms',
                    )
                ),
                /*array(
                    'label'	=> __('Group', APS_PB_LANG),
                    'desc' 	=> __('Elements in the same group will trigger animation at the same time.', APS_PB_LANG),
                    'id' 	=> 'group',
                    'type' 	=> 'select',
                    'value' => 'fadeInUp',
                    'options' => array(
                        '0'    => 'No group',
                        '1'    => 'Group 1',
                        '2'    => 'Group 2',
                        '3'    => 'Group 3',
                        '4'    => 'Group 4',
                        '5'    => 'Group 5',
                        '6'    => 'Group 6',
                    )
                ),*/
                array(
                    'label'	=> __('Content', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'content_sc',
                    'type' 	=> 'textarea',
                    'value' => 'Content here',
                )
            );

        }

        function shortcode_handler($atts, $content='')
        {
            extract(shortcode_atts(array(
                'id' => '',
                'class' => '',
                'style' => '',
                'type' => 'fadeInUp',
                'delay' => '0',
                'group' => '0'
            ), $atts));

            $id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $style    = ( $style    != '' ) ? 'style="' . $style . '"' : '';

            $html  = "<div {$id} class=\"aps_animated aps_{$type} {$class}\" {$style}";
            if ( $delay!='0' && $delay!='' ) { $html .= " data-adelay=\"{$delay}\""; }
            if ( $group!='0' && $group!='') { $html .= " data-agroup=\"{$group}\""; }
            $html .= ">";
            $html .= do_shortcode( apply_filters('the_content', $content));
            $html .= "</div>";
            return $html;
        }
    }
}