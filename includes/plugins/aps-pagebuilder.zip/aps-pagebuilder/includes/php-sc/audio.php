<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_audio' ) ) 
{
	class aps_audio extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Audio',
				'shortcode' => 'aps_audio',
                'tab' 		=> __('MEDIA',APS_PB_LANG),
				'order' 	=> 120,
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',	
				),
				array(
					'label'	=> __('AUDIO HOSTED / EMBEDDED', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'type',
					'type' 	=> 'select',	
					'value' => 'embed_iframe',
					'options' => array(
						'hosted' => 'HOSTED',
						'embed_iframe' => 'EMBEDDED iframe',
					)
				),

				array(
					'label'	=> __('AUDIO iframe', APS_PB_LANG),
					'desc' 	=> __('Insert embedded code here.', APS_PB_LANG),
					'id' 	=> 'iframe',
					'type' 	=> 'textarea',	
					'value' => '<iframe width="100%" height="450" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/59865538&amp;auto_play=false&amp;hide_related=false&amp;visual=true"></iframe>',
					'required' => 'type->embed_iframe'
				),
				array(
					'label'	=> __('Use FRAME', APS_PB_LANG),
					'desc' 	=> __('Create a frame around the audio', APS_PB_LANG),
					'id' 	=> 'frame',
					'type' 	=> 'select',	
					'value' => 'yes',
					'options' => array(
						'yes' => 'YES',
						'no'  => 'NO'
					),
				),
				
				
				array(
					'label'	=> __('Audio m4a', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'm4a',
					'type' 	=> 'input',	
					'value' => '',
					'required' => 'type->hosted'
				),
				array(
					'label'	=> __('Audio mp3', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'mp3',
					'type' 	=> 'input',	
					'value' => '',
					'required' => 'type->hosted'
				),
				array(
					'label'	=> __('Audio oga', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'oga',
					'type' 	=> 'input',	
					'value' => '',
					'required' => 'type->hosted'
				),
				array(
					'label'	=> __('Poster Image', APS_PB_LANG),
					'desc' 	=> "Insert direct link of an Image or select one from media. Leave it blank if you don\'t want an image",
					'id' 	=> 'poster',
					'type' 	=> 'image_src_visible',	
					'value' => '',
					'required' => 'type->hosted',
					'button' => 'Select image'
				),
				array(
					'label'	=> __('Autoplay', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'autoplay',
					'type' 	=> 'select',	
					'value' => 'no',
					'options' => array(
						'yes' => 'YES',
						'no'  => 'NO'
					),
				),
				array(
					'label'	=> __('Skin', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'skin',
					'type' 	=> 'select',	
					'value' => 'black',
					'options' => array(
						'white' => 'White',
						'gray'  => 'Gray',
						'black' => 'Black'
					),
				),
			);
		}
		
		
		

		
		function shortcode_handler( $atts, $content = null )
		{
			if (isset($atts['type']))
				$type = $atts['type'];
			else 
				$type = null;
			
			if ($type=='hosted'){
				return $this->html_audio_hosted($atts, $content);
				
			} else if ($type=='embed_iframe'){
				return $this->html_audio_embed_iframe($atts, $content);
				
			} else {
				return '';
			}
			
		}

		function html_audio_embed_iframe($atts,$content=null)
		{
			extract( shortcode_atts( array(
			'id'     	=> '',
			'class' 	=> '',
			'style'  	=> '',
			'frame'		=> '',
			'iframe'	=> '',
			), $atts ) );
			
			$id     = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class  = ( $class != '' ) ? 'aps-audio-embed ' . esc_attr( $class ) : 'aps-audio-embed';
			$style  = ( $style != '' ) ? 'style="' . $style . '"' : '';
			
			$html = "<div {$id} class=\"{$class}\" {$style}>{$iframe}</div>";

			return $html;
		}
		

		
		function html_audio_hosted($atts,$content=null)
		{
			extract( shortcode_atts( array(
			'id'     		=> '',
			'class'  		=> '',
			'style'  		=> '',
			'frame'  		=> '',
			'm4a'		 	=> '',
			'mp3'    		=> '',
			'oga'    		=> '',
			'poster' 		=> '',
            'poster_ratio'  => '',//Si se define genera un espacio blanco
			'autoplay'		=> '',
			'skin'	 => ''
			), $atts ) );
			
			//Calcular bien los url por si son parciales
			$m4a = $this->get_url_media($m4a);
			$mp3 = $this->get_url_media($mp3);
			$oga = $this->get_url_media($oga);
			
			
			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? 'aps-audio aps-audio-hosted ' . esc_attr( $class ) : 'aps-audio aps-audio-hosted';

            if ( $poster_ratio!='' ){
                $ratio = 100.0 * floatval($poster_ratio);
                $style = 'position:relative;overflow:hidden;padding-top:'.$ratio.'%';
                $style_image_poster = 'style="position:absolute;top:0px;width:100%;"';
                $style_audio_inner = 'style="position:absolute;bottom:0px;width:100%;"';
            } else {
                $style_image_poster = '';
                $style_audio_inner = '';
            }
            $style = 'style="'.$style.'"';

			$autoplay = ( $autoplay == 'true' || $autoplay == 'yes' ) ? '.jPlayer("play")' : '';
			$skin = ( $skin != '' ) ? ' jp-skin-'.$skin : ' jp-skin-black';
			$frame = ( $frame=='false' || $frame=='no' ) ? '' : ' audio-with-frame';
			
			static $count = 0; $count++;
			
			$script = '<script>'.
			  'jQuery(document).ready(function($){
			  	//console.log("Preparando el audio "+'.$count.');
			  	if ($().jPlayer) {
						$("#aps_jplayer_audio_'.$count.'").jPlayer({
							ready: function () {
								$(this).jPlayer("setMedia", {'
								. ( ( $mp3!="" ) ? "mp3: '{$mp3}'," : '' )
								. ( ( $m4a!="" ) ? "m4a: '{$m4a}'," : '' )
								. ( ( $oga!="" ) ? "oga: '{$oga}'," : '' )
								//. ( ( $poster!="" ) ? "poster: '{$poster}'," : '' )
								.'})'.$autoplay.';
							},
							swfPath: "'.APS_PAGEBUILDER_URL.'/includes/js/vendor/jplayer",
							supplied: '
							. '"'
							. ( ($mp3!="") ? "mp3," : "")
							. ( ($m4a!="") ? "m4a," : "")
							. ( ($oga !="") ? "oga," : "")
							. '"'
							. ',size: {
								width: "100%",
								height: "100%"
							},
							cssSelectorAncestor: ".jp-audio-'.$count.'"
						});
			
			    //Corregir ids porque jplayer les asigna el mismo a todos
			    $("#aps_jplayer_audio_'.$count.' > img").attr("id","aps-jp-poster-'.$count.'");
			    $("#aps_jplayer_audio_'.$count.' > audio").attr("id","aps-jp-audio-'.$count.'");        
						
					}
				});'
				.'</script>';
			
			$controls = '<div class="jp-controls-wrapper">'
									.'<div id="jp_interface_audio_'.$count.'" class="jp-interface">'
			  						
			  						. '<ul class="jp-controls">'
			  							. '<li><a href="javascript:;" class="jp-play" tabindex="1"></a></li>'
											. '<li><a href="javascript:;" class="jp-pause" tabindex="1"></a></li>'
										. '</ul>'
										
										. '<div class="jp-progress-wrapper">'
											. '<div class="jp-progress">'
												. '<div class="jp-seek-bar">'
													.	'<div class="jp-play-bar"></div>'
												. '</div>'
											. '</div>'
										. '</div>'
										
									.'</div>'
								.'</div>';
			
			
			$html = $script;
			$html .=	"<div {$id} class=\"{$class}{$skin}{$frame} jp-audio jp-audio-{$count}\" {$style}>";
            $html .= 	    "<img class='aps-audio-poster' src='".$poster."' {$style_image_poster}>";
            $html .= 		"<div class=\"aps-audio-inner\" {$style_audio_inner}>";
			if ($poster != '' ) 
			//$html .= 			"<img class='aps-audio-poster' src='".$poster."'>";
			$html .= 			"<div id=\"aps_jplayer_audio_{$count}\" class=\"jp-jplayer\"></div>";
			$html .=				$controls;
			$html .=		"</div>";
			$html .= 	"</div>";

            wp_enqueue_script( 'aps-jplayer');
			return $html;
		}
	}
}




