<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_bigtitle' ) ) {
    class aps_bigtitle extends APSShortcode
    {
        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Big Title',
                'shortcode' => 'aps_bigtitle',
                'tab' => __('CONTENT', APS_PB_LANG),
                'order' => 30,
                'use_line_break' => 'no'
                //'direct_insert' => "[aps_bigtitle size='50px' align='center' color='white' bg_color='#ff3300' padding_v='3px' padding_h='15px' font='heading|text']THIS IS MY TITLE[/aps_bigtitle]"
            );

        }


        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),
                array(
                    'label'	=>__('THE TITLE', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'content_sc',
                    'type' 	=> 'textarea',
                    'value' => 'Write the title here'
                ),
                array(
                    'label'	=>__('text align', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'align',
                    'type' 	=> 'select',
                    'value' => 'center',
                    'options' => array('left'=>'left', 'center'=>'Center', 'right'=>'Right')
                ),
                array(
                    'label'	=>__('Font type', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'font',
                    'type' 	=> 'select',
                    'value' => 'heading',
                    'options' => array('heading'=>'Heading font', 'text'=>'Text font')
                ),
                array(
                    'label'	=>__('Font size', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'size',
                    'type' 	=> 'input',
                    'value' => '50px',
                ),
                array(
                    'label'	=>__('Color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'color',
                    'type' 	=> 'colorpicker',
                    'value' => '#ffffff',
                ),
                array(
                    'label'	=>__('Background Color', APS_PB_LANG),
                    'desc' 	=> __('Leave it blank if don\'t want any back color', APS_PB_LANG),
                    'id' 	=> 'bg_color',
                    'type' 	=> 'colorpicker',
                    'value' => '#ff3300',
                ),
                array(
                    'label'	=>__('Padding top', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'padding_top',
                    'type' 	=> 'input',
                    'value' => '3px',
                ),
                array(
                    'label'	=>__('Padding bottom', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'padding_bottom',
                    'type' 	=> 'input',
                    'value' => '3px',
                ),
                array(
                    'label'	=>__('Padding left', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'padding_left',
                    'type' 	=> 'input',
                    'value' => '15px',
                ),
                array(
                    'label'	=>__('Padding right', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'padding_right',
                    'type' 	=> 'input',
                    'value' => '15px',
                )
            );
        }

        function shortcode_handler($atts, $content = '')
        {
            extract( shortcode_atts( array(
                'id'   			=> '',
                'class' 		=> '',
                'style' 		=> '',
                'title'         => 'THIS IS THE TITLE',
                'align'         => 'center', //left, right
                'color'         => 'black',
                'bg_color'      => 'transparent',
                'padding_top'     => '',
                'padding_bottom'  => '',
                'padding_left'     => '',
                'padding_right'     => '',
                'size'          => '50px',
                'font'          => 'heading' // text
            ), $atts ) );

            $id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $class = ( $class != '' ) ? 'aps-bigtitle ' . esc_attr( $class ) .' ' : 'aps-bigtitle ';
            $style = ( $style != '' ) ? ' ' . $style : '';

            $style .= "text-align:{$align};";

            $tag = 'h1';
            if ($font=='text') $tag='div';

            $style_tag = "display:inline-block; ";

            if ( $padding_top != '' )       { $style_tag .= "padding-top:{$padding_top};"; }
            if ( $padding_bottom != '' )    { $style_tag .= "padding-bottom:{$padding_bottom};"; }
            if ( $padding_left != '' )      { $style_tag .= "padding-left:{$padding_left};"; }
            if ( $padding_right != '' )     { $style_tag .= "padding-right:{$padding_right};"; }

            //$style_tag .= "padding:{$padding_top} {$padding_right} {$padding_bottom} {$padding_left};";
            $style_tag .= "margin:0; color:{$color}; background-color:{$bg_color}; font-size:{$size}; line-height:1.2em;";

            $html  = "<div {$id} class=\"{$class}\" style=\"{$style}\">";
            $html .= "<{$tag} style=\"{$style_tag}\">";
            $html .= do_shortcode(apply_filters('the_content',$content));
            $html .= "</{$tag}>";
            $html .= "</div>";
            return $html;

        }
    }
}