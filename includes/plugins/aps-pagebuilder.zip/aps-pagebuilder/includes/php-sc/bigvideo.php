<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_bigvideo' ) ) {
    class aps_bigvideo extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Big Video background',
                'shortcode' => 'aps_bigvideo',
                'tab' => __('MEDIA', APS_PB_LANG),
                'order' => 115,
            );

        }


        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),
                array(
                    'label'	=> __('CONTENT HEIGHT', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'height',
                    'type' 	=> 'select',
                    'value' => 'no',
                    'options' => array(
                        'fullscreen'     => 'Screen height',
                        'fullscreen_minus'   => 'Screen height - menu height',
                        'defined' => 'Predifined height',
                    )
                ),
                array(
                    'label'	=> __('Height in pixels', APS_PB_LANG),
                    'desc' 	=> __('ex: 500', APS_PB_LANG),
                    'id' 	=> 'height_px',
                    'type' 	=> 'input',
                    'value' => '',
                    'required' => 'height->defined'
                ),
                array(
                    'label'	=> __('Image preview', APS_PB_LANG),
                    'desc' 	=> __('This image displays until de video is loaded', APS_PB_LANG),
                    'id' 	=> 'image_id',
                    'type' 	=> 'image',
                    'value' => '',
                    'button' => __('Image', APS_PB_LANG),
                ),
                array(
                    'label'	=> __('Video mp4', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'mp4',
                    'type' 	=> 'input',
                    'value' => '',
                ),
                array(
                    'label'	=> __('Content vertical center ?', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'center_vertical',
                    'type' 	=> 'select',
                    'value' => 'yes',
                    'options' => array('yes'=>'YES','no'=>'NO')
                ),
                array(
                    'label'	=> __('Content text align ?', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'align',
                    'type' 	=> 'select',
                    'value' => 'center',
                    'options' => array('left'=>'YES','center'=>'CENTER','right'=>'RIGHT')
                ),
                array(
                    'label'	=> __('Content', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'content_sc',
                    'type' 	=> 'textarea',
                    'value' => '',
                )
            );
        }

        function shortcode_handler($atts, $content='')
        {
            extract( shortcode_atts( array(
                'id'   			=> '',
                'class' 		=> '',
                'style' 		=> '',
                'height'        => 'fullscreen', // fullscreen_minus, defined
                'height_px'        => '',
                //'minus_height'  => '',//80  Para restar al fullscreen
                'center_vertical'   => 'yes',
                'align'         => 'center',
                'image_src'     => '',
                'image_id'      => '',
                'mp4'           => '',
                'ogg'           => ''
            ), $atts ) );

            $id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $class = ( $class != '' ) ? 'aps-bigvideo ' . esc_attr( $class ) .' ' : 'aps-bigvideo ';
            $style = ( $style != '' ) ? ' ' . $style : '';

            if ($center_vertical == 'yes') {
                $class .= 'center_vertical ';
            }

            if ( $height == 'fullscreen' ) {
                $class .= 'fit-height-screen';
                //$data_minus_height = "data-minus_height=\"{$minus_height}\"";
            } else if ( $height == 'fullscreen_minus' ) {
                $class .= 'fit-height-screen minus-menu-height';
            } else {
                $height = str_replace('px','',$height);
                $style .= ";height:{$height}px;";
            }

            $img_src = $this->get_image_from($image_src, $image_id, 'full');

            wp_enqueue_script( 'vendor-bigvideo');

            $html  = "<div {$id} class=\"{$class}\" style=\"{$style}\" data-video_mp4=\"{$mp4}\" data-video_ogg=\"{$ogg}\">";
            $html .= "<div class=\"bigvideo-image\"><img class=\"horizontal\" src=\"{$img_src}\"></div>";
            $html .= "<div class=\"bigvideo-overlay\" style=\"text-align:{$align};\"><div class=\"overlay-inner\">";
            $html .= do_shortcode( $content );
            $html .= "</div></div>";
            $html .= "</div>";
            return $html;
        }

    }
}