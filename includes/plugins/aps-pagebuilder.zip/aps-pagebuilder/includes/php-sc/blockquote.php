<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_blockquote' ) ) 
{
	class aps_blockquote extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Blockquote',
				'shortcode' => 'aps_blockquote',
                'tab' 		=> __('CONTENT-2',APS_PB_LANG),
				'order' 	=> 20,
                'use_line_break' => 'no'
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',	
				),
				array(
					'label'	=>__('Description', APS_PB_LANG),
					'desc' 	=> __('This quote extends to all the width of the content', APS_PB_LANG),
					'id' 	=> '',
					'type' 	=> 'description',	
					'value' => '',
					'class-wrap' => 'field-description',
					'class' => ''
				),
				array(
					'label'	=> __('TEXT ALIGN', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'align',
					'type' 	=> 'select',	
					'value' => 'left',
					'options' => array('left'=>'Left', 'center'=>'Center', 'right'=>'Right')
				),
				array(
					'label'	=> __('AUTHOR', APS_PB_LANG),
					'desc' 	=> __('The author of the quote', APS_PB_LANG),
					'id' 	=> 'cite',
					'type' 	=> 'input',	
					'value' => 'Steve Jobs',
				),
				array(
					'label'	=> __('CONTENT', APS_PB_LANG),
					'desc' 	=> __('Edit the content of the quote', APS_PB_LANG),
					'id' 	=> 'content_sc',
					'type' 	=> 'tinymce',	
					'value' => 'Design is not just what it looks like and feels like. Design is how it works.',
				),
				
			);
		}
		
		function shortcode_handler($atts, $content='')
		{
			extract( shortcode_atts( array(
				'id'    => '',
				'class' => '',
				'style' => '',
				'cite'  => '',
				'align'  => ''
			), $atts ) );
			
			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? 'aps-blockquote ' . esc_attr( $class ) : 'aps-blockquote';
			$style = ( $style != '' ) ? 'style="' . $style . '"' : '';
			$cite  = ( $cite  != '' ) ? '<cite class="aps-cite">' . $cite . '</cite>' : '';
			
			switch ( $align ) {
			case 'right' :
			  $align = ' align-right';
			  break;
			case 'center' :
			  $align = ' align-center';
			  break;
			default :
			  $align = '';
			}
			
			$html = "<div class=\"aps-blockquote-wrap\">";
            $html .= "<blockquote {$id} class=\"{$class}{$align}\" {$style}>";
            $html .= "<span class=\"fa fa-quote-left\"></span>";
            $html .= do_shortcode( $content );
            $html .= "<span class=\"fa fa-quote-right\"></span>";
            $html .= $cite;
            $html .= "</blockquote>";
            $html .= "</div>";
			
			return $html;
		}
		
	}
}