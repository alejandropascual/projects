<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_button' ) ) {
    class aps_button extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Button',
                'shortcode' => 'aps_button',
                'tab' => __('CONTENT-2', APS_PB_LANG),
                'order' => 40,
                'use_line_break' => 'no'
            );
        }


        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),
                array(
                    'label' => __('Content', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'content_sc',
                    'type' 	=> 'input',
                    'value' => 'My Button',
                ),
                array(
                    'label' => __('Link', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'link',
                    'type' 	=> 'input',
                    'value' => 'http://example.com',
                ),
                array(
                    'label'	=> __('Target', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'target',
                    'type' 	=> 'select',
                    'value' => '_blank',
                    'options' => array(
                        '_self'   => __('Open in the same window',APS_PB_LANG),
                        '_blank'  => __('Open in a new window',APS_PB_LANG)
                    ),
                    'required' => 'use_button->yes'
                ),
                array(
                    'label' => __('With icon before text ?', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'use_icon',
                    'type' 	=> 'select',
                    'value' => 'no',
                    'options' => array(
                        'before'=>'Before text',
                        'no'	=>'No icon',
                        'after' => 'After text'
                    )
                ),
                array(
                    'label' => __('Icon', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'icon',
                    'type' 	=> 'iconfont',
                    'value' => 'coffee',
                    'required'=>'use_icon->before,after'
                ),
                array(
                    'label' => __('TYPE of Button', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'type',
                    'type' 	=> 'select',
                    'value' => 'flat',
                    'options' => array(
                        'flat'	=> __('Flat',APS_PB_LANG),
                        'ghost'	=> __('Ghost',APS_PB_LANG),
                    )
                ),
                array(
                    'label' => __('Button SHAPE', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'shape',
                    'type' 	=> 'select',
                    'value' => 'square',
                    'options' => array(
                        'square'	=> __('Square',APS_PB_LANG),
                        'rounded'	=> __('Rounded',APS_PB_LANG),
                        'pill'	    => __('Pill',APS_PB_LANG),
                    )
                ),
                array(
                    'label' => __('Button SIZE', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'size',
                    'type' 	=> 'select',
                    'value' => 'medium',
                    'options' => array(
                        'x-small'  => __('X-Small',APS_PB_LANG),
                        'small'	   => __('Small',APS_PB_LANG),
                        'medium'   => __('Medium',APS_PB_LANG),
                        'large'    => __('Large',APS_PB_LANG),
                        'x-large'  => __('X-Large',APS_PB_LANG),
                        'super'    => __('Super',APS_PB_LANG),
                    )
                ),
                array(
                    'label' => __('Full Width Button ?', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'full_width',
                    'type' 	=> 'select',
                    'value' => 'no',
                    'options' => array(
                        'yes'	=> __('Yes',APS_PB_LANG),
                        'no'	=>__('No',APS_PB_LANG),
                    )
                ),


                array(
                    'label'	=> __('Color Style', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'skin',
                    'type' 	=> 'select',
                    'value' => '',
                    'options' => array(
                        'heading'   => __('Heading color',APS_PB_LANG),
                        'text'	    =>__('Text color',APS_PB_LANG),
                        'title'	    => __('Title color',APS_PB_LANG),
                        'link'	    => __('Link color',APS_PB_LANG),
                        'hoverlink'	=> __('Hover Link color',APS_PB_LANG),
                        'custom'    => __('Custom Colors',APS_PB_LANG)
                    )
                ),




                array(
                    'label'	=> __('Text Color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'color',
                    'type' 	=> 'colorpicker',
                    'value' => '#000000',
                    'required'=>'skin->custom'
                ),
                array(
                    'label'	=> __('Hover: Text Color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'hover_color',
                    'type' 	=> 'colorpicker',
                    'value' => '#ffffff',
                    'required'=>'skin->custom'
                ),


                array(
                    'label'	=> __('Back Color', APS_PB_LANG),
                    'desc' 	=> __('No effect for Ghost button (transparent)', APS_PB_LANG),
                    'id' 	=> 'bg_color',
                    'type' 	=> 'colorpicker',
                    'value' => '#ffffff',
                    //'required'=>'type->flat',
                    'required'=>'skin->custom'
                ),
                array(
                    'label'	=> __('Hover: Back Color', APS_PB_LANG),
                    'desc' 	=> __('No effect for Ghost button (transparent)', APS_PB_LANG),
                    'id' 	=> 'hover_bg_color',
                    'type' 	=> 'colorpicker',
                    'value' => '#000000',
                    //'required'=>'type->flat',
                    'required'=>'skin->custom'
                ),


                array(
                    'label'	=> __('Border Width', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'border_width',
                    'type' 	=> 'input',
                    'value' => '1px',
                    'required'=>'skin->custom'
                ),
                array(
                    'label'	=> __('Border Color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'border_color',
                    'type' 	=> 'colorpicker',
                    'value' => '#000000',
                    'required'=>'skin->custom'
                ),
                array(
                    'label'	=> __('Hover: Border Color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'hover_border_color',
                    'type' 	=> 'colorpicker',
                    'value' => '#000000',
                    'required'=>'skin->custom'
                ),
            );
        }

        function shortcode_handler($atts, $content='')
        {
            extract( shortcode_atts( array(
                'id'    => '',
                'class' => '',
                'style' => '',
                'link' => '',
                'target' => '_blank',
                'type' => '',//flat,transparent
                'shape' => '',//square,rounded,pill
                'size' => '',//x-small,small,medium,large,x-large,super
                //'float' => '',//left, right
                'full_width' => '',//true
                'skin'  => 'custom',

                'color' => '',
                'bg_color' => '',
                'hover_color' => '',
                'hover_bg_color' => '',
                'border_color' => '',
                'border_width' => '',
                'hover_border_color' => '',
                'use_icon'  => 'no',
                'icon' => ''
            ), $atts ) );

            if ($id == '') {
                $id = 'btn-'.uniqid();
            }
            else {
                $id = esc_attr( $id );
            }


            $style = ( $style != '' ) ? $style : '';

            $shape = ( $shape != '' ) ? ' aps-btn-' . $shape : ' aps-btn-square';
            $size = ( $size != '' ) ? ' aps-btn-' . $size : ' aps-btn-regular';
            $full_width = ( $full_width == 'true' || $full_width == 'yes' ) ? ' aps-btn-fullwidth': '';

            //Personalizado
            if ($skin == 'custom')
            {
                $class = ( $class != '' ) ? 'aps-btn ' . esc_attr( $class ) : 'aps-btn';

                $color = ($color != '') ? " color:{$color};" : ' color:white;';
                $bg_color = ($bg_color != '') ? " background-color:{$bg_color};" : ' background-color:black;';
                if ($type == 'ghost') {
                    $bg_color = " background-color:transparent;";
                }
                $border_color = ($border_color != '') ? " border-color:{$border_color};" : ' border-color:transparent;';
                $border_width = ($border_width != '') ? " border-width:{$border_width};" : ' border-width:0px;';

                //Hover
                $style_hover = '';
                if ($hover_color != '') {
                    $style_hover .= "#{$id}:hover { color:{$hover_color} !important; } ";
                }

                if ( $type == 'ghost'){
                    $style_hover .= "#{$id}:hover { background-color:transparent !important; } ";
                }
                else if ($hover_bg_color != '') {
                    $style_hover .= "#{$id}:hover { background-color:{$hover_bg_color} !important; } ";
                }

                if ($hover_border_color != '') {
                    $style_hover .= "#{$id}:hover { border-color:{$hover_border_color} !important; } ";
                }
                if ($style_hover!='') {
                    $style_hover = '<style>' . $style_hover . '</style>';
                }

            //Los del tema
            } else
            {

                $class = ( $class != '' ) ? 'aps-btn-theme ' . esc_attr( $class ) : 'aps-btn-theme';
                $class .= ' btn-theme-'.$skin; //heading,text,title,link,hoverlink
                $class .= ' type-'.$type; //flat / ghost

                $color = '';
                $bg_color = '';
                $border_color = '';
                $border_width = '';
                $style_hover = '';
            }







            $html = $style_hover . "<a id=\"{$id}\" class=\"{$class}{$shape}{$size}{$full_width}\" style=\"{$style}{$color}{$bg_color}{$border_color}{$border_width}\" href=\"{$link}\" target=\"{$target}\">";
            if ($use_icon == 'before'){
                $html .= '<i class="aps-icon fa '.$icon.'" style="padding-right:10px;"></i>';
            }
            $html .= do_shortcode( $content );
            if ($use_icon == 'after'){
                $html .= '<i class="aps-icon fa '.$icon.'" style="padding-left:10px;"></i>';
            }
            $html .= "</a>";

            return $html;
        }
    }
}