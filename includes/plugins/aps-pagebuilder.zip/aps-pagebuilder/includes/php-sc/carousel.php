<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_carousel' ) ) {
    class aps_carousel extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Carousel Images-Link',
                'shortcode' => 'aps_carousel',
                'shortcode_nested' => array('aps_carousel_item'),
                'tab' => __('GALLERIES', APS_PB_LANG),
                'order' => 140,
                'direct_insert' => "[aps_carousel image_width='300' image_height='150']
<br>[aps_carousel_item image_id='0' link='http://']
<br>[aps_carousel_item image_id='0' link='http://']
<br>[aps_carousel_item image_id='0' link='http://']
<br>[/aps_carousel]" );
        }


        function modal_fields()
        {
            $this->fields = array(
                /*
                array(
                    'type' => 'id_class_style',
                ),
                array(
                    'label' => __('Items', APS_PB_LANG),
                    'desc' 	=> __('Add or remove carousel items here', APS_PB_LANG),
                    'id' 	=> 'content_wrap',
                    'type' 	=> 'group_fields',
                    'value' => array(
                        array('title'=>'Title image 1', 'image'=>'', 'link'=>''),
                        array('title'=>'Title image 2', 'image'=>'', 'link'=>''),
                        array('title'=>'Title image 3', 'image'=>'', 'link'=>''),
                    ),
                    'subfields' => array(
                        array(
                            'label' => __('Title', APS_PB_LANG),
                            'desc' 	=> __('Enter the title here', APS_PB_LANG),
                            'id' 	=> 'title',
                            'type' 	=> 'input',
                            'value' => 'The accordion item title',

                        ),
                        array(
                            'label' => __('Image', APS_PB_LANG),
                            'desc' 	=> __('', APS_PB_LANG),
                            'id' 	=> 'image',
                            'type' 	=> 'image',
                            'value' => '',
                            'button' => 'Image'
                        ),

                        array(
                            'label' => __('Link', APS_PB_LANG),
                            'desc' 	=> __('Enter the link for this item here. Leave it blank if you dont want any link.', APS_PB_LANG),
                            'id' 	=> 'link',
                            'type' 	=> 'input',
                            'value' => ''
                        ),

                    )
                ),
                */
            );
        }


        function shortcode_handler($atts, $content = '')
        {
            extract( shortcode_atts( array(
                'id'    => '',
                'class' => '',
                'style' => '',
                'image_width' => '200',
                'image_height' => '150',
                'type' => 'photo-slider'
            ), $atts ) );

            $id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $class = ( $class != '' ) ? ' ' . esc_attr( $class ) : '';
            $style = ( $style != '' ) ? 'style="' . $style . '"' : '';

            $cadena = " width='{$image_width}' height='{$image_height}' type='{$type}'";
            $content = $this->add_to_shortcode($content, 'aps_carousel_item', $cadena);

            $html = "<div {$id} class=\"{$class}\" {$style}>";

            $html .= '<div class="everslider aps-everslider featured-slider" data-slide_width="'.$image_width.'" data-slide_height="'.$image_height.'">';
            $html .= '<ul class="es-slides">';
            $html .= do_shortcode( $content );
            $html .= '</ul>';
            $html .= '</div>';

            $html .= "</div>";

            return $html;
        }

    }
}





if ( !class_exists( 'aps_carousel_item' ) )
{
    class aps_carousel_item extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' 		=> 'Carousel Item',
                'shortcode' => 'aps_carousel_item',
                'tab' 		=> __('GALLERIES',APS_PB_LANG),
                'order' 	=> 150,
                'direct_insert' => '[aps_carousel_item image_id="0" link="http://"]',
                'hidden' => 'yes'
            );
        }


        function modal_fields()
        {
            $this->fields = array();
        }


        function shortcode_handler($atts, $content='')
        {
            extract( shortcode_atts( array(
                'type'      => '',
                'image_id'  => '',
                'link'      => '',
                'width'     => '200',
                'height'    => '150'
            ), $atts ) );

            $html = '';
            $image = aps_get_image_resized_for_id($image_id, $width, $height,0,'no');


            $html_image = '';
            if ($image && isset($image['resized']['img']))
            {
                $html_image =  $image['resized']['img'];
            } else {
                $placehold = $this->dame_placehold_image($width,$height,'error image');
                $html_image = $placehold['image'];
            }

            $data = [
                'permalink' => $link,
                'image' => $html_image
            ];

            $templates = $this->get_templates();
            if ($link=='') {
                $template = $templates['photo-slider-no_link'];
            } else {
                $template = $templates['photo-slider'];
            }

            $html .= '<li>'.$this->render_template($template,$data).'</li>';

            return $html;
        }

        function render_template( $tmpl, $data )
        {
            $html = $tmpl;
            foreach( $data as $key=>$value) {
                $html = str_replace('%'.$key.'%', $value, $html);
            }
            return $html;
        }


        function get_templates()
        {
            $templates = array();

            $templates['photo-slider'] = <<<TMPL
            <div class="featured-pic">
				<a href="%permalink%" target="_blank"><i class="fa fa-link"></i></a>
				%image%
			</div>
TMPL;
            $templates['photo-slider-no_link'] = <<<TMPL
            <div class="featured-pic">
				%image%
			</div>
TMPL;


            return $templates;
        }

    }
}
