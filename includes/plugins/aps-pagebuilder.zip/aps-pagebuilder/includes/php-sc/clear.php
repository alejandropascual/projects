<?php
// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }


if ( !class_exists( 'aps_clear' ) ) 
{
	class aps_clear extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Clear',
				'shortcode' => 'aps_clear',
                'tab' 		=> __('STRUCTURE',APS_PB_LANG),
				'order' 	=> 118,
				'direct_insert' => '[aps_clear]'
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',	
				),
			);
		}
		

		
		function shortcode_handler($atts, $content='')
		{
			extract( shortcode_atts( array(
				'id'    => '',
				'class' => '',
				'style' => ''
			), $atts ) );
			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? 'aps-clear ' . esc_attr( $class ) : 'aps-clear';
			$style = ( $style != '' ) ? 'style="' . $style . '"' : '';
			
			$html = "<hr {$id} class=\"{$class}\" {$style}>";
			return $html;
		}
		
	}
}