<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_columns' ) ) 
{
	class aps_columns extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Columns',
				'shortcode' => 'aps_columns',
				'shortcode_nested' => array('aps_column'),
                'tab' 		=> __('STRUCTURE',APS_PB_LANG),
				'order' 	=> 120,
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',	
				),
				array(
					'label'	=>__('RESPONSIVE COLUMNS', APS_PB_LANG),
					'desc' 	=> __('Each column expands 100% when the width of the window is small', APS_PB_LANG),
					'id' 	=> 'responsive',
					'type' 	=> 'select',	
					'value' => 'yes',
					'options' => array(
						'yes' => 'YES',
						'no' => 'NO'
					)
				),
				array(
					'label'	=>__('MARGIN', APS_PB_LANG),
					'desc' 	=> __('Use margin between columns', APS_PB_LANG),
					'id' 	=> 'margin',
					'type' 	=> 'select',	
					'value' => 'yes',
					'options' => array(
						'yes' => 'YES',
						'no' => 'NO'
					)
				),
				array(
					'label'	=> __('ADD EDIT COLUMNS', APS_PB_LANG),
					'desc' 	=> __('Add or edit the columns here. The sum of all has to be 100%.', APS_PB_LANG),
					'id' 	=> 'content_wrap',
					'type' 	=> 'group_fields',
					'value' => array(
						array('type'=>'1_3','content_sub'=>'Content'),
						array('type'=>'1_3','content_sub'=>'Content'),
						array('type'=>'1_3','content_sub'=>'Content'),
					),
					'subfields' => array(
						array(
							'label' => __('Column type', APS_PB_LANG),
							'desc' 	=> __('', APS_PB_LANG),
							'id' 	=> 'type',
							'type' 	=> 'select',
							'value' => '1_3',
							'options' => array(
								'1_1' => 'Column 1_1 = 100%',
								'1_2' => 'Column 1_2 = 50%',
								'1_3' => 'Column 1_3 = 33%',
								'1_4' => 'Column 1_4 = 25%',
								'1_5' => 'Column 1_5 = 20%',
                                '2_5' => 'Column 2_5 = 40%',
                                '3_5' => 'Column 3_5 = 60%',
                                '4_5' => 'Column 4_5 = 80%',
                                '2_3' => 'Column 2_3 = 66%',
                                '3_4' => 'Column 3_4 = 75%',
                            )
						),
						array(
							'label' => __('Content', APS_PB_LANG),
							'desc' 	=> __('Enter the content here. You can edit after in the rich editor', APS_PB_LANG),
							'id' 	=> 'content_sub',
							'type' 	=> 'textarea',
							'value' => 'The content here'
						)
					)
				)
			);
		}
		

		
		function shortcode_handler($atts, $content='')
		{

			extract( shortcode_atts( array(
				'id'    => '',
				'class' => '',
				'style' => '',
				'responsive' => 'yes',
				'margin' => 'yes'
			), $atts ) );

			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? 'class="row aps-clear ' . esc_attr( $class ) . '"' : 'class="row aps-clear"';
			$style = ( $style != '' ) ? 'style="' . $style . '"' : '';

            //Se compone de varios shortcodes, uno por columnas

			//Añado a cada nested shortcode lo de responsive y margin			
			$string = 'responsive='.$responsive.' margin='.$margin;
			$new_content = $this->add_to_shortcode($content,'aps_column',$string);

			//Ahora a la ultima ocurrencia añado last=yes			
			$index = strrpos($new_content, $string);
			$string_last = $string.' last=yes';
			if($index) {
				$new_content = substr_replace($new_content, $string_last, $index, strlen($string));
				//echo '<pre>'; print_r($new_content); echo '</pre>';
			}

            $html  = "<div {$id} {$class} {$style}>";
			$html .= do_shortcode($new_content);
            $html .= "</div>";
			return $html;
		}
		
	}
}





if ( !class_exists( 'aps_column' ) ) 
{
	class aps_column extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Column',
				'shortcode' => 'aps_column',
				'tab' 		=> __('Structure',APS_PB_LANG),
				'order' 	=> 200,
				'hidden' => 'yes'
			);
		}
		
		function modal_fields()
		{
			$this->fields = array();
		}
		
		
		function shortcode_handler($atts, $content='')
		{
		  extract( shortcode_atts( array(
		    'id'    => '',
		    'class' => '',//no-margin
		    'style' => '',
		    'type'	=> '',
		    'responsive' => 'yes',
		    'last'	=> 'no', //por defecto no es la ultima
		    'margin' => 'yes'//por defecto margen si
		  ), $atts ) );
		  
		  $id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
		  $class = ( $class != '' ) ? 'aps-column ' . esc_attr( $class ) : 'aps-column';
		  $style = ( $style != '' ) ? 'style="' . $style . '"' : '';
		  $type  = ( $type  != '' ) ? ' col-' . $type : '';
		  $responsive  = ( $responsive  == 'true' || $responsive=='yes' ) ? ' responsive': '';
		  $last_class  = ( $last  == 'true' || $last=='yes') ? ' last' : '';
		  $margin = ( $margin  == 'true' || $margin=='yes') ? '' : ' no-margin';
		  
		  $html = "<div {$id} class=\"{$class}{$type}{$responsive}{$last_class}{$margin}\" {$style}>" . do_shortcode( apply_filters('the_content',$content) ) . "</div>";
		  if ($last == 'true') {
				$html .= '<hr class="aps-clear">'; 
		  }
		  return $html;
		}
	}
}