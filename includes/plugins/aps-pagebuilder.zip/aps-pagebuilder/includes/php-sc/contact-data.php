<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

// Lo coje de las opciones del tema si existen

if ( !function_exists('aps_load_theme_domain') ) {
    return false;
}


if ( !class_exists( 'aps_contact' ) ) {
    class aps_contact extends APSShortcode
    {
        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Contact data',
                'shortcode' => 'aps_contact',
                'tab' => __('CONTENT-2', APS_PB_LANG),
                'order' => 70,
                'direct_insert' => "[aps_contact contact='yes' social='yes']"
            );
        }

        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),
            );
        }

        function shortcode_handler($atts, $content='')
        {
            extract( shortcode_atts( array(
                'id'    => '',
                'class' => '',
                'style' => '',
                'contact' => 'yes',
                'social' => 'yes'
            ), $atts ) );

            $html = '';

            $html .= '<div class="sc-contact-data">';
            if ( $contact == 'yes' )
            {
                $ct = get_option('aps_op_contact');
                if ($ct) {
                    $html .= '<div class="sc-contact-data-address">';
                    if ( isset($ct['address']) && $ct['address'] != '' ) {
                        $html .= '<div><i class="fa fa-location-arrow"></i>' . $ct['address'] . '</div>';
                    }
                    if ( isset($ct['telephone']) && $ct['telephone'] != '' ) {
                        $html .= '<div><i class="fa fa-mobile"></i>' . $ct['telephone'] . '</div>';
                    }
                    if ( isset($ct['email']) && $ct['email'] != '' ) {
                        $html .= '<div><i class="fa fa-envelope"></i><a href="mailto:' . $ct['email'] . '">' . $ct['email'] . '</a></div>';
                    }
                    if ( isset($ct['schedule']) && $ct['schedule'] != '' ) {
                        $html .= '<div><i class="fa fa-calendar"></i>' . $ct['schedule'] . '</div>';
                    }
                    $html .= '</div>';
                }
            }
            if ( $social == 'yes' )
            {
                $social_data = get_option('aps_op_social');
                if ($social_data)
                {
                    $ops = array(
                        'facebook'  => 'facebook',
                        'twitter'   => 'twitter',
                        'rss'       => 'rss',
                        'linkedin'  => 'linkedin',
                        'skype'     => 'skype',
                        'tumblr'    => 'tumblr',
                        'google'    => 'google-plus',
                        'pinterest' => 'pinterest',
                        'dribbble'  => 'dribbble',
                        'flickr'    => 'flickr',
                        'youtube'   => 'youtube',
                        'vimeo'     => 'vimeo',
                        'instagram' => 'instagram',
                        'github'    => 'github'
                    );
                    $open = $social_data['social_open'];
                    $target = '_self';
                    if ($open == 'yes') { $target = '_blank'; }

                    $html .= '<div class="sc-contact-data-social">';
                    foreach($ops as $key=>$value)
                    {
                        $name = 'social_'.$key;
                        if ( isset($social_data[$name]) && $social_data[$name]!='' ) {
                            $html .= '<a class="aps-tooltip" data-toggle="tooltip" data-placement="top" title="'.strtoupper($value).'" target="'.$target.'" href="' . $social_data[$name] . '"><i class="fa fa-'.$value.'"></i></a>';
                        }
                    }
                    $html .= '</div>';
                }
            }
            $html .= '</div>';
            return $html;
        }
    }

}