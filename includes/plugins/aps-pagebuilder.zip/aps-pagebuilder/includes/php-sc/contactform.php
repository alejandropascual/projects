<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_contactform' ) ) {
    class aps_contactform extends APSShortcode
    {
        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Contact Form',
                'shortcode' => 'aps_contactform',
                'tab' 		=> __('CONTENT-2',APS_PB_LANG),
                'order' 	=> 80,
            );

        }


        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),
                array(
                    'label'	=>__('Contact Form', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'form_id',
                    'type' 	=> 'select_contactform7',
                    'value' => ''
                ),
                array(
                    'label'	=>__('Font Size', APS_PB_LANG),
                    'desc' 	=> __('1em will maintain the normal height.<br>1.5em will increase the font size 50%<br>2em is for double font size.', APS_PB_LANG),
                    'id' 	=> 'font_size',
                    'type' 	=> 'input',
                    'value' => '1em',
                ),
            );
        }

        function shortcode_handler($atts, $content = '')
        {
            extract( shortcode_atts( array(
                'id'   			=> '',
                'class' 		=> '',
                'style' 		=> '',
                'form_id'         => '',
                'font_size'         => '1em',
            ), $atts ) );

            $id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $class = ( $class != '' ) ? 'aps-contactform ' . esc_attr( $class ) .' ' : 'aps-contactform ';
            $style = ( $style != '' ) ? ' ' . $style : '';

            $style = "font-size:{$font_size};".$style;

            $html  = "<div {$id} class=\"{$class}\" style=\"{$style}\">";
            $html .= do_shortcode("[contact-form-7 id='{$form_id}']");
            $html .= "</div>";
            return $html;

        }
    }
}