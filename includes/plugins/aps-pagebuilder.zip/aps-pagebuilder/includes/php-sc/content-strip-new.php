<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_content_strip' ) )
{
    class aps_content_strip extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' 		=> 'Content Strip',
                'shortcode' => 'aps_content_strip',
                'tab' 		=> __('STRUCTURE',APS_PB_LANG),
                'order' 	=> 10
            );
        }


        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),

                array(
                    'label'	=>__('Description', APS_PB_LANG),
                    'desc' 	=> __('This shortcode wrap your content with a background image, a background color, or a background pattern.<br>You can also define the margin and the border for the four sides.', APS_PB_LANG),
                    'id' 	=> '',
                    'type' 	=> 'description',
                    'value' => '',
                    'class-wrap' => 'field-description',
                    'class' => ''
                ),
                array(
                    'label'	=> __('CONTENT WIDTH', APS_PB_LANG),
                    'desc' 	=> __('Boxed: the content will be centered in the page<br>  (ex: use this when you have a full-width layout and want to keep the content centered)<br>Padding: define also padding left and right<br>Full-width: no left and right padding', APS_PB_LANG),
                    'id' 	=> 'container_width',
                    'type' 	=> 'select',
                    'value' => 'no',
                    'options' => array(
                        'boxed'     => 'Boxed',
                        'padding'   => 'With padding',
                        'fullwidth' => 'Full-width',
                    )
                ),
                array(
                    'label'	=> __('CONTENT HEIGHT', APS_PB_LANG),
                    'desc' 	=> __('Full-screen: this will fit the height of the strip to the height of the screen', APS_PB_LANG),
                    'id' 	=> 'container_height',
                    'type' 	=> 'select',
                    'value' => 'no',
                    'options' => array(
                        'normal' => 'Normal Flow content',
                        'fullscreen' => 'Full-screen height',
                        'fullscreen_minus' => 'Full-screen height - menu height',
                        'custom_height' => 'Custom Height'
                    )
                ),
                array(
                    'label'	=> __('Vertical center content', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'vertical_center',
                    'type' 	=> 'select',
                    'value' => 'yes',
                    'options' => array('yes'=>'YES','no'=>'NO'),
                    'required' => 'container_height->fullscreen,fullscreen_minus,custom_height'
                ),
                array(
                    'label'	=> __('Vertical height', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'height',
                    'type' 	=> 'input',
                    'value' => '300px',
                    'required' => 'container_height->custom_height'
                ),
                array(
                    'label'	=> __('Text align content', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'align',
                    'type' 	=> 'select',
                    'value' => 'left',
                    'options' => array('left'=>'LEFT','center'=>'CENTER','right'=>'RIGHT'),
                ),
                array(
                    'label'	=> __('Padding TOP', APS_PB_LANG),
                    'desc' 	=> __(' You can use % or px (example: 5% , 15px)<br>Don\'t use when the content is centered vertically', APS_PB_LANG),
                    'id' 	=> 'padding_top',
                    'type' 	=> 'input',
                    'value' => '',
                    //'required' => 'use_padding->yes'
                ),
                array(
                    'label'	=> __('Padding BOTTOM', APS_PB_LANG),
                    'desc' 	=> __(' You can use % or px (example: 5% , 15px)<br>Don\'t use when the content is centered vertically', APS_PB_LANG),
                    'id' 	=> 'padding_bottom',
                    'type' 	=> 'input',
                    'value' => '',
                    //'required' => 'use_padding->yes'
                ),
                array(
                    'label'	=> __('Padding LEFT', APS_PB_LANG),
                    'desc' 	=> __(' You can use % or px (example: 5% , 15px)', APS_PB_LANG),
                    'id' 	=> 'padding_left',
                    'type' 	=> 'input',
                    'value' => '',
                    'required' => 'container_width->padding,fullscreen'
                ),
                array(
                    'label'	=> __('Padding RIGHT', APS_PB_LANG),
                    'desc' 	=> __(' You can use % or px (example: 5% , 15px)', APS_PB_LANG),
                    'id' 	=> 'padding_right',
                    'type' 	=> 'input',
                    'value' => '',
                    'required' => 'container_width->padding,fullscreen'
                ),


                array(
                    'label'	=> __('USE BORDER', APS_PB_LANG),
                    'desc' 	=> __('You can define a border for the box', APS_PB_LANG),
                    'id' 	=> 'use_border',
                    'type' 	=> 'select',
                    'value' => 'no',
                    'options' => array('yes'=>'YES','no'=>'NO')
                ),
                array(
                    'label'	=>__('Border Type', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'border',
                    'type' 	=> 'select',
                    'value' => '',
                    'options' => array(
                        ''				=> 'NONE',
                        'all'		 	=> 'ALL',
                        'top'			=> 'TOP',
                        'bottom'		=> 'BOTTOM',
                        'left'			=> 'LEFT',
                        'right'			=> 'RIGHT',
                        'top-bottom'	=> 'TOP-BOTTOM',
                        'left-right' 	=> 'LEFT-RIGHT'
                    ),
                    'required' => 'use_border->yes'
                ),
                array(
                    'label'	=>__('Border Color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'border_color',
                    'type' 	=> 'colorpicker',
                    'value' => '',
                    'required' => 'use_border->yes'
                ),
                array(
                    'label'	=>__('Border Width', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'border_width',
                    'type' 	=> 'select',
                    'options' => $this->get_options_pixels(),
                    'value' => '',
                    'required' => 'use_border->yes'
                ),
                array(
                    'label'	=> __('TYPE OF BACKGROUND', APS_PB_LANG),
                    'desc' 	=> __('You can select color, image or pattern', APS_PB_LANG),
                    'id' 	=> 'bg_type',
                    'type' 	=> 'select',
                    'value' => 'transparent',
                    'options' => array(
                        'transparent'   => 'Background TRANSPARENT',
                        'color'		    =>'Background COLOR',
                        'image'		    =>'Background IMAGE',
                        'pattern'	    =>'Background PATTERN',
                        'gallery'        =>'Background GALLERY'
                        //'video'     =>'Background VIDEO'
                    )
                ),
                array(
                    'label'	=>__('Background Color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'bg_color',
                    'type' 	=> 'colorpicker',
                    'value' => '',
                    'required' => 'bg_type->color'
                ),
                array(
                    'label'	=> __('Background Image', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'bg_image',
                    'type' 	=> 'image_src',
                    'value' => '',
                    'button'=> 'Select Image',
                    'required' => 'bg_type->image'
                ),
                array(
                    'label'	=> __('Background Image Scroll', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'bg_image_scroll',
                    'type' 	=> 'select',
                    'value' => 'yes',
                    'required' => 'bg_type->image',
                    'options'   => array('scroll'=>'No scroll effect', 'fixed'=>'With scroll effect')
                ),

                array(
                    'label'	=> __('Background Pattern', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'bg_pattern',
                    'type' 	=> 'select',
                    'options' => $this->get_options_patterns(),
                    'value' => '',
                    'required' => 'bg_type->pattern'
                ),
                array(
                    'label'	=>__('Background Color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'bg_pattern_color',
                    'type' 	=> 'colorpicker',
                    'value' => '',
                    'required' => 'bg_type->pattern'
                ),
                array(
                    'label'	=> __('Background Gallery', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'bg_gallery',
                    'type' 	=> 'gallery',
                    'value' => '',
                    'button'=> 'Select Images',
                    'required' => 'bg_type->gallery'
                ),

                array(
                    'label'	=> __('CONTENT', APS_PB_LANG),
                    'desc' 	=> __('This is the content inside the shortcode. Just write some text now, you can add more content after in the rich editor', APS_PB_LANG),
                    'id' 	=> 'content_sc',
                    'type' 	=> 'textarea',
                    'value' => 'Some content goes here',
                )
            );
        }


        function get_options_pixels($min=1, $max=20)
        {
            $options = array();
            $options[''] = 'none';
            for ($i=$min; $i<=$max; $i++)
            {
                $options[$i.'px']=$i.'px';
            }
            return $options;
        }


        function get_options_patterns()
        {
            $options = array();
            $options[''] = __('No patterns. Please activate the theme',APS_PB_LANG);

            //Buscar los patrones que tiene el theme
            if (function_exists('aps_give_me_theme_patterns')){
                $options = aps_give_me_theme_patterns();
            }

            return $options;
        }

        function shortcode_handler($atts, $content='')
        {
            extract( shortcode_atts( array(
                'id'   					=> '',
                'class' 				=> '',
                'style' 				=> '',
                'use_border' 			=> 'no',
                'border'				=> '',
                'border_color'			=> '',
                'border_width'			=> '',
                'container_width'       => '',
                'container_height'      => '',
                'vertical_center'       => '',
                'height'                => '',
                'align'                 => '',
                'padding_top'			=> '',
                'padding_bottom' 		=> '',
                'padding_left'			=> '',
                'padding_right'			=> '',
                'bg_type'				=> 'color',
                'bg_color'				=> '',
                'bg_image_src'			=> '',
                'bg_image_id' 			=> '',
                'bg_image_size'			=> '',
                'bg_image_scroll'       => '',
                'bg_pattern'			=> '',
                'bg_pattern_color'      => '',
                'bg_gallery'            => ''
            ), $atts ) );

            $id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $class = ( $class != '' ) ? 'aps-content-strip ' . esc_attr( $class ) : 'aps-content-strip ';
            $style = ( $style != '' ) ? ' ' . $style : '';

            $style .= 'text-align:'.$align.';';


            //Border
            if ($use_border=='yes')
            {
                switch ( $border ) {
                    case 'top' :
                        $border = ' border-top';
                        break;
                    case 'left' :
                        $border = ' border-left';
                        break;
                    case 'right' :
                        $border = ' border-right';
                        break;
                    case 'bottom' :
                        $border = ' border-bottom';
                        break;
                    case 'top-bottom' :
                        $border = ' border-top border-bottom';
                        break;
                    case 'left-right' :
                        $border = ' border-left border-right';
                        break;
                    case 'all' :
                        $border = ' border-top border-left border-right border-bottom';
                        break;
                    default :
                        $border = '';
                }
                $border_color = ( $border_color != '' ) ? ' border-color: '.$border_color.';' : '';
                $border_width = ( $border_width != '' ) ? ' border-width: '.$border_width.';' : '';
            }
            else
            {
                $border = '';
                $border_color = '';
                $border_width = '';
            }

            //Corregir errores de usuario
            $padding_top    = $this->completar_numero_con_px( $padding_top );
            $padding_bottom = $this->completar_numero_con_px( $padding_bottom );
            $padding_left   = $this->completar_numero_con_px( $padding_left );
            $padding_right  = $this->completar_numero_con_px( $padding_right );

            $padding_top = ( $padding_top != '' ) ? ' padding-top: '.$padding_top.';' : '';
            $padding_bottom = ( $padding_bottom != '' ) ? ' padding-bottom: '.$padding_bottom.';' : '';
            $padding_left = ( $padding_left != '' ) ? ' padding-left: '.$padding_left.';' : '';
            $padding_right = ( $padding_right != '' ) ? ' padding-right: '.$padding_right.';' : '';

            if ($container_width == 'boxed') {
                $class .= ' selector'; //Para que le indique el ancho al container
                $padding_left = '';
                $padding_right = '';
            } else if ($container_width == 'padding') {

            }

            if ($container_height == 'normal') {

            } else if ($container_height == 'fullscreen') {
                $class .= ' fit-height-screen';
            } else if ($container_height == 'fullscreen_minus') {
                $class .= ' fit-height-screen minus-menu-height';
            } else if ($container_height == 'custom_height') {
                $style .= 'height:'.$height.';min-height:'.$height.';';
            }

            //$bg_color = ' background-color: transparent;';
            $bg_image_src_src = '';
            $bg_image_class = '';
            $bg_pattern_src = '';
            $bg_pattern_class = '';
            $html_video = '';

            if ($bg_type == 'transparent')
            {
                $bg_color = ' background-color: transparent;';

            }
            else if ($bg_type == 'color')
            {
                $bg_color = ( $bg_color != '' ) ? " background-color: {$bg_color};" : ' background-color: transparent;';

            }
            else if ($bg_type == 'image')
            {
                $bg_color = ' background-color: transparent;';
                $img_src = $this->get_image_from($bg_image_src,$bg_image_id,$bg_image_size);
                $bg_image_src_src = " background-image: url('{$img_src}');background-attachment:{$bg_image_scroll};";
                $bg_image_class = " bg-image" ;
            }
            else if ($bg_type == 'pattern')
            {
                //El pattern esta en el theme
                $pattern_path = get_template_directory_uri().'/includes/stylesheets/images/patterns/';
                $url_pattern = 'url('.$pattern_path.$bg_pattern.'.png)';

                if ( $bg_pattern != '' ) $bg_color = ' background-color: '.$bg_pattern_color.';';
                $bg_pattern_src = ( $bg_pattern != '' ) ? " background-image: {$url_pattern};" : '';
                $bg_pattern_class = ( $bg_pattern != '' ) ? " bg-pattern" : '';
            }
            else if ($bg_type == 'gallery')
            {
                $bg_color = ' background-color: transparent;';
                $class .= ' is-gallery';
            }


            if ($vertical_center == 'yes') { $class.= ' vertical-center '; }


            //html
            $html  = "<div {$id} class=\"{$class}{$border}{$bg_image_class}{$bg_pattern_class}\"";
            $html .= " style=\"{$style}{$padding_top}{$padding_bottom}{$padding_left}{$padding_right}{$border_color}{$border_width}{$bg_color}{$bg_image_src_src}{$bg_pattern_src}\">";

            if ($bg_type=='gallery') {
                $html .= $this->create_style_for_gallery($bg_gallery);
            }

            $html .= "<div class=\"aps-content-strip-inner\">";
            $html .= do_shortcode( $content );
            $html .= "</div>";

            $html .= "</div>";


            return $html;
        }


        function create_style_for_gallery($images_id)
        {
            $arr_id = explode(',',$images_id);
            if (empty($arr_id)) return '';
            $num = count($arr_id);

            static $count = 0;
            $count++;

            //El identificador para el estilo
            $id = 'big-slideshow-'.$count;
            $lapse = 6; //Numero de segundos por diapo

            //Es estilo
            $html = "<style>";


            //Primero la animacion
            $time = $lapse * count($arr_id);
            $name_anim = 'imageAnimation'.$count;
            $html .= "
            #{$id}.big-slideshow li {
                -webkit-animation: {$name_anim} {$time}s linear infinite 0s;
                  -moz-animation: {$name_anim} {$time}s linear infinite 0s;
                  -o-animation: {$name_anim} {$time}s linear infinite 0s;
                  -ms-animation: {$name_anim} {$time}s linear infinite 0s;
                  animation: {$name_anim} {$time}s linear infinite 0s;
            }
            ";
            $keys = array('@-webkit-','@-moz-','@-o-','@-ms-','@');
            $paso1 = 100/$num;
            $paso2 = $paso1/2;
            $paso3 = $paso1+10;
            foreach($keys as $key){
                $html .= "
                    {$key}keyframes {$name_anim} {
                      0% { opacity: 0; -webkit-animation-timing-function: ease-in; }
                      {$paso2}% { opacity: 1; -webkit-animation-timing-function: ease-out; }
                      {$paso1}% { opacity: 1 }
                      {$paso3}% { opacity: 0 }
                      100% { opacity: 0 }
                    }
                ";
            }




            //Ahora los delay
            $index=1;
            $delay = 0;
            foreach($arr_id as $attach_id)
            {
                $img_src = $this->get_image_from('',$attach_id,'full');
                $html .= "
                #{$id}.big-slideshow  li:nth-child({$index}) {
                  background-image: url('{$img_src}');
                  -webkit-animation-delay: {$delay}s;
                  -moz-animation-delay: {$delay}s;
                  -o-animation-delay: {$delay}s;
                  -ms-animation-delay: {$delay}s;
                  animation-delay: {$delay}s;
                }
                ";
                $index++;
                $delay += $lapse;
            }
            $html .= "</style>";


            //El listado de elementos para las imagenes
            $html .= "<ul id=\"{$id}\" class=\"big-slideshow\">";
            foreach($arr_id as $value)
            {
                $html .= '<li>image</li>';
            }
            $html .= "</ul>";


            return $html;
        }

    }
}