<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_content_wrap' ) ) 
{
	class aps_content_wrap extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Content Wrap',
				'shortcode' => 'aps_content_wrap',
                'tab' 		=> __('STRUCTURE',APS_PB_LANG),
				'order' 	=> 110
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',	
				),
				
				array(
					'label'	=>__('Description', APS_PB_LANG),
					'desc' 	=> __('This shortcode will wrap your content with a margin left and right.<br> Cannot be nested within the same shortcode.', APS_PB_LANG),
					'id' 	=> '',
					'type' 	=> 'description',	
					'value' => '',
					'class-wrap' => 'field-description',
					'class' => ''
				),
				
				array(
					'label'	=> __('WIDTH %', APS_PB_LANG),
					'desc' 	=> __('Introduce in % between 20% and 100%, example: 88% ( this will introduce a left and right margin of 6% each)', APS_PB_LANG),
					'id' 	=> 'width',
					'type' 	=> 'input',
					'value' => '88%',	
				),
				
				array(
					'label'	=> __('CONTENT', APS_PB_LANG),
					'desc' 	=> __('This is the content inside the shortcode. Just write some text now, you can add more content after in the rich editor', APS_PB_LANG),
					'id' 	=> 'content_sc',
					'type' 	=> 'textarea',
					'value' => 'Some content goes here',	
				)
			);
		}

		
		function shortcode_handler($atts, $content='')
		{
			extract( shortcode_atts( array(
			'id'    => '',
			'class' => '',
			'style' => '',
			'width' => '88%'
			), $atts ) );
			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? 'aps-content-wrap ' . esc_attr( $class ) : 'aps-content-wrap';
			$style = 'width:'.$width.';'.$style;
			
			$html = "<div {$id} class=\"{$class}\" style=\"{$style}\">" . do_shortcode( $content ) . "</div>";
			return $html;
		}
		
	}
}