<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_cubetitle' ) ) {
    class aps_cube_effect extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Rotation Title',
                'shortcode' => 'aps_cubetitle',
                'tab' => __('EFFECTS', APS_PB_LANG),
                'order' => 120,

            );
        }

        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' => 'id_class_style',
                ),
                array(
                    'label'	=> __('Size', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'size',
                    'type' 	=> 'select',
                    'value' => 'big',
                    'options' => array(
                        'big' => __('Big (140px)',APS_PB_LANG),
                        'medium' => __('Medium (90px)',APS_PB_LANG),
                        'small' => __('Small (50px)',APS_PB_LANG)
                    )
                ),
                array(
                    'label'	=>__('Font type', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'font',
                    'type' 	=> 'select',
                    'value' => 'heading',
                    'options' => array('heading'=>'Heading font', 'text'=>'Text font')
                ),
                array(
                    'label'	=> __('Width', APS_PB_LANG).' 1',
                    'desc' 	=> __('ex 100%, 300px', APS_PB_LANG),
                    'id' 	=> 'width',
                    'type' 	=> 'input',
                    'value' => '100%'
                ),
                array(
                    'label'	=> __('Delay in miliseconds', APS_PB_LANG),
                    'desc' 	=> __('Useful when you have more than one Rotation Title and don\'t want to rotate at the same time', APS_PB_LANG),
                    'id' 	=> 'delay',
                    'type' 	=> 'input',
                    'value' => '0'
                ),
                array(
                    'label'	=> __('Slogan', APS_PB_LANG).' 1',
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'text1',
                    'type' 	=> 'input',
                    'value' => 'SLOGAN TEXT 1'
                ),
                array(
                    'label'	=> __('Slogan', APS_PB_LANG).' 2',
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'text2',
                    'type' 	=> 'input',
                    'value' => 'SLOGAN TEXT 2'
                ),
                array(
                    'label'	=> __('Slogan', APS_PB_LANG).' 3',
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'text3',
                    'type' 	=> 'input',
                    'value' => 'SLOGAN TEXT 3'
                ),
                array(
                    'label'	=> __('Slogan', APS_PB_LANG).' 4',
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'text4',
                    'type' 	=> 'input',
                    'value' => 'SLOGAN TEXT 4'
                ),
                array(
                    'label'	=> __('Text Colors ?', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'colors',
                    'type' 	=> 'select',
                    'value' => 'default',
                    'options' => array(
                        'default' => __('All texts with default color',APS_PB_LANG),
                        'same' => __('All texts with same color',APS_PB_LANG),
                        'different' => __('Each text with different color',APS_PB_LANG)
                    )
                ),
                array(
                    'label'	=> __('Color texts', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'color',
                    'type' 	=> 'colorpicker',
                    'value' => '#cdcdcd',
                    'required' => 'colors->same'
                ),
                array(
                    'label'	=> __('Color text', APS_PB_LANG).' 1',
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'color1',
                    'type' 	=> 'colorpicker',
                    'value' => '#cdcdcd',
                    'required' => 'colors->different'
                ),
                array(
                    'label'	=> __('Color text', APS_PB_LANG).' 2',
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'color2',
                    'type' 	=> 'colorpicker',
                    'value' => '#cdcdcd',
                    'required' => 'colors->different'
                ),
                array(
                    'label'	=> __('Color text', APS_PB_LANG).' 3',
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'color3',
                    'type' 	=> 'colorpicker',
                    'value' => '#cdcdcd',
                    'required' => 'colors->different'
                ),
                array(
                    'label'	=> __('Color text', APS_PB_LANG).' 4',
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'color4',
                    'type' 	=> 'colorpicker',
                    'value' => '#cdcdcd',
                    'required' => 'colors->different'
                ),
                array(
                    'label'	=> __('Define background colors ?', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'bg_colors',
                    'type' 	=> 'select',
                    'value' => 'no',
                    'options' => array(
                        'no' => 'NO',
                        'yes' => 'YES'
                    )
                ),
                array(
                    'label'	=> __('Back Color text', APS_PB_LANG).' 1',
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'bg_color1',
                    'type' 	=> 'colorpicker',
                    'value' => 'white',
                    'required' => 'bg_colors->yes'
                ),
                array(
                    'label'	=> __('Back Color text', APS_PB_LANG).' 2',
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'bg_color2',
                    'type' 	=> 'colorpicker',
                    'value' => 'black',
                    'required' => 'bg_colors->yes'
                ),
                array(
                    'label'	=> __('Back Color text', APS_PB_LANG).' 3',
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'bg_color3',
                    'type' 	=> 'colorpicker',
                    'value' => 'white',
                    'required' => 'bg_colors->yes'
                ),
                array(
                    'label'	=> __('Back Color text', APS_PB_LANG).' 4',
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'bg_color4',
                    'type' 	=> 'colorpicker',
                    'value' => 'black',
                    'required' => 'bg_colors->yes'
                ),
            );
        }

        function shortcode_handler($atts, $content='')
        {
            extract(shortcode_atts(array(
                'id' => '',
                'class' => '',
                'style' => '',
                'size' => 'big', //medium,small
                'font'  => '',
                'width' => '100%',
                'delay' => '0',
                'colors' => 'default', //same,different
                'color' => '#cdcdcd',
                'text1'  => 'TEXT SLOGAN 1',
                'text2'  => 'TEXT SLOGAN 2',
                'text3'  => 'TEXT SLOGAN 3',
                'text4'  => 'TEXT SLOGAN 4',
                'color1' => '#cdcdcd',
                'color2' => '#cdcdcd',
                'color3' => '#cdcdcd',
                'color4' => '#cdcdcd',
                'bg_colors' => 'no',
                'bg_color1' => 'transparent',
                'bg_color2' => 'transparent',
                'bg_color3' => 'transparent',
                'bg_color4' => 'transparent',
            ), $atts));

            $id = ( $id != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';

            $style1 = '';
            $style2 = '';
            $style3 = '';
            $style4 = '';

            if ($colors == 'default') {

            } else if ($colors == 'same') {
                $style = 'color:'.$color.';'.$style;
                $style1 = $style2 = $style3 = $style4 = 'color:'.$color.';';

            } else {
                $style1 = 'color:'.$color1.';';
                $style2 = 'color:'.$color2.';';
                $style3 = 'color:'.$color3.';';
                $style4 = 'color:'.$color4.';';
            }

            if ($bg_colors=='yes'){
                $style1 .= 'background-color:'.$bg_color1.';';
                $style2 .= 'background-color:'.$bg_color2.';';
                $style3 .= 'background-color:'.$bg_color3.';';
                $style4 .= 'background-color:'.$bg_color4.';';
            }


            $style .= 'width:'.$width.';';

            $style1 = 'style="'.$style1.'"';
            $style2 = 'style="'.$style2.'"';
            $style3 = 'style="'.$style3.'"';
            $style4 = 'style="'.$style4.'"';

            $tag = 'div';
            if ($font=='heading') $tag='h2';

            $html  = "<div {$id} style=\"{$style}\" class=\"cube-effect cube-wrapper-{$size} {$class}\"";
            //if ($delay!='0' && $delay!='' & is_numeric($delay)){
                $html .= " data-delay=\"{$delay}\"";
            //}
            $html .= ">";
            $html .= "<div class=\"cube-inner\">";
            $html .= "<{$tag} class=\"cube-face cube-face-front\" {$style1}>{$text1}</{$tag}>";
            $html .= "<{$tag} class=\"cube-face cube-face-top\" {$style2}>{$text2}</{$tag}>";
            $html .= "<{$tag} class=\"cube-face cube-face-back\" {$style3}>{$text3}</{$tag}>";
            $html .= "<{$tag} class=\"cube-face cube-face-bottom\" {$style4}>{$text4}</{$tag}>";
            $html .= "</div>";
            $html .= "</div>";

            return $html;
        }

    }
}