<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }


if ( !class_exists( 'aps_cubetitle_letters' ) ) {
    class aps_cubetitle_letters extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Rotation Letters',
                'shortcode' => 'aps_cubetitle_letters',
                'tab' => __('EFFECTS', APS_PB_LANG),
                'order' => 130,

            );
        }

        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' => 'id_class_style',
                ),
                array(
                    'label'	=> __('Size', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'size',
                    'type' 	=> 'select',
                    'value' => 'big',
                    'options' => array(
                        'big' => __('Big (140px)',APS_PB_LANG),
                        'medium' => __('Medium (90px)',APS_PB_LANG),
                        'small' => __('Small (50px)',APS_PB_LANG)
                    )
                ),
                array(
                    'label'	=>__('Font type', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'font',
                    'type' 	=> 'select',
                    'value' => 'heading',
                    'options' => array('heading'=>'Heading font', 'text'=>'Text font')
                ),
                array(
                    'label'	=> __('Delay between letters', APS_PB_LANG),
                    'desc' 	=> __('ex: 1000 (is one second)', APS_PB_LANG),
                    'id' 	=> 'delay',
                    'type' 	=> 'input',
                    'value' => '100'
                ),
                array(
                    'label'	=> __('Letter width', APS_PB_LANG),
                    'desc' 	=> __('ex: 70px', APS_PB_LANG),
                    'id' 	=> 'letter_width',
                    'type' 	=> 'input',
                    'value' => '70px'
                ),
                array(
                    'label'	=> __('Slogan', APS_PB_LANG).' 1',
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'text1',
                    'type' 	=> 'input',
                    'value' => 'SLOGAN TEXT 1'
                ),
                array(
                    'label'	=> __('Slogan', APS_PB_LANG).' 2',
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'text2',
                    'type' 	=> 'input',
                    'value' => 'SLOGAN TEXT 2'
                ),
                array(
                    'label'	=> __('Slogan', APS_PB_LANG).' 3',
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'text3',
                    'type' 	=> 'input',
                    'value' => 'SLOGAN TEXT 3'
                ),
                array(
                    'label'	=> __('Slogan', APS_PB_LANG).' 4',
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'text4',
                    'type' 	=> 'input',
                    'value' => 'SLOGAN TEXT 4'
                ),
                array(
                    'label'	=> __('Colors for letters', APS_PB_LANG),
                    'desc' 	=> __('Insert several colors separated by commas', APS_PB_LANG),
                    'id' 	=> 'text_colors',
                    'type' 	=> 'input',
                    'value' => '#dd3366,#881267,#985721',
                ),
                array(
                    'label'	=> __('Back Colors for letters', APS_PB_LANG),
                    'desc' 	=> __('Insert several colors separated by commas', APS_PB_LANG),
                    'id' 	=> 'back_colors',
                    'type' 	=> 'input',
                    'value' => 'red,green,blue,yellow',
                ),
            );
        }

        function shortcode_handler($atts, $content='')
        {
            extract(shortcode_atts(array(
                'id' => '',
                'class' => '',
                'style' => '',
                'size' => 'big', //medium,small
                'letter_width' => '70px',
                'font'  => '',
                'width' => '60px',
                'delay' => '300',
                'text_colors' => 'black,white,gray',
                'back_colors' => '#ababab,#dedede',
                'text1'  => 'TEXT SLOGAN 1',
                'text2'  => 'TEXT SLOGAN 2',
                'text3'  => 'TEXT SLOGAN 3',
                'text4'  => 'TEXT SLOGAN 4'
            ), $atts));


            //Genera varios shortcodes seguidos a partir de los datos con aps_cubetitle
            //con un retraso entre cada letra y la siguiente

            //Numero de letras
            $max = max(strlen($text1),strlen($text2),strlen($text3),strlen($text4));

            //Rellenar con espacios a la derecha
            $text1 = str_pad($text1, $max);
            $text2 = str_pad($text2, $max);
            $text3 = str_pad($text3, $max);
            $text4 = str_pad($text4, $max);

            $text_colors = explode(',', $text_colors);
            $back_colors = explode(',',$back_colors);

            $shortcodes = '';
            $retraso = 0;

            //echo '<pre>'; print_r( $max ); echo '</pre>';
            //echo '<pre>'; print_r( $text_colors ); echo '</pre>';
            //echo '<pre>'; print_r( $back_colors ); echo '</pre>';


            for ($i=0; $i<$max; $i++){
                $t1 = $text1[$i];
                $t2 = $text2[$i];
                $t3 = $text3[$i];
                $t4 = $text4[$i];

                $c1 = $text_colors[ array_rand($text_colors,1) ];
                $c2 = $text_colors[ array_rand($text_colors,1) ];
                $c3 = $text_colors[ array_rand($text_colors,1) ];
                $c4 = $text_colors[ array_rand($text_colors,1) ];

                $bc1 = $back_colors[ array_rand($back_colors,1) ];
                $bc2 = $back_colors[ array_rand($back_colors,1) ];
                $bc3 = $back_colors[ array_rand($back_colors,1) ];
                $bc4 = $back_colors[ array_rand($back_colors,1) ];

                $sc = "[aps_cubetitle size='{$size}' font='{$font}' width='{$letter_width}' delay='{$retraso}' text1='{$t1}' text2='{$t2}' text3='{$t3}' text4='{$t4}' ";
                $sc .= "colors='different' color1='{$c1}' color2='{$c2}' color3='{$c3}' color4='{$c4}' bg_colors='yes' bg_color1='{$bc1}' bg_color2='{$bc2}' bg_color3='{$bc3}' bg_color4='{$bc4}']";
                $retraso += (integer)$delay;

                $shortcodes .= ' '.$sc;
            }


            $html = do_shortcode( $shortcodes );

            return $html;
        }
    }
}