<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_dropcap' ) ) 
{
	class aps_dropcap extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Dropcap',
				'shortcode' => 'aps_dropcap',
                'tab' 		=> __('CONTENT',APS_PB_LANG),
				'order' 	=> 50,
                'use_line_break' => 'no'
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',	
				),


                array(
                    'label' => __('With Background Color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'use_bg_color',
                    'type' 	=> 'select',
                    'value' => 'no',
                    'options' => array('no'=>'No','yes'=>'Yes')
                ),

				array(
					'label' => __('Background Color', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'bg_color',
					'type' 	=> 'colorpicker',
					'value' => 'white',
                    'required' => 'use_bg_color->yes'
				),
				array(
					'label' => __('Text color', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'text_color',
					'type' 	=> 'colorpicker',
					'value' => '#ffffff',
				),
				array(
					'label' => __('Content', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'content_wrap',
					'type' 	=> 'input',
					'value' => 'A',
				),
			);
		}
				
		function shortcode_handler($atts, $content='')
		{
		  extract( shortcode_atts( array(
		    'id'    => '',
		    'class' => '',
		    'style' => '',
            'use_bg_color' => '',
		    'bg_color' => 'transparent',
		    'text_color' => ''
		  ), $atts ) );


		  $id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
		  $class = ( $class != '' ) ? 'aps-dropcap ' . esc_attr( $class ) : 'aps-dropcap';
		  $style = ( $style != '' ) ? ' ' . $style : '';

          if ( $use_bg_color == 'yes' && $bg_color != '' )
          {
              $bg_color = ( $bg_color != '' ) ? " background-color:{$bg_color};" : '';
              $bg_color = " background-color:{$bg_color};";
          } else {
              $bg_color = " background-color:transparent;";
          }

		  $text_color = ( $text_color != '' ) ? " color:{$text_color};" : '';
		  
		  $html = "<span {$id} class=\"{$class}\" style=\"{$style}{$bg_color}{$text_color}\">{$content}</span>";
		  return $html;
		}
		
	}
}