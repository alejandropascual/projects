<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_fittext' ) ) {
    class aps_fittext extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Responsive Title',
                'shortcode' => 'aps_fittext',
                'tab' => __('EFFECTS', APS_PB_LANG),
                'order' => 130,
                'direct_insert' => "[aps_fittext coef='1.0' min-font='12px' max-font='100px']THIS IS MY TITLE[/aps_fittext]"
            );
        }

        function modal_fields()
        {

        }

        function shortcode_handler($atts, $content='')
        {
            extract(shortcode_atts(array(
                'id' => '',
                'class' => '',
                'style' => '',
                'coef' => '1.0',
                'min_font' => '',
                'max_font' => '',
                'font' => 'text' // text
            ), $atts));

            $id = ( $id != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $class = ( $id != '' ) ? esc_attr($class) : '' ;
            $style = ($style !='') ? 'style="'.$style.'"' : '';

            $tag = 'div';
            if ($font=='heading') { $tag = 'h2'; }

            $html = "<{$tag} {$id} {$style} class=\"aps-fittext {$class}\"";

            $html .= " data-fit=\"{$coef}\" data-min_font=\"{$min_font}\" data-max_font=\"{$max_font}\"";
            $html .= ">";
            $html .= do_shortcode( apply_filters('the_content', $content) );
            $html .= "</{$tag}>";

            return $html;
        }
    }
}