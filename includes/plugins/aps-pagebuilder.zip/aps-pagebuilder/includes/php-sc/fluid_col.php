<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_fluidcol' ) ) 
{
	class aps_fluidcol extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Fluid columns',
				'shortcode' => 'aps_fluidcol',
                'tab' 		=> __('STRUCTURE',APS_PB_LANG),
				'order' 	=> 130
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',	
				),
				
				
				array(
					'label' => __('Background Color', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'type',
					'type' 	=> 'select',
					'value' => 'three-up',
					'options' => array(
						'two-up' 	=> '2 columns',
						'three-up' 	=> '3 columns',
						'four-up' 	=> '4 columns',
						'five-up' 	=> '5 columns',
						'six-up' 	=> '6 columns',
						'seven-up' 	=> '7 columns',
						'eight-up' 	=> '8 columns',
						'nine-up' 	=> '9 columns',
						'tem-up' 	=> '10 columns',
					)
				),
				
				array(
					'label' => __('Content', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'content_wrap',
					'type' 	=> 'tinymce',
					'value' => 'The content here',
				)
			);
		}
				
		function shortcode_handler($atts, $content='')
		{
			extract( shortcode_atts( array(
			'id'    => '',
			'class' => '',
			'style' => '',
			'type'	=> 'two-up'
			), $atts ) );
			
			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? 'aps-fluid-col ' . esc_attr( $class ) : 'aps-fluid-col';
			$style = ( $style != '' ) ? 'style="' . $style . '"' : '';
			
			$html = "<div {$id} class=\"{$class} {$type}\" {$style}>" . do_shortcode( $content ) . "</div>";
			
			return $html;
		}
		
	}
}