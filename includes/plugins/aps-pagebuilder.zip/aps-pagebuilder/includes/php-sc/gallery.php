<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_gallery' ) ) {

    class aps_gallery extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' 		=> 'Gallery of Images',
                'shortcode' => 'aps_gallery',
                'tab' 		=> __('GALLERIES',APS_PB_LANG),
                'order' 	=> 130,
            );

        }

        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),
                //Select images
                array(
                    'label'	=> __('Select images', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'ids',
                    'type' 	=> 'gallery',
                    'value' => '',
                    'button' => __('Select images',APS_PB_LANG)
                ),

                // Type of gallery
                array(
                    'label' => __('Type of gallery', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'type',
                    'type'  => 'select',
                    'value' => 'masonry_image',
                    'options' => array(
                        'masonry_image'                     => 'Masonry',
                        'grid_image'                        => 'Grid',
                        'justified_grid_image'              => 'Justified grid image',
                        'gallery_image'                     => 'Slider',
                        'fullwidth_image'                   => 'Fullwidth image'
                    )
                ),


                //Masonry
                array(
                    'label' => __('Image width in pixels', APS_PB_LANG),
                    'desc'  => __('example: 300', APS_PB_LANG),
                    'id'    => 'masonry_width',
                    'type'  => 'input',
                    'value' => 300,
                    'required' => 'type->masonry_image'
                ),
                array(
                    'label' => __('Separation between elements in pixels', APS_PB_LANG),
                    'desc'  => __('example: 2', APS_PB_LANG),
                    'id'    => 'masonry_margin',
                    'type'  => 'input',
                    'value' => 2,
                    'required' => 'type->masonry_image'
                ),

                //Grid
                array(
                    'label' => __('Grid columns', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'grid_cols',
                    'type'  => 'select',
                    'required' => 'type->grid_image',
                    'options' => array('2'=>'2', '3'=>'3', '4'=>'4', '5'=>'5', '6'=>'6')
                ),
                array(
                    'label' => __('Image width in pixels', APS_PB_LANG),
                    'desc'  => __('example: 300', APS_PB_LANG),
                    'id'    => 'grid_width',
                    'type'  => 'input',
                    'value' => 300,
                    'required' => 'type->grid_image',
                ),
                array(
                    'label' => __('Separation between elements in pixels', APS_PB_LANG),
                    'desc'  => __('example: 2', APS_PB_LANG),
                    'id'    => 'grid_padding',
                    'type'  => 'input',
                    'value' => 2,
                    'required' => 'type->grid_image',
                ),
                array(
                    'label' => __('Ratio image vertical/horizontal', APS_PB_LANG),
                    'desc'  => __('examples: 1 (square)<br>0.5 (landscape)<br>2 (vertical)', APS_PB_LANG),
                    'id'    => 'grid_ratio',
                    'type'  => 'input',
                    'value' => 0.75,
                    'required' => 'type->grid_image',
                ),

                //Justified grid
                array(
                    'label' => __('Column height en pixels', APS_PB_LANG),
                    'desc'  => __('example: 300', APS_PB_LANG),
                    'id'    => 'jgrid_height',
                    'type'  => 'input',
                    'value' => 300,
                    'required' => 'type->justified_grid_image',
                ),
                array(
                    'label' => __('Separation between elements in pixels', APS_PB_LANG),
                    'desc'  => __('example: 1', APS_PB_LANG),
                    'id'    => 'jgrid_padding',
                    'type'  => 'input',
                    'value' => 1,
                    'required' => 'type->justified_grid_image',
                ),

                //Slider
                array(
                    'label' => __('Slider: Image width in pixels', APS_PB_LANG),
                    'desc'  => __('example: 800', APS_PB_LANG),
                    'id'    => 'gallery_width',
                    'type'  => 'input',
                    'value' => 800,
                    'required' => 'type->gallery_image,gallery_image_and_text',
                ),
                /*array(
                    'label' => __('Slider full-screen', APS_PB_LANG),
                    'desc'  => __('This will force the height of the slider to the height of the screen (minus header height)', APS_PB_LANG),
                    'id'    => 'gallery_fullscreen',
                    'type'  => 'select_yes_no',
                    'value' => 'no',
                    'required' => 'type->gallery_image,gallery_image_and_text',
                ),*/
                array(
                    'label' => __('Slider: Image height in pixels', APS_PB_LANG),
                    'desc'  => __('example: 500', APS_PB_LANG),
                    'id'    => 'gallery_height',
                    'type'  => 'input',
                    'value' => 500,
                    'required' => 'type->gallery_image,gallery_image_and_text',
                ),
                array(
                    'label' => __('Slider: Image mode', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'gallery_mode',
                    'type'  => 'select',
                    'required' => 'type->gallery_image,gallery_image_and_text',
                    'options' => array(
                        'fill' => 'Fill: image will expand to fill the slider container',
                        'fit' => 'Fit: image will fit inside the slider container'
                    )
                ),
                array(
                    'label' => __('Slider Transition', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'gallery_transition',
                    'type'  => 'select',
                    'value' => 'move',
                    'required' => 'type->gallery_image,gallery_image_and_text',
                    'options' => array('move'=>'Move', 'fade'=>'Fade')
                ),
                array(
                    'label' => __('Slider Autoplay', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'gallery_autoplay',
                    'type'  => 'select_yes_no',
                    'value' => 'yes',
                    'required' => 'type->gallery_image,gallery_image_and_text',
                ),
                array(
                    'label' => __('Slider Show Buttons', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'gallery_show_buttons',
                    'type'  => 'select_yes_no',
                    'value' => 'no',
                    'required' => 'type->gallery_image,gallery_image_and_text',
                ),
                array(
                    'label' => __('Slider Show Bullets', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'gallery_show_points',
                    'type'  => 'select_yes_no',
                    'value' => 'no',
                    'required' => 'type->gallery_image,gallery_image_and_text',
                ),
                /*array(
                    'label' => __('Slider: Display post excerpt', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'gallery_text_desc',
                    'type'  => 'select_yes_no',
                    'required' => 'type->gallery_image_and_text',
                    'options' => array(
                        'yes' => 'Yes, display below the title',
                        'no' => 'No'
                    )
                ),
                */

                //Fullwidth image
                array(
                    'section'	=> 'sec_opciones_project_archive',
                    'label' => __('Image width in pixels', APS_PB_LANG),
                    'desc'  => __('example: 800', APS_PB_LANG),
                    'id'    => 'fullwidth_width',
                    'type'  => 'input',
                    'value' => 800,
                    'required' => 'type->fullwidth_image',
                ),
                array(
                    'section'	=> 'sec_opciones_project_archive',
                    'title' => 'Image height in pixels',
                    'desc'  => __('Example: 400 or <br>Leave it blank if you do not want to crop the image.', APS_PB_LANG),
                    'id'    => 'fullwidth_height',
                    'type'  => 'input',
                    'value' => 400,
                    'required' => 'type->fullwidth_image',
                ),

                //DISPLAY
                array(
                    'label' => __('Display border', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'with_border',
                    'type'  => 'select_yes_no',
                    'value' => 'yes',
                    'required' => 'type->masonry_image,grid_image,justified_grid_image,fullwidth_image',
                ),

            );
        }

        function shortcode_handler($atts, $content = null)
        {
            $sc = "[aps_gallery_template post_type='post' select_by='by_images' image_direct_link='yes'";

            foreach( $atts as $key=>$value)
            {
                if ($key=='ids') { $key = 'image_ids';}
                $sc .= " {$key}='{$value}'";
            }

            $sc .= "]";

            return do_shortcode($sc);
        }
    }
}