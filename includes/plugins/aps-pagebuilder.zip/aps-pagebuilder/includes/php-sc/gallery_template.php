<?php

/*
 * Permite difirentes tipos de galerias con diversas fuentes
 * Admite paginacion con numeros y con load-more
 *   con numero añade /page/? a la url, y el propio shortcode lo reconoce
 *   no se debe tener mas de un shortcode dentro de la pagina para que no de problema el paging
 *   esto se soluciona creando sl shortcode a traves del page template
 */


// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_gallery_template' ) ) {

    class aps_gallery_template extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Image Gallery for template',
                'shortcode' => 'aps_gallery_template',
                //'tab' => __('Media', APS_PB_LANG),
                //'order' => 110,
                'hidden' => 'yes'
                //'direct_insert' => "[aps_gallery ids='']"
            );

        }

        function modal_fields()
        {

        }

        function shortcode_handler( $atts, $content = null )
        {
            /* posibilidades de galerias:

                masonry_image (isotope) (numbers or ajax)
                masonry_image_and_text (isotope) (numbers or ajax)
                grid_image (isotope) (numbers or ajax)
                grid_image_and_text (isotope) (numbers or ajax)
                justified_grid_image (collageplus) (ajax)
                list_image_and_text
                list_image_and_text_alternate

                //flexslider (woothemes) (none)
                gallery_image (royalslider) (none)
                gallery_image_and_text (royalslider) (none)

                fullwidth_image

            */


            $array_atts = shortcode_atts( array(
                'id'     => '',
                'class'  => '',
                'style'  => '',

                //Tipo de galeria ****************
                'type' => 'list_image_and_text_alternate',
                //********************************

                //Resize images
                'ampliar' => 'no', // Forzar ampliar la imagen por seguridad

                //Datos especificos de cada galeria
                'masonry_width' => 300,
                'masonry_margin' => 0,

                'grid_cols' => 2,
                'grid_width' => 300, //Esto se puede calcular en funcion del numero de columnas
                'grid_padding' => 0,
                'grid_ratio' => 0.50,

                'jgrid_height' => 300,
                'jgrid_padding' => 0,

                'gallery_width' => 1050, //Sirve para el ancho de la imagen, la imagen mantiene su proporcion natural
                'gallery_height' => 600, //Esto es solo para la proporcion del royalslider, no afecta para recortar la imagen
                'gallery_mode' => 'fill',
                'gallery_text_desc' => 'no',
                'gallery_fullscreen' => 'no',//Permite ajustar la altura a la de la pantalla-menu
                'gallery_transition' => 'move', //fade
                'gallery_autoplay' => 'no',
                'gallery_show_buttons' => 'yes',
                'gallery_show_points' => 'no',

                'list_width' => 250,
                'list_ratio' => 0.40,

                'fullwidth_width' => 800,
                'fullwidth_height' => '', //en blanco para mantener proporcion natural

                //Style
                'with_border' => 'yes',
                'display_link_post' => 'yes',
                'display_link_lightbox' => 'yes',
                'display_link_external' => 'yes',
                'display_curtain_text' => 'yes',

                //yes hace que la cortina desaparezca,
                // salta al lightbox al pulsar la imagen
                //Se usa para las galerias de imagenes simples
                //por ejemplo dentro del proyecto
                'image_direct_link' => 'no',
                'image_direct_link_show_caption' => 'yes',

                //post
                'post_type' => 'post', //post,aps_project
                //'categories_post' =>'category::uncategorized,category::digital',
                //'tags_post' => 'post_tag::informatica,post_tag::wifi',
                'categories_post' => '',
                'tags_post' => '',

                //aps_project
                //'post_type' => 'aps_project',
                'categories_aps_project' => '',
                'tags_aps_project' => '',

                //Si esta relleno no se usan los filtros para obtener los posts
                //sino directamente estos ids, ya sean post, aps_project, o media
                //post_per_page se pone a -1
                //No puedo mezclar post con aps_project, se detecta el post_type con el primer id
                'select_by' => 'by_filter',// by_filter , by_ids, by_images
                'post_ids' => '',//'416,417',
                'image_ids' => '',//Directamente las imagenes
                'query_relation' => 'AND', //OR

                //yes : entonces coje la galeria de imagenes en vez del thumbnail
                //aqui paging no vale porque no lo he preparado todavia
                //post_per_page se pone a -1
                'use_gallery_of_post' => 'no',

                //general
                'posts_per_page' => -1, //-1
                'page_number' => 1,
                'paging_type' => 'ajax', //numbers,ajax,none, no todos son aplicables
                'orderby' => 'date',
                'order' => 'DESC',
                'current_url' => '' //Usar este si existe para la paginacion

                //'number_words' => 55 //pendiente añadirle esta opcion, ver como esta hecho en los archivos de los projectos

            ), $atts );

            extract( $array_atts );

            //echo '<pre>'; print_r( $atts ); echo '</pre>';
            //echo '<pre>'; print_r( $array_atts ); echo '</pre>';


            ///////////////////////////////////////////////
            // PAGINATION -1 / numbers -> paged
            ///////////////////////////////////////////////


            //Sin paginacion cojo todos
            if ($paging_type == 'none') {
                //$posts_per_page = -1;
            }

            //Establecer la pagina a partir de la url
            if ($paging_type == 'numbers')
            {
                global $paged;
                if(get_query_var('paged')) {
                    $paged = get_query_var('paged');
                } else if (get_query_var('page')) {
                    $paged = get_query_var('page');
                } else {
                    $paged = 1;
                }
                if ($paged>1) {
                    $page_number = $paged;
                }
            }


            ///////////////////////////////////////////////
            // ID, CLASS, STYLE
            ///////////////////////////////////////////////

            $id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $class = ( $class != '' ) ? esc_attr( $class ) : '';
            $style = ( $style != '' ) ? esc_attr( $style ) : '';



            ///////////////////////////////////////////////
            // TEMPLATE ?
            ///////////////////////////////////////////////

            //Obtener template
            $templates = $this->get_templates();
            $tmpl = $templates[$type];
            if ($type=='gallery_image_and_text' && $gallery_text_desc=='yes'){
                $tmpl = $templates['gallery_image_and_text_2'];
            }



            ///////////////////////////////////////////////
            // LINKS OCULTOS
            ///////////////////////////////////////////////

            //Definir datos css
            $class_wrapper = 'gallery-the-elements-inner popup-gallery '; //Para lightbox
            $class_wrapper .= $with_border == 'yes' ? '' : 'hidden-border ';
            $class_wrapper .= $display_link_post == 'yes' ? '' : 'hidden-link-post ';
            $class_wrapper .= $display_link_lightbox == 'yes' ? '' : 'hidden-link-ligthbox ';
            $class_wrapper .= $display_link_external == 'yes' ? '' : 'hidden-link-external ';
            $class_wrapper .= $display_curtain_text == 'yes' ? '' : 'hidden-curtain-content ';


            $data_wrapper = '';
            $el_begin = '';
            $el_end = '';
            $class_article = 'post post-grid isotope-item';
            $style_article = '';




            ///////////////////////////////////////////////
            // IMAGE DIRECT LINK
            ///////////////////////////////////////////////


            //Image direct link
            if ( $image_direct_link == 'yes' ){
                $class_article .= ' image-direct-link-yes';
            } else {
                $class_article .= ' image-direct-link-no';
            }

            ///////////////////////////////////////////////
            // TAMAÑO DE LAS IMAGENES segun tipo de galeria
            ///////////////////////////////////////////////

            //Para resize image sobre la marcha
            $resize_w = 300;
            $resize_h = 0;
            $resize_p = 0;
            $resize_aumentar = $ampliar;

            //El tamaño necesario de las imagenes lo tengo que calcular en funcion
            //de la galeria que voy a utilizar

            //Masonry define el ancho del elemento y el margen
            if ( $type == 'masonry_image' || $type == 'masonry_image_and_text' ){

                $class_wrapper .= 'isotope';
                $style_article .= 'width:'.$masonry_width.'px;margin:'.$masonry_margin.'px;'; //ancho fijo del elemento, margin para crear separacion
                $resize_w = $masonry_width; //Fijar un ancho, proporcion natural
                $resize_h = 0;
                $resize_p = 0;

            //Grid define el numero de columnas
            } else if ( $type == 'grid_image' || $type == 'grid_image_and_text' ) {

                $class_wrapper .= 'isotope grid width-'.$grid_cols.'cols'; //Definir numero de columnas, css en %
                $style_article .= 'padding:'.$grid_padding.'px;'; //padding para crear separacion
                $resize_w = $grid_width; //Fijar un ancho
                $resize_h = floatval($grid_ratio) * floatval($grid_width);
                $resize_p = 0 ; //Fijar una proporcion

            //Justified grid
            } else if ($type == 'justified_grid_image') {

                $class_wrapper .= 'justified-grid hidden-border'; //El borde entorpece el encaje
                $data_wrapper .= 'data-padding="'.$jgrid_padding.'" data-target_height="'.$jgrid_height.'"';
                $style_article .= ''; //padding para crear separacion va en el script
                $resize_w = 0;
                $resize_h = $jgrid_height; //Fijar una altura, proporcion natural
                $resize_p = 0;

            //Gallery image
            //Gallery text, para poner p.ejemplo el titulo del post y linkar a el
            } else if ($type == 'gallery_image' || $type == 'gallery_image_and_text') {

                $class_wrapper .= 'sliderContainer fullWidth clearfix hidden-border';
                $data_wrapper .= 'data-rs-width="'.$gallery_width.'" data-rs-height="'.$gallery_height.'" data-rs-mode="'.$gallery_mode.'" data-fullscreen="'.$gallery_fullscreen.'"';
                $data_wrapper .= ' data-rs-transition="'.$gallery_transition.'" data-rs-autoplay="'.$gallery_autoplay.'" data-rs-show_buttons="'.$gallery_show_buttons.'" data-rs-show_points="'.$gallery_show_points.'"';
                $el_begin = '<div class="shortcode-royalSlider royalSlider heroSlider rsMinW">';
                $el_end = '</div>';
                $resize_w = $gallery_width; //Fijar un ancho
                $resize_h = 0;
                $resize_p = 0;


            //List with text
            } else if ($type == 'list_image_and_text' || $type == 'list_image_and_text_alternate') {
                $class_wrapper .= 'gallery-list';
                $resize_w = $list_width; //Fijar un ancho
                $resize_h = floatval($list_ratio) * floatval($list_width);
                $resize_p = 0; //Fijar una proporcion


            //Fullwidth
            } else if ($type == 'fullwidth_image') {

                if ($fullwidth_height != '') {
                    $class_wrapper .= 'fullwidth-list';
                    $resize_w = $fullwidth_width;
                    $resize_h = $fullwidth_height;
                    $resize_p = 0;
                } else {
                    $resize_w = $fullwidth_width;
                    $resize_h = 0;
                    $resize_p = 0;
                }
            }

            //HTML
            $html = '';



            ///////////////////////////////////////////////
            // FILTROS
            ///////////////////////////////////////////////

            //SI es ajax solo tengo que devolver los elementos, sin la envolvente ni filtros
            // a partir de la pagina 1

            if ( $page_number < 2 || ($paging_type !== 'ajax' && $paging_type !== 'scroll') || $select_by == 'by_images' ) {

                //$html .= '<h1>MOSTRAR FILTROS</h1>';
                //$html .= "<p>TYPE:{$type}</p>";
                //$html .= "<p>POST TYPE:{$post_type}</p>";

                //$html .= "<p>Categories post: {$categories_post}</p>";
                //$html .= "<p>Tags post:{$tags_post}</p>";
                //$html .= "<p>Categories aps_project: {$categories_aps_project}</p>";
                //$html .= "<p>Tags aps_project:{$tags_aps_project}</p>";

                //wrapper
                $html .= '<div class="aps-gallery-template clearfix filters-grid-wrapper type-' . $type . '">';

                if ( $type == 'masonry_image' || $type == 'masonry_image_and_text' ||
                     $type == 'grid_image' || $type == 'grid_image_and_text' ||
                     $type == 'list_image_and_text' || $type == 'list_image_and_text_alternate' )
                {
                    if ($post_type == 'post') {
                        $html .= $this->create_html_filter($categories_post, $tags_post);
                    } else if ($post_type == 'aps_project') {
                        $html .= $this->create_html_filter($categories_aps_project, $tags_aps_project);
                    }
                }

                //$html .= '<h1>TERMINAR FILTROS</h1>';

                ///////////////////////////////////////////////
                // Iniciar LISTADO DE ELEMENTOS
                ///////////////////////////////////////////////

                //Tiene que estar aqui dentro para poderlo usar tambien desde ajax
                //y que el ajaz no me saque los filtros, sino solo los elementos

                //los elementos
                if ($type=='masonry_image' || $type=='masonry_image_and_text') {
                    $style .= 'padding-top:20px; padding-bottom:20px;';
                }
                else if ($type=='grid_image' || $type=='grid_image_and_text') {
                    $style .= 'padding:'.$grid_padding.'px;';
                }
                else if ($type=='justified_grid_image') {
                    $style .= 'padding:'.$jgrid_padding.'px; padding-bottom:0px;';
                }

                // COMIENZO ELEMENTS
                $html .= "<div {$id} style=\"{$style}\" class=\"gallery-the-elements clearfix {$class}\">";
                $html .= '<div class="' . $class_wrapper . ' selector aps_animated aps_fadeInUp" data-adelay="500" ' . $data_wrapper . '>';
                $html .= $el_begin;

            }









            ///////////////////////////////////////////////
            // Tamaño Imagenes
            ///////////////////////////////////////////////

            //Para resize las imagenes
            $resize_data = array(
                'width'     => $resize_w,
                'height'    => $resize_h,
                'prop'      => $resize_p,
                'aumentar'  => $resize_aumentar
            );
            //echo '<pre>'; print_r( $resize_data ); echo '</pre>';





            ///////////////////////////////////////////////
            // IMAGENES directamente
            ///////////////////////////////////////////////

            //No necesito consulta si paso los ids de las imagenes directamente
            if ( $select_by == 'by_images' )
            {
                $thumbs_ids = explode(',', $image_ids);

                foreach($thumbs_ids as $thumb_id)
                {
                    $item = $this->get_array_data_for_image($thumb_id,$resize_data,$type);
                    $item['class_article']   = $class_article;
                    $item['style_article']   = $style_article;
                    $html_item = $this->render_template($tmpl, $item);
                    //echo '<pre>'; print_r( $item ); echo '</pre>';
                    $html .= $html_item;
                }
            }


            ///////////////////////////////////////////////
            // Preparar CONSULTA Posts
            ///////////////////////////////////////////////
            else
            {


                //Obtener los datos de la DB
                $query_data = array(
                    'post_type'         => $post_type,
                    'posts_per_page'    => $posts_per_page,
                    'paged'             => $page_number,
                    'orderby'           => $orderby,
                    'order'             => $order,
                    'post_status'       => 'publish',
                );


                // Que filtros uso segun post type
                //-----------------------------------------------

                $filter_categories = '';
                $filter_tags = '';
                if ($post_type == 'post') {
                    $filter_categories = $categories_post;
                    $filter_tags = $tags_post;
                } else if ($post_type == 'aps_project') {
                    $filter_categories = $categories_aps_project;
                    $filter_tags = $tags_aps_project;
                }

                // Consultar posts especificos
                //-----------------------------------------------

                if ($select_by == 'by_ids' && $post_ids != '')
                {
                    $post_ids = explode(',',$post_ids);
                    $query_data['post_type'] = get_post_type($post_ids[0]);
                    $query_data['post__in'] = $post_ids;
                    $query_data['posts_per_page'] = -1;
                    $query_data['paged'] = 1;
                    $page_number = 1;
                    $filter_categories = '';
                    $filter_tags = '';
                }

                // Paged segun 1 imagen o varias por post (thumb/gallery)
                //-----------------------------------------------

                $thumb_or_gallery = 'thumb';
                if ( $use_gallery_of_post == 'yes' )
                {
                    $thumb_or_gallery = 'gallery';
                }
                if ( $use_gallery_of_post == 'yes' || $type == 'gallery_image' || $type == 'gallery_image_and_text')
                {
                    $query_data['posts_per_page'] = -1; //La galeria la forman todos, no hay paging
                    $query_data['paged'] = 1;
                    $page_number = 1;
                }

                //echo '<pre>'; print_r( $query_data ); echo '</pre>';

                // QUERY
                //-----------------------------------------------

                $result = $this->query_posts_data($type, $thumb_or_gallery, $query_data, $filter_categories, $filter_tags, $resize_data, $query_relation);
                //echo '<h1>NUMERO DE POSTS = '. count($result['my_posts']) .'</h1>';
                $my_posts = $result['my_posts'];
                $my_posts_number = count( $result['my_posts'] );
                $max_num_pages = $result['max_num_pages'];


                ///////////////////////////////////////////////
                // RENDER cada post
                ///////////////////////////////////////////////

                foreach($my_posts as $item){
                    $item['class_article']   = $class_article.' '.$item['filter'];
                    $item['style_article']   = $style_article;
                    $html_item = $this->render_template($tmpl, $item);
                    $html .= $html_item;
                    /*if (defined('DOING_AJAX') && DOING_AJAX) {
                        $ajax_articles[] = $html_el;
                    }*/
                }
            }




            ///////////////////////////////////////////////
            // ECHAR PAGINACION
            ///////////////////////////////////////////////

            //$html .= '<h1>Pnumb = '.$page_number.'</h1>';

            if ( $page_number < 2 || ($paging_type !== 'ajax' && $paging_type !== 'scroll') || $select_by == 'by_images' ) {

                //FINAL ELEMENTS
                $html .= $el_end;
                $html .= '</div>';
                $html .= '</div>';

                //Para determinadas galerias no se puede usar paginacion
                if ($type != 'flexslider' && $type != 'gallery_image' && $type != 'gallery_image_and_text' && $select_by != 'by_images')
                {
                    //pagination, solo si hay mas de una pagina
                    //if ($max_num_pages > $page_number)
                    if ($max_num_pages > 1)
                    {

                        //PAGINACION CON NUMEROS
                        if ($paging_type == 'numbers')
                        {
                            $html .= '<div class="gallery-the-paging numbers pagination-numbers">';
                            $html .= '<ul>';

                            //Saber de antemano que tipo de esturctura uso
                            $perma_selection = get_option('permalink_structure');

                            //Tengo que usar la url de la pagina actual ?
                            //por ejemplo en archivos de projectos y en sus taxonomias
                            if ($current_url == 'yes')
                            {
                                global $wp;
                                global $wp_query;
                                $query = $wp_query->query;
                                unset($query['page']); //No quiero usarla repetida

                                //Url normal   ../?post_type=aps_project  ../?project_category=graphics
                                if ($perma_selection=='')
                                {
                                    $url = home_url(add_query_arg($query, $wp->request));
                                    $permalink = $url;
                                }
                                //Url nice   ../project   ../project_category/graphics
                                else
                                {
                                    $url = home_url(add_query_arg(array(),$wp->request));
                                    //echo '<pre>'; print_r( $url ); echo '</pre>';
                                    $url = preg_replace('#\/page\/.+#','',$url);
                                    $permalink = $url.'/';
                                }
                            }
                            else
                            {
                                $permalink = get_permalink();
                            }

                            //Pongo cada numero
                            for ($i = 1; $i <= $max_num_pages; $i++)
                            {
                                $class_current = '';
                                if ($i == $page_number) {
                                    $class_current = 'nav-current active';
                                };

                                //Url normal
                                if ($perma_selection=='') {
                                    $html .= '<li><a class="button-style-1 ' . $class_current . '" href="' . $permalink . '&page=' . $i . '"> ' . $i . ' </a></li>';

                                //Nice url
                                } else {
                                    $html .= '<li><a class="button-style-1 ' . $class_current . '" href="' . $permalink . 'page/' . $i . '"> ' . $i . ' </a></li>';
                                }

                            }

                            $html .= '</ul>';
                            $html .= '</div>';

                        //PAGINACION LOAD MORE
                        }
                        else if ($paging_type == 'ajax')
                        {
                            $html .= '<div class="gallery-the-paging ajax pagination-ajax">';
                            $html .= '<a class="button-style-1" href="javascript: void(0);" data-posts_number="'.$my_posts_number.'" data-max_num_pages="' . $max_num_pages . '" data-sc_atts="' . esc_attr(json_encode($array_atts)) . '">';
                            $html .= __('LOAD MORE', APS_PB_LANG);
                            $html .= '</a>';
                            $html .= '<span><img src="' . APS_THEME_URI . '/includes/stylesheets/images/preloaders/boxes2.gif' . '"></span>';
                            $html .= '<script>var ajaxurl = "' . admin_url('admin-ajax.php') . '";</script>';
                            $html .= '</div>';
                        }
                        else if ($paging_type == 'scroll')
                        {
                            $html .= '<div class="gallery-the-paging ajax pagination-ajax infinite-scroll">';
                            $html .= '<a class="button-style-1" href="javascript: void(0);"  data-posts_number="'.$my_posts_number.'" data-max_num_pages="' . $max_num_pages . '" data-sc_atts="' . esc_attr(json_encode($array_atts)) . '">';
                            $html .= __('SCROLL TO LOAD MORE', APS_PB_LANG);
                            $html .= '</a>';
                            $html .= '<span><img src="' . APS_THEME_URI . '/includes/stylesheets/images/preloaders/boxes2.gif' . '"></span>';
                            $html .= '<script>var ajaxurl = "' . admin_url('admin-ajax.php') . '";</script>';
                            $html .= '</div>';
                        }
                    }
                }

                //Cerrar gallery template
                $html .= '</div>'; //filters-grid-wrapper
            }

            //No funciona para un shortcode
            /*if (defined('DOING_AJAX') && DOING_AJAX)
            {
                return $ajax_articles;
            }*/
            return $html;
        }


        ///////////////////////////////////////////////
        // LA CONSULTA QUERY
        ///////////////////////////////////////////////

        function query_posts_data($type_of_gallery, $thumb_or_gallery='thumb', $query_data, $filter_categories, $filter_tags, $resize_data, $query_relation = 'AND')
        {


            //$thumb_or_gallery
            // = 'thumb' entonces coje la featured image
            // = 'gallery' entonces coje toda la galeria del post

            // Preparar query con categorias y tags
            //-----------------------------------------------

            $tax_query = array( 'relation' => $query_relation );

            //preparar categorias
            if (!empty($filter_categories)) {
                $cats = explode(',', $filter_categories);
                $query_cats = array();
                foreach( $cats as $cat ) {
                    list($taxonomy, $term) = explode('::', $cat);
                    if ( !array_key_exists($taxonomy, $query_cats) ) {
                        $query_cats[$taxonomy] = array(
                            'taxonomy' => $taxonomy,
                            'field' => 'slug',
                            'terms' => array($term)
                        );
                    } else {
                        $query_cats[$taxonomy]['terms'][] = $term;
                    }
                }
                $tax_query = array_merge($tax_query, $query_cats);
            }
            //preparar tags
            if (!empty($filter_tags)) {
                $tags = explode(',', $filter_tags);
                $query_tags = array();
                foreach( $tags as $tag ) {
                    list($taxonomy, $term) = explode('::', $tag);
                    if ( !array_key_exists($taxonomy, $query_tags) ) {
                        $query_tags[$taxonomy] = array(
                            'taxonomy' => $taxonomy,
                            'field' => 'slug',
                            'terms' => array($term)
                        );
                    } else {
                        $query_tags[$taxonomy]['terms'][] = $term;
                    }
                }
                $tax_query = array_merge($tax_query, $query_tags);
            }

            $query_data['tax_query'] = $tax_query;

            // LA CONSULTA
            //-----------------------------------------------
            // cuando es una galeria no debe afectar el numero de posts a consultar

            //echo '<pre>'; print_r( $query_data ); echo '</pre>';

            $my_query = new WP_Query( $query_data );

            //echo '<pre>'; print_r( $query_data ); echo '</pre>';

            $data = array();

            if ( $my_query->have_posts() ) {

                while ( $my_query->have_posts() ) {

                    $my_query->the_post();

                    // Preparo los datos del post o aps_project
                    //Curtain content ? post content ?
                    $filter = '';
                    $curtain_content = '';
                    $curtain_icons = '';
                    $post_title = '';
                    $post_meta = '';
                    $post_content = '';

                    $post_type = get_post_type( get_the_ID());
                    if ( $post_type == 'post' || $post_type == 'aps_project' )
                    {
                        // LOS DATOS DE CADA POST
                        //-----------------------------------------------

                        $array_data = $this->get_post_data_for($type_of_gallery);
                        extract ( $array_data );
                    }


                    // AQUI resized image
                    //-----------------------------------------------

                    // Una imagen por post
                    if ($thumb_or_gallery == 'thumb')
                    {
                        //featured image del post
                        $image = aps_get_image_resized_for_post_id( get_the_ID(),
                            $resize_data['width'], $resize_data['height'],
                            $resize_data['prop'], $resize_data['aumentar']
                        );



                        //Si el post no tiene featured image no aparece
                        if ( $image)
                        {
                            //Coger la resize o la full si no se ha hecho
                            $el_image = $this->get_correct_resize_image($image);
                            // $el['image']  $el['src']

                            //Añadir icono zoom de la imagen
                            $curtain_icons = '<a class="popup fa fa-search" href="' . $image['full']['url'] . '" title="'.get_the_title().'" data-author=""></a>'.$curtain_icons;

                        }
                        else
                        {
                            //Cojo una imagen placeholder aqui porque el post no tiene featured image
                            $width = intval( $resize_data['width'] );
                            $height = intval( $resize_data['height'] );

                            if ($width!=0 && $height!=0) {
                                $el_image = $this->dame_placehold_image($width, $height);
                            } else if ($width!=0 && $height==0) {
                                $el_image = $this->dame_placehold_image($width, intval( 0.75*$width ));
                            } else if ($width==0 && $height==0) {
                                $el_image = $this->dame_placehold_image($height, $height);
                            } else {
                                $el_image = $this->dame_placehold_image(400, 300);
                            }

                            //No tiene imagen con zoom
                        }

                        // IMAGEN OCUPA ESPACIO hasta que se haya cargado
                        //ratio de la imagen
                        $preload_item_image_style = '';
                        //Para justified grid no funciona esta tecnica porque el ancho no esta definido
                        if ( strpos($type_of_gallery,'masonry')===0 || strpos($type_of_gallery,'grid')===0 || strpos($type_of_gallery,'list')===0 || strpos($type_of_gallery,'fullwidth')===0 )
                        {
                            $image_ratio_percent = 100.0*(floatval($el_image['height']) / floatval($el_image['width']));
                            if ( $type_of_gallery == 'list_image_and_text' || $type_of_gallery == 'list_image_and_text_alternate' ) {
                                $image_ratio_percent *= 0.6; //La imagen es el 60% del total, el texto el 40% restante
                            }

                            //Para la precarga ajusto la altura vacia hasta que carga la imagen
                            $preload_item_image_style = 'position:relative;padding-top:'.$image_ratio_percent.'%;overflow:hidden;';
                            $preload_img_style = 'style="position:absolute;top:0;width:100%;"';
                            $el_image['image'] = str_replace('>',' '.$preload_img_style.'>',$el_image['image']);
                        }

                        //Para este no funciona, mejor muestro las imagenes cuando se hayan cargado
                        else if ( $type_of_gallery === 'justified_grid_image_kk' )
                        {
                            $image_ratio_percent = 100.0*(floatval($el_image['height']) / floatval($el_image['width']));
                            $preload_item_image_style = 'position:relative;padding-top:'.$image_ratio_percent.'%;overflow:hidden;border:1px solid black;';
                            $preload_img_style = 'style="position:absolute;top:0;width:100%;"';
                            $el_image['image'] = str_replace('>',' '.$preload_img_style.'>',$el_image['image']);
                        }


                        //Para pruebas
                        if (defined('DEELAY_ME')) {
                            //$el_image['image'] = str_replace('http://', 'http://deelay.me/'.DEELAY_ME.'/', $el_image['image'] );
                            //$el_image['src'] = 'http://deelay.me/'.DEELAY_ME.$el_image['src'];
                        }

                        //Array con los datos a devolver
                        $data[] = array_merge(
                            $el_image, array(
                                'filter'            => $filter,
                                'curtain_content'   => $curtain_content,
                                'curtain_icons'     => $curtain_icons,
                                'post_title'        => $post_title,
                                'post_meta'         => $post_meta,
                                'post_content'      => $post_content,
                                'gallery_title'          => $gallery_title,
                                'gallery_title_and_desc' => $gallery_title_and_desc,
                                'preload_item_image_style' => $preload_item_image_style
                            )
                        );

                    }

                    // La galeria de imagenes del post
                    else if ($thumb_or_gallery == 'gallery')
                    {
                        $gallery_ids = get_post_meta(get_the_ID(), 'gallery_images');

                        if ($gallery_ids)
                        {
                            $gallery_ids = explode(',', $gallery_ids[0]);

                            foreach($gallery_ids as $attach_id)
                            {
                                $image = aps_get_image_resized_for_id( $attach_id,
                                    $resize_data['width'], $resize_data['height'],
                                    $resize_data['prop'], $resize_data['aumentar']
                                );

                                if ($image)
                                {
                                    //Coger la resize o la full si no se ha hecho
                                    $el_image = $this->get_correct_resize_image($image);

                                    // IMAGEN OCUPA ESPACIO hasta que se haya cargado
                                    //ratio de la imagen
                                    $preload_item_image_style = '';
                                    //Para justified grid no funciona esta tecnica porque el ancho no esta definido
                                    if ( strpos($type_of_gallery,'masonry')===0 || strpos($type_of_gallery,'grid')===0 || strpos($type_of_gallery,'list')===0 || strpos($type_of_gallery,'fullwidth')===0 )
                                    {
                                        $image_ratio_percent = 100.0*(floatval($el_image['height']) / floatval($el_image['width']));
                                        if ( $type_of_gallery == 'list_image_and_text' || $type_of_gallery == 'list_image_and_text_alternate' ) {
                                            $image_ratio_percent *= 0.6; //La imagen es el 60% del total, el texto el 40% restante
                                        }

                                        //Para la precarga ajusto la altura vacia hasta que carga la imagen
                                        $preload_item_image_style = 'position:relative;padding-top:'.$image_ratio_percent.'%;overflow:hidden;';
                                        $preload_img_style = 'style="position:absolute;top:0;width:100%;"';
                                        $el_image['image'] = str_replace('>',' '.$preload_img_style.'>',$el_image['image']);
                                    }


                                    //Los datos de la imagen
                                    //Cambio para cada imagen los datos del titulo, meta y content
                                    $a_data = $this->get_attach_data_for( $attach_id );

                                    $link = esc_url( get_permalink() );

                                    //Añadir icono zoom de la imagen manteniendo el resto
                                    $curtain_icons_image = '<a class="popup fa fa-search" href="' . $image['full']['url'] . '" title="'.$a_data['name'].'" data-author="'.get_the_title().'"></a>'.$curtain_icons;

                                    $filter_image = $filter;
                                    $curtain_content_image = $post_title.'<p>'.$a_data['name'].'</p>';
                                    $post_title_image = '<h3 class="post_title" style="font-size:16px;">'.$a_data['name'].'</h3>';

                                    $post_meta_image = '<div class="post_meta"><div class="meta_holder">';
                                    $post_meta_image .= '<a style="font-size:14px;" href="'.$link.'">'.get_the_title().'</a><br>';
                                    $post_meta_image .= $a_data['list_terms'];
                                    $post_meta_image .= '</div></div>';

                                    $post_content_image = '<div class="post_content">'.$a_data['description'].'</div>';

                                    $gallery_title = '<a href="'.$link.'" class="post_more">MORE</a>';
                                    $gallery_title .= '<div class="slider_text">';
                                    $gallery_title .= '<h4 class="slider_title">'.$a_data['name'].' | <a href="'.$link.'">'.get_the_title().'</a></h4>';
                                    $gallery_title .= '</div>';

                                    $gallery_title_and_desc = '<a href="'.$link.'" class="post_more">MORE</a>';
                                    $gallery_title_and_desc .= '<div class="slider_text">';
                                    $gallery_title_and_desc .= '<h4 class="slider_title">'.$a_data['name'].' | <a href="'.$link.'">'.get_the_title().'</a></h4>';
                                    $gallery_title_and_desc .= '<div class="slider_content">'.$a_data['description'].'</div>';
                                    $gallery_title_and_desc .= '</div>';

                                    $data[] = array_merge(
                                        $el_image, array(
                                            'filter'            => $filter_image,
                                            'curtain_content'   => $curtain_content_image,
                                            'curtain_icons'     => $curtain_icons_image,
                                            'post_title'        => $post_title_image,
                                            'post_meta'         => $post_meta_image,
                                            'post_content'      => $post_content_image,
                                            'gallery_title'          => $gallery_title,
                                            'gallery_title_and_desc' => $gallery_title_and_desc,
                                            'preload_item_image_style' => $preload_item_image_style
                                        )
                                    );
                                }
                            }

                        }
                    }

                }

            }

            wp_reset_postdata();

            //return $data;

            return array(
                'my_posts' => $data,
                'max_num_pages' => $my_query->max_num_pages
            );

        }


        ///////////////////////////////////////////////
        // Obtiene los datos necesarios de cada post
        // segun necesite 1 imagen o varias (thumb/gallery)
        // Dentro del loop
        ///////////////////////////////////////////////

        function get_post_data_for($type_of_gallery)
        {
            $post_id = get_the_ID();
            $post_type = get_post_type($post_id);
            $link = esc_url( get_permalink() );
            $tit = esc_attr(sprintf(__('Permalink to: &#39;%s&#39;',APS_PB_LANG), the_title_attribute('echo=0')));
            $post_title = '<h3 class="post_title"><a href="' . $link . '" rel="bookmark" title="'.$tit.'">'.get_the_title().'</a></h3>';

            $curtain_content = $post_title;

            $curtain_icons = '';
            //$curtain_icons .= '<a class="popup fa fa-search" href="' . $image['full']['url'] . '" title="" data-author=""></a>';
            $curtain_icons .= '<a class="post_more" href="'.$link.'"></a>';

            $taxonomy = 'category';
            if ($post_type=='aps_project') {
                $taxonomy = 'project_category';
            }

            $post_meta = '<div class="post_meta"><div class="meta_holder">';
            $post_meta .= $this->get_list_terms_for_taxonomy($post_id, $taxonomy, true);
            $post_meta .= '</div></div>';

            $curtain_content .= $post_meta;

            $post_content = '<div class="post_content">'.get_the_excerpt().'</div>';

            $filter = $this->get_all_terms_for_post(get_the_ID());

            //Cuando saco el texto no me hace falta el content porque seria repetido
            if ( $type_of_gallery=='masonry_image_and_text' || $type_of_gallery=='grid_image_and_text' ) {
                $curtain_content = '';
            }

            //Tiene video
            if ($post_type == 'post' and get_post_format()=='post-format-video')
            {
                //Poner el link al video
            }

            //Link externo aps_project
            if ($post_type == 'aps_project' && get_post_meta($post_id,'project_has_link',true) == 'yes')
            {

                $project_link = get_post_meta($post_id,'project_link',true);
                $project_caption = get_post_meta($post_id,'project_caption',true);
                $project_target = get_post_meta($post_id,'project_target',true);
                $curtain_icons .= '<a target="'.$project_target.'" class="fa fa-link" href="'.$project_link.'"></a>';
            }

            //Para el slider
            $gallery_title = '<a href="'.$link.'" class="post_more">MORE</a>';
            $gallery_title .= '<div class="slider_text">';
            $gallery_title .= '<h4 class="slider_title"><a href="'.$link.'">'.get_the_title().'</a></h4>';
            $gallery_title .= '</div>';

            $gallery_title_and_desc = '<a href="'.$link.'" class="post_more">MORE</a>';
            $gallery_title_and_desc .= '<div class="slider_text">';
            $gallery_title_and_desc .= '<h4 class="slider_title"><a href="'.$link.'">'.get_the_title().'</a></h4>';
            $gallery_title_and_desc .= '<div class="slider_content">'.get_the_excerpt().'</div>';
            $gallery_title_and_desc .= '</div>';

            return array(
                'filter'            => $filter,
                'curtain_content'   => $curtain_content,
                'curtain_icons'     => $curtain_icons,
                'post_title'        => $post_title,
                'post_meta'         => $post_meta,
                'post_content'      => $post_content,
                'gallery_title'          => $gallery_title,
                'gallery_title_and_desc' => $gallery_title_and_desc
            );
        }


        ///////////////////////////////////////////////
        // Coger resized image or full si no esta completa
        ///////////////////////////////////////////////

        function get_correct_resize_image($image)
        {
            $el = array();
            if (isset($image['resized'])) {
                $el['image'] = $image['resized']['img'];
                $el['src'] = $image['resized']['url'];
                $el['width'] = $image['resized']['width'];
                $el['height'] = $image['resized']['height'];
            } else {
                $el['image'] = $image['full']['img'];
                $el['src'] = $image['full']['url'];
                $el['width'] = $image['full']['width'];
                $el['height'] = $image['full']['height'];
            }
            return $el;
        }


        ///////////////////////////////////////////////
        // Array data for image
        ///////////////////////////////////////////////


        function get_array_data_for_image( $attach_id ,$resize_data, $type_of_gallery )
        {
            $image = aps_get_image_resized_for_id( $attach_id,
                $resize_data['width'], $resize_data['height'],
                $resize_data['prop'], $resize_data['aumentar']
            );

            if ($image)
            {
                //Coger la resize o la full si no se ha hecho
                $el_image = $this->get_correct_resize_image($image);

                // IMAGEN OCUPA ESPACIO hasta que se haya cargado
                //ratio de la imagen
                $preload_item_image_style = '';
                //Para justified grid no funciona esta tecnica porque el ancho no esta definido
                if ( strpos($type_of_gallery,'masonry')===0 || strpos($type_of_gallery,'grid')===0 || strpos($type_of_gallery,'list')===0 || strpos($type_of_gallery,'fullwidth')===0 )
                {
                    $image_ratio_percent = 100.0*(floatval($el_image['height']) / floatval($el_image['width']));
                    if ( $type_of_gallery == 'list_image_and_text' || $type_of_gallery == 'list_image_and_text_alternate' ) {
                        $image_ratio_percent *= 0.6; //La imagen es el 60% del total, el texto el 40% restante
                    }

                    //Para la precarga ajusto la altura vacia hasta que carga la imagen
                    $preload_item_image_style = 'position:relative;padding-top:'.$image_ratio_percent.'%;overflow:hidden;';
                    $preload_img_style = 'style="position:absolute;top:0;width:100%;"';
                    $el_image['image'] = str_replace('>',' '.$preload_img_style.'>',$el_image['image']);
                }

                //Los datos de la imagen
                //Cambio para cada imagen los datos del titulo, meta y content
                $a_data = $this->get_attach_data_for( $attach_id );
                //echo '<pre>'; print_r( $a_data ); echo '</pre>';

                //Link a imagen para lightbox
                $curtain_icons_image = '<a class="popup fa fa-search" href="' . $image['full']['url'] . '" title="'.$a_data['name'].'" data-author="'.$a_data['description'].'"></a>';

                $data = array_merge(
                    $el_image, array(
                        'curtain_icons'     => $curtain_icons_image,
                        'preload_item_image_style' => $preload_item_image_style
                    )
                );
                return $data;
            }
            return null;
        }


        ///////////////////////////////////////////////
        // Datos de una imagen, caption, etc
        ///////////////////////////////////////////////

        function get_attach_data_for( $attachment_id )
        {
            $attachment = get_post( $attachment_id );

            $list_terms_1 = $this->get_list_terms_for_taxonomy( $attachment_id, 'category', false);
            $list_terms_2 = $this->get_list_terms_for_taxonomy( $attachment_id, 'post_tag', false);
            //$list_terms_3 = $this->get_list_terms_for_taxonomy( $attachment_id, 'location', false);
            $separator = ' &nbsp;|&nbsp; ';

            $list_terms = $list_terms_1;
            $list_terms .= ( ($list_terms && $list_terms_2) ? $separator : '' ) . $list_terms_2;
            //$list_terms .= ( ($list_terms && $list_terms_3) ? $separator : '' ) . $list_terms_3;

            if ($attachment->post_excerpt) {
                $attach_name = $attachment->post_excerpt;
            } else {
                $attach_name = $attachment->post_title;
            }

            return array(
                'alt' => get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true ),
                'caption' => $attachment->post_excerpt,
                'description' => $attachment->post_content,
                'href' => get_permalink( $attachment->ID ),
                'src' => $attachment->guid,
                'title' => $attachment->post_title,
                'list_terms' => $list_terms,
                'name'  => $attach_name
            );
        }


        ///////////////////////////////////////////////
        // Listado de terms para un post y taxonomy, con su link
        ///////////////////////////////////////////////

        function get_list_terms_for_taxonomy( $post_id, $taxonomy, $with_link = true)
        {
            $terms = get_the_terms($post_id, $taxonomy);

            //echo '<h3>Obteniendo taxonomy '.$taxonomy.'</h3>';
            //echo '<pre>'; print_r( $terms ); echo '</pre>';

            if ($terms)
            {
                $list_terms = '';
                $separator = ' &nbsp;|&nbsp; ';
                $i = 0;
                $len = count($terms);

                foreach ($terms as $term)
                {
                    //$c_href = get_category_link($term->term_id);
                    $c_href = get_term_link($term->term_id, $taxonomy);
                    $c_title = esc_attr( sprintf( __("View all items in: &#39;%s&#39;",APS_PB_LANG), $term->name ));
                    $c_name = $term->name;
                    if ($with_link === true  ) {
                        $list_terms .= '<a class="post_cat" href="'.$c_href.'" title="'.$c_title.'">'.$c_name.'</a>';
                    } else {
                        $list_terms .= '<span>'.$c_name.'</span>';
                    }

                    if ( $i++ < $len-1 ) {
                        $list_terms .= $separator;
                    }
                }

                return $list_terms;
            }
            return false;
        }


        ///////////////////////////////////////////////
        // LINK para un filtro
        ///////////////////////////////////////////////

        function create_html_filter($categories, $tags)
        {

            //echo '<p>Creando html filter para = '.$categories.','.$tags.'</p>';

            if ( empty($categories) && empty($tags)) {
                return '';
            }
            $html = '<ul class="gallery-the-filters isotope-filters">';
            $html .= '<li><a href="#" class="active button-style-1" data-filter=".isotope-item">' . __('All', APS_PB_LANG) . '</a></li>';

            $filters = $categories.','.$tags;
            $filters = rtrim($filters, ',');
            $filters = explode(',',$filters);

            //SI solo hay un filro no hace falta
            if (count($filters) == 1) { return ''; }

            foreach($filters as $filter)
            {
                $data_filter = explode('::', $filter);
                if (isset($data_filter[1]))
                {
                    $term = get_term_by('slug', $data_filter[1], $data_filter[0]);
                    $html .= '<li><a href="#" class="button-style-1" data-filter=".isotope-item.filter_' . $data_filter[1] . '">' . $term->name . '</a></li>';
                }
            }

            $html .= '</ul>';
            return $html;
        }



        ///////////////////////////////////////////////
        // Filtros
        ///////////////////////////////////////////////
        //Obtener listado para una taxonomia especifica

        function get_taxonomy_list($post_id, $taxonomy)
        {
            $array = wp_get_object_terms($post_id,$taxonomy);
            if ($array){
                $cadena = '';
                foreach($array as $tax){
                    //$cadena .= ' '.$taxonomy.':'.$tax->slug;
                    $cadena .= ' filter_'.$tax->slug;
                }
                return $cadena;
            }
            return '';
        }


        ///////////////////////////////////////////////
        // TERMS FOR POST
        ///////////////////////////////////////////////

        function get_all_terms_for_post($post_id)
        {
            $list = '';
            $taxonomies = get_object_taxonomies(get_post_type($post_id));
            foreach ($taxonomies as $taxonomy) {
                $list .= ' '.$this->get_taxonomy_list($post_id, $taxonomy);
            }
            return $list;
        }



        ///////////////////////////////////////////////
        // TEMPLATES
        ///////////////////////////////////////////////

        function get_templates()
        {
            $templates = array();

            $templates['masonry_image'] = <<<TMPL
    <article class="%class_article%" style="%style_article%">
		<div class="post-item-wrap">
			<div class="item-image" style="%preload_item_image_style%">
			    %image%
				<div class="item-image-curtain">
					<div class="item-image-curtain-content">%curtain_content%</div>
					<div class="item-image-curtain-icons">%curtain_icons%</div>
				</div>
			</div>
		</div>
	</article>
TMPL;

            $templates['masonry_image_and_text'] = <<<TMPL
    <article class="%class_article%" style="%style_article%">
		<div class="post-item-wrap">
			<div class="item-image" style="%preload_item_image_style%">
			    %image%
				<div class="item-image-curtain">
					<div class="item-image-curtain-content">%curtain_content%</div>
					<div class="item-image-curtain-icons">%curtain_icons%</div>
				</div>
			</div>
			<div class="item-content">
				%post_title%
				%post_meta%
				%post_content%
			</div>
		</div>
	</article>
TMPL;

            $templates['grid_image']            = $templates['masonry_image'];
            $templates['grid_image_and_text']   = $templates['masonry_image_and_text'];
            $templates['justified_grid_image']  = $templates['masonry_image'];

            $templates['gallery_image'] = <<<TMPL
       <div class="rsContent">
			<img class="rsImg" src="%src%" alt="" />
		</div>
TMPL;

            $templates['gallery_image_and_text'] =  <<<TMPL
       <div class="rsContent">
			<img class="rsImg" src="%src%" alt="" />
			<div class="infoBlock rsABlock" data-fade-effect="" data-move-offset="10" data-move-effect="bottom" data-speed="200">
				%gallery_title%
			</div>
		</div>
TMPL;
            $templates['gallery_image_and_text_2'] =  <<<TMPL
       <div class="rsContent">
			<img class="rsImg" src="%src%" alt="" />
			<div class="infoBlock rsABlock" data-fade-effect="" data-move-offset="10" data-move-effect="bottom" data-speed="200">
				%gallery_title_and_desc%
			</div>
		</div>
TMPL;

            $templates['list_image_and_text'] = $templates['masonry_image_and_text'];
            $templates['list_image_and_text_alternate'] = $templates['masonry_image_and_text'];
            $templates['fullwidth_image'] = $templates['masonry_image'];

            return $templates;

        }


        function render_template( $tmpl, $data )
        {
            $html = $tmpl;

            foreach($data as $key=>$value)
            {
                $html = str_replace('%'.$key.'%', $value, $html);
            }

            return $html;
        }


        /*function dame_placehold_image ($width, $height)
        {
            $name = 'http://placehold.it/'.$width.'x'.$height.'&text=no+image';
            return array(
                'image' => '<img src="'.$name.'" width="'.$width.'" height="'.$height.'">',
                'src' => $name,
                'width' => $width,
                'height' => $height
            );
        }
        */

    }

}
