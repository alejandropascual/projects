<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_gallery_projects' ) )
{
    class aps_gallery_projects extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' 		=> 'List/Gallery: Projects',
                'shortcode' => 'aps_gallery_projects',
                'tab' 		=> __('GALLERIES',APS_PB_LANG),
                'order' 	=> 110,

            );
        }

        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),
                // Type of gallery
                array(
                    'label' => __('Type of gallery', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'type',
                    'type'  => 'select',
                    'value' => 'top',
                    'options' => array(
                        'masonry_image'                     => 'Masonry with image',
                        'masonry_image_and_text'            => 'Masonry with image and text',
                        'grid_image'                        => 'Grid with image',
                        'grid_image_and_text'               => 'Grid with image and text',
                        'justified_grid_image'              => 'Justified grid image',
                        'list_image_and_text'               => 'List',
                        'list_image_and_text_alternate'     => 'List alternate',
                        'gallery_image'                     => 'Slider',
                        'gallery_image_and_text'            => 'Slider with text',
                        'fullwidth_image'                   => 'Fullwidth image'
                    )
                ),

                //Select by filter or specific posts
                array(
                    'label' => __('Select posts by', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'select_by',
                    'type'  => 'select',
                    'options' => array('by_filter'=>'Filter by category | tag', 'by_ids'=>'Posts by ID')
                ),

                //Muestra las categorias de cada custom post
                array(
                    'label' => __('Filter categories', APS_PB_LANG),
                    'desc'  => __('Select multiple categories or leave it blank for all', APS_PB_LANG),
                    'id'    => 'categories',
                    'type'  => 'select_custom_categories',
                    'required' => 'select_by->by_filter',
                    'include_custom_posts' => array('aps_project')
                ),

                //Muestra los tags de cada custom post
                array(
                    'label' => __('Filter tags', APS_PB_LANG),
                    'desc'  => __('Select multiple tags or leave it blank for all', APS_PB_LANG),
                    'id'    => 'tags',
                    'type'  => 'select_custom_tags',
                    'required' => 'select_by->by_filter',
                    'include_custom_posts' => array('aps_project')
                ),

                //Relacion AND OR
                array(
                    'label' => __('Relation', APS_PB_LANG),
                    'desc'  => __('Filter relation categories / tags', APS_PB_LANG),
                    'id'    => 'query_relation',
                    'type'  => 'select',
                    'required' => 'select_by->by_filter',
                    'options' => array('AND'=>'AND', 'OR'=>'OR')
                ),

                //Escribir los ids
                array(
                    'label' => __('Post ID', APS_PB_LANG),
                    'desc'  => __('Write the ID of the posts you want to display.<br>For example: 45,78', APS_PB_LANG),
                    'id'    => 'post_ids',
                    'type'  => 'input',
                    'value' => '',
                    'required' => 'select_by->by_ids',
                ),

                //Select featured image or gallery
                array(
                    'label' => __('Use featured Image or Gallery posts', APS_PB_LANG),
                    'desc'  => __('You can use the one image per post (featured image) <br>or show all the images of the gallery included in the post (only valid for gallery posts).', APS_PB_LANG),
                    'id'    => 'use_gallery_of_post',
                    'type'  => 'select',
                    'options' => array('no'=>'Use only featured image', 'yes'=>'Use all the gallery images in the post')
                ),

                //Los datos para cada tipo de galeria

                //Masonry
                array(
                    'label' => __('Image width in pixels', APS_PB_LANG),
                    'desc'  => __('example: 300', APS_PB_LANG),
                    'id'    => 'masonry_width',
                    'type'  => 'input',
                    'value' => 300,
                    'required' => 'type->masonry_image,masonry_image_and_text'
                ),
                array(
                    'label' => __('Separation between elements in pixels', APS_PB_LANG),
                    'desc'  => __('example: 2', APS_PB_LANG),
                    'id'    => 'masonry_margin',
                    'type'  => 'input',
                    'value' => 2,
                    'required' => 'type->masonry_image,masonry_image_and_text'
                ),

                //Grid
                array(
                    'label' => __('Grid columns', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'grid_cols',
                    'type'  => 'select',
                    'required' => 'type->grid_image,grid_image_and_text',
                    'options' => array('2'=>'2', '3'=>'3', '4'=>'4', '5'=>'5', '6'=>'6')
                ),
                array(
                    'label' => __('Image width in pixels', APS_PB_LANG),
                    'desc'  => __('example: 300', APS_PB_LANG),
                    'id'    => 'grid_width',
                    'type'  => 'input',
                    'value' => 300,
                    'required' => 'type->grid_image,grid_image_and_text',
                ),
                array(
                    'label' => __('Separation between elements in pixels', APS_PB_LANG),
                    'desc'  => __('example: 2', APS_PB_LANG),
                    'id'    => 'grid_padding',
                    'type'  => 'input',
                    'value' => 2,
                    'required' => 'type->grid_image,grid_image_and_text',
                ),
                array(
                    'label' => __('Ratio image vertical/horizontal', APS_PB_LANG),
                    'desc'  => __('examples: 1 (square)<br>0.5 (landscape)<br>2 (vertical)', APS_PB_LANG),
                    'id'    => 'grid_ratio',
                    'type'  => 'input',
                    'value' => 0.75,
                    'required' => 'type->grid_image,grid_image_and_text',
                ),

                //Justified grid
                array(
                    'label' => __('Column height en pixels', APS_PB_LANG),
                    'desc'  => __('example: 300', APS_PB_LANG),
                    'id'    => 'jgrid_height',
                    'type'  => 'input',
                    'value' => 300,
                    'required' => 'type->justified_grid_image',
                ),
                array(
                    'label' => __('Separation between elements in pixels', APS_PB_LANG),
                    'desc'  => __('example: 1', APS_PB_LANG),
                    'id'    => 'jgrid_padding',
                    'type'  => 'input',
                    'value' => 1,
                    'required' => 'type->justified_grid_image',
                ),

                //List
                array(
                    'label' => __('Image width in pixels', APS_PB_LANG),
                    'desc'  => __('example: 400', APS_PB_LANG),
                    'id'    => 'list_width',
                    'type'  => 'input',
                    'value' => 400,
                    'required' => 'type->list_image_and_text,list_image_and_text_alternate',
                ),
                array(
                    'label' => __('Ratio image vertical/horizontal', APS_PB_LANG),
                    'desc'  => __('examples: 1 (square)<br>0.5 (landscape)<br>2 (vertical)', APS_PB_LANG),
                    'id'    => 'list_ratio',
                    'type'  => 'input',
                    'value' => 0.75,
                    'required' => 'type->list_image_and_text,list_image_and_text_alternate',
                ),

                //Slider
                array(
                    'label' => __('Slider: Image width in pixels', APS_PB_LANG),
                    'desc'  => __('example: 800', APS_PB_LANG),
                    'id'    => 'gallery_width',
                    'type'  => 'input',
                    'value' => 800,
                    'required' => 'type->gallery_image,gallery_image_and_text',
                ),
                array(
                    'label' => __('Slider full-screen', APS_PB_LANG),
                    'desc'  => __('This will force the height of the slider to the height of the screen (minus header height)<br>Use it with full-screen layout.', APS_PB_LANG),
                    'id'    => 'gallery_fullscreen',
                    'type'  => 'select_yes_no',
                    'value' => 'no',
                    'required' => 'type->gallery_image,gallery_image_and_text',
                ),
                array(
                    'label' => __('Slider: Image height in pixels', APS_PB_LANG),
                    'desc'  => __('example: 500', APS_PB_LANG),
                    'id'    => 'gallery_height',
                    'type'  => 'input',
                    'value' => 500,
                    'required' => 'type->gallery_image,gallery_image_and_text',
                ),
                array(
                    'label' => __('Slider: Image mode', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'gallery_mode',
                    'type'  => 'select',
                    'required' => 'type->gallery_image,gallery_image_and_text',
                    'options' => array(
                        'fill' => 'Fill: image will expand to fill the slider container',
                        'fit' => 'Fit: image will fit inside the slider container'
                    )
                ),
                array(
                    'label' => __('Slider: Display post excerpt', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'gallery_text_desc',
                    'type'  => 'select_yes_no',
                    'required' => 'type->gallery_image_and_text',
                    'options' => array(
                        'yes' => 'Yes, display below the title',
                        'no' => 'No'
                    )
                ),

                //Fullwidth image
                array(
                    'label' => __('Image width in pixels', APS_PB_LANG),
                    'desc'  => __('example: 800', APS_PB_LANG),
                    'id'    => 'fullwidth_width',
                    'type'  => 'input',
                    'value' => 800,
                    'required' => 'type->fullwidth_image',
                ),
                array(
                    'label' => __('Image height in pixels', APS_PB_LANG),
                    'desc'  => __('Example: 400 or <br>Leave it blank if you do not want to crop the image.', APS_PB_LANG),
                    'id'    => 'fullwidth_height',
                    'type'  => 'input',
                    'value' => 400,
                    'required' => 'type->fullwidth_image',
                ),


                //Paging
                array(
                    'label' => __('Pagination', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'paging_type',
                    'type'  => 'select',
                    'required' => 'use_gallery_of_post->no AND type->masonry_image,masonry_image_and_text,grid_image,grid_image_and_text,list_image_and_text,list_image_and_text_alternate',
                    'options' => array(
                        'none'      => 'No pagination. Show all elements',
                        'numbers'   => 'Pagination with Numbers',
                        'ajax'      => 'Pagination with Load-More button',
                        'scroll'      => 'Infinite scroll'
                    )
                ),
                array(
                    'label' => __('Pagination: posts per page', APS_PB_LANG),
                    'desc'  => __('Write -1 for all', APS_PB_LANG),
                    'id'    => 'posts_per_page',
                    'type'  => 'input',
                    'required' => 'use_gallery_of_post->no AND type->masonry_image,masonry_image_and_text,grid_image,grid_image_and_text,list_image_and_text,list_image_and_text_alternate',
                    'value' => 10
                ),
                /*array(
                    'label' => __('Pagination: page number', APS_PB_LANG),
                    'desc'  => __('When pagination is active you can select here de default page to display. By default = 1', APS_PB_LANG),
                    'id'    => 'page_number',
                    'type'  => 'input',
                    'required' => 'use_gallery_of_post->no AND type->masonry_image,masonry_image_and_text,grid_image,grid_image_and_text,list_image_and_text,list_image_and_text_alternate', //Asi queda oculto
                    'value' => 1
                ),*/

                //Order
                array(
                    'label'	=> __('Order posts By', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'orderby',
                    'type' 	=> 'select',
                    'value' => 'date',
                    'options' => array(
                        'none'          => 'None',
                        'title'         => 'Title',
                        'author'        => 'Author',
                        'date'          => 'Date',
                        'comment_count' => 'Popularity',
                        'rand'          => 'Random'
                    )
                ),
                //Order
                array(
                    'label'	=> __('Order of posts', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'order',
                    'type' 	=> 'select',
                    'value' => 'ASC',
                    'options' => array(
                        'ASC' => 'Ascending',
                        'DESC' => __('Descending', APS_PB_LANG)
                    )
                ),

                //DISPLAY
                array(
                    'label' => __('Display border', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'with_border',
                    'type'  => 'select_yes_no',
                    'value' => 'yes',
                    'required' => 'type->masonry_image,masonry_image_and_text,grid_image,grid_image_and_text,list_image_and_text,list_image_and_text_alternate,justified_grid_image,fullwidth_image',
                ),
                array(
                    'label' => __('Hover: display link to post', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'display_link_post',
                    'type'  => 'select_yes_no',
                    'value' => 'yes',
                    'required' => 'type->masonry_image,masonry_image_and_text,grid_image,grid_image_and_text,list_image_and_text,list_image_and_text_alternate,justified_grid_image,fullwidth_image',
                ),
                array(
                    'label' => __('Hover: display link to lightbox', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'display_link_lightbox',
                    'type'  => 'select_yes_no',
                    'value' => 'yes',
                    'required' => 'type->masonry_image,masonry_image_and_text,grid_image,grid_image_and_text,list_image_and_text,list_image_and_text_alternate,justified_grid_image,fullwidth_image',
                ),
                array(
                    'label' => __('Hover: display link to external page', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'display_link_external',
                    'type'  => 'select_yes_no',
                    'value' => 'yes',
                    'required' => 'type->masonry_image,masonry_image_and_text,grid_image,grid_image_and_text,list_image_and_text,list_image_and_text_alternate,justified_grid_image,fullwidth_image',
                ),
                array(
                    'label' => __('Hover: display content text', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'display_curtain_text',
                    'type'  => 'select_yes_no',
                    'value' => 'yes',
                    'required' => 'type->masonry_image,masonry_image_and_text,grid_image,grid_image_and_text,list_image_and_text,list_image_and_text_alternate,justified_grid_image,fullwidth_image',
                ),
            );

        }

        function shortcode_handler( $atts, $content = null )
        {

            $sc = "[aps_gallery_template post_type='aps_project'";
            foreach( $atts as $key=>$value) {
                $sc .= " {$key}='{$value}'";
            }
            $sc .= "]";
            //echo '<pre>'; print_r( $sc ); echo '</pre>';
            return do_shortcode($sc);
        }

    }
}