<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_headline' ) ) 
{
	class aps_headline extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Headline',
				'shortcode' => 'aps_headline',
                'tab' 		=> __('CONTENT',APS_PB_LANG),
				'order' 	=> 20,
				'use_line_break' => 'no'
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',
				),
				
				
				array(
					'label' => __('Type', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'type',
					'type' 	=> 'select',
					'value' => 'h1',
					'options' => array(
						'h1'=>'Heading h1',
						'h2'=>'Heading h2',
						'h3'=>'Heading h3',
						'h4'=>'Heading h4',
						'h5'=>'Heading h5',
						'h6'=>'Heading h6',
					)
				),
				array(
					'label' => __('Content', APS_PB_LANG),
					'desc' 	=> __('Write the headline here', APS_PB_LANG),
					'id' 	=> 'content_sc',
					'type' 	=> 'input',
					'value' => 'Title of the headline',
				),
				array(
					'label' => __('Align', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'align',
					'type' 	=> 'select',
					'value' => 'left',
					'options' => array(
						'left'	=>'Left',
						'center'=>'Center',
						'right'	=>'Right',
					)
				),
				array(
					'label' => __('Use Line', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'use_line',
					'type' 	=> 'select',
					'value' => 'no',
					'options' => array(
						'yes'	=>'Yes',
						'no'=>'No',
					)
				),
                array(
                    'label' => __('1 or 2 lines', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'number_lines',
                    'type' 	=> 'select',
                    'value' => '1',
                    'options' => array(
                        '1'	=>'1 line',
                        '2' =>'2 lines',
                    ),
                    'required'=>'use_line->yes'
                ),
				array(
					'label' => __('Line Color', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'line_color',
					'type' 	=> 'colorpicker',
					'value' => '#000000',
					'required'=>'use_line->yes'
				),
				array(
					'label' => __('Line Width', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'line_width',
					'type' 	=> 'input',
					'value' => '1px',
					'required'=>'use_line->yes'
				),	
				array(
					'label'	=> __('Line Type', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'line_style',
					'type' 	=> 'select',	
					'value' => 'solid',
					'options' => array(
						'solid'=>'Solid',
						'dashed'=>'Dashed',
						'dotted'=>'Dotted'
					),
					'required'=>'use_line->yes'
				),	
				
				array(
					'label' => __('Use Icon', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'use_icon',
					'type' 	=> 'select',
					'value' => 'no',
					'options' => array(
						'yes'	=>'Yes',
						'no'	=>'No',
					)
				),
				array(
					'label' => __('Icon', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'icon',
					'type' 	=> 'iconfont',
					'value' => '',
					'required'=>'use_icon->yes'
				),
				/*array(
					'label' => __('Icon Color', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'icon_color',
					'type' 	=> 'colorpicker',
					'value' => '',
					'required'=>'use_icon->yes'
				),
				array(
					'label' => __('Icon background color', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'icon_bg_color',
					'type' 	=> 'colorpicker',
					'value' => '',
					'required'=>'use_icon->yes'
				),
				array(
					'label' => __('Icon type', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'icon_bg_type',
					'type' 	=> 'select',
					'value' => '',
					'options' => array(
						'square'=>'Square', 
						'circle'=>'Circle', 
						'rounded'=>'Rounded'
					),
					'required'=>'use_icon->yes'
				)*/
			);
		}
				
		function shortcode_handler($atts, $content='')
		{
			extract( shortcode_atts( array(
				'id'    => '',
				'class' => '',
				'style' => '',
				'type'	=> '',
				'align'	=> '',
				'use_line'	 => '',
                'number_lines' => '',
				'line_color' => '',
				'line_width' => '',
				'line_style' => '',
				'use_icon'	 => '',
				'icon'		 => '',
				'icon_color' => '',
				'icon_bg_color' => '',
				'icon_bg_type'	=> ''
			), $atts ) );
			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? 'aps-headline ' . esc_attr( $class ) : 'aps-headline';
			$style = ( $style != '' ) ? 'style="' . $style . '"' : '';
			
			$type = ( $type != '' ) ? $type : 'h2';
			
			switch ($align) {
			  case ('center'):
			  	$align = ' align-center';
			  	break;
			  case ('right'):
			  	$align = ' align-right';
			  	break;
			  default:
			  	$align = '';
			} 
			
			//Line
			$line_class = ( $use_line == 'yes' ) ? ' line': '';
			$line_color = ( $line_color != '' ) ? " border-color: {$line_color};" : '';
			$line_width = ( $line_width != '' ) ? " border-width: {$line_width};" : '';
			$line_style = ( $line_style != '' ) ? " border-style: {$line_style};" : '';

			$border = ' border-left:0; border-right:0;';
            if ($number_lines=='1') { $border .= 'border-bottom:0;'; }
		
			//Icon
			$icon_color = ( $icon_color != '' ) ? " color:{$icon_color};" : '';
			$icon_bg_color = ( $icon_bg_color != '' ) ? " background-color:{$icon_bg_color};" : '';
			switch ($icon_bg_type){
				case ('square'):
					$icon_bg_type = " border-radius:0em;";
					break;
				case ('rounded'):
					$icon_bg_type = " border-radius:5%;";
					break;
				default:
					$icon_bg_type = " border-radius:99em;";
			}
		  
			//html
			$html = "<{$type} {$id} class=\"{$class}{$line_class}{$align}\" {$style}\">";
			$html .= "<span class='wrap'>";

			if ($use_line=='yes') {
				$html .= "<span class=\"before lines-{$number_lines}\" style=\"{$line_color}{$line_width}{$line_style}{$border}\"></span>";
			}
			if ($use_icon=='yes') {
				//$html .= "<span class=\"entypo-icon entypo-{$icon}\"></span>";
				//$html .= "<i class=\"aps-icon fa {$icon}\" style=\"{$icon_color}{$icon_bg_color}{$icon_bg_type}\"></i>";
                $html .= "<span class=\"title-icon fa {$icon}\"></span>";
			}
			$html .= do_shortcode(aps_clean_shortcodes( $content ));
			if ($use_line=='yes') {
				$html .= "<span class=\"after lines-{$number_lines}\" style=\"{$line_color}{$line_width}{$line_style}{$border}\"></span>";
			}
			$html .= "</span>";
			$html .= "</{$type}>";
			
			return $html;
		}
		
	}
}