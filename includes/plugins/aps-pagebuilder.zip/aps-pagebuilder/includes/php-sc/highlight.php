<?php


// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }


if ( !class_exists( 'aps_highlight' ) )
{
    class aps_highlight extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' 		=> 'Highlight',
                'shortcode' => 'aps_highlight',
                'tab' 		=> __('CONTENT',APS_PB_LANG),
                'order' 	=> 100,
                'use_line_break' => 'no'
            );
        }


        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),

                array(
                    'label' => __('Background Color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'back_color',
                    'type' 	=> 'colorpicker',
                    'value' => 'yellow',
                ),
                array(
                    'label' => __('Override color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'use_color',
                    'type' 	=> 'select',
                    'value' => 'yes',
                    'options' => array('no'=>'No','yes'=>'Yes')
                ),
                array(
                    'label' => __('Color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'color',
                    'type' 	=> 'colorpicker',
                    'value' => '#000000',
                    'required' => 'use_color->yes'
                ),
                array(
                    'label' => __('Content', APS_PB_LANG),
                    'desc' 	=> __('Write the highlighted text here', APS_PB_LANG),
                    'id' 	=> 'content_sc',
                    'type' 	=> 'input',
                    'value' => 'highlighted text',
                ),

            );
        }

        function shortcode_handler($atts, $content='')
        {
            extract( shortcode_atts( array(
                'id'    => '',
                'class' => '',
                'style' => '',
                'back_color' => '',
                'use_color' => '',
                'color' => '',
            ), $atts ) );

            $id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $class = ( $class != '' ) ? 'class="aps-highlight '.esc_attr( $class ).'"' : 'class="aps-highlight"';
            $style_more = ( $style != '' ) ? $style : '';

            $style  = 'style="';
            $style .= 'background-color:'.$back_color.';';
            if ( $use_color == 'yes' ) {
                $style .= 'color:'.$color.';';
            }
            $style .= $style_more;
            $style .= '"';

            $html = "<span {$id} {$class} {$style}>".do_shortcode($content)."</span>";

            return $html;
        }

    }
}