<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_icon' ) ) 
{
	class aps_icon extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Icon',
				'shortcode' => 'aps_icon',
                'tab' 		=> __('CONTENT',APS_PB_LANG),
				'order' 	=> 60
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',	
				),
				
				
				array(
					'label' => __('Icon', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'icon',
					'type' 	=> 'iconfont',
					'value' => 'coffee',
				),
                array(
                    'label' => __('Icon size', APS_PB_LANG),
                    'desc' 	=> __('Define the size in pixels, example: 30px', APS_PB_LANG),
                    'id' 	=> 'size',
                    'type' 	=> 'input',
                    'value' => '30px',
                ),
                array(
                    'label' => __('Custom colors', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'customize',
                    'type' 	=> 'select',
                    'value' => 'no',
                    'options' => array('no'=>'NO', 'yes'=>'YES')
                ),
				array(
					'label' => __('Icon Color', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'icon_color',
					'type' 	=> 'colorpicker',
					'value' => '#000000',
                    'required' => 'customize->yes'
				),
				array(
					'label' => __('Icon background color', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'icon_bg_color',
					'type' 	=> 'colorpicker',
					'value' => '#ffffff',
                    'required' => 'customize->yes'
				),
				array(
					'label' => __('Icon type', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'icon_bg_type',
					'type' 	=> 'select',
					'value' => 'square',
					'options' => array('square'=>'Square', 'circle'=>'Circle', 'rounded'=>'Rounded'),
                    'required' => 'customize->yes'
				),

				array(
					'label' => __('Border color', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'border_color',
					'type' 	=> 'colorpicker',
					'value' => '#000000',
                    'required' => 'customize->nada'
				),
				array(
					'label' => __('Border width', APS_PB_LANG),
					'desc' 	=> __('Set 0px id do not want a border', APS_PB_LANG),
					'id' 	=> 'border_width',
					'type' 	=> 'input',
					'value' => '0px',
                    'required' => 'customize->nada'
				),

                array(
                    'label' => __('Display', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'display',
                    'type' 	=> 'select',
                    'value' => 'inline',
                    'options' => array('inline'=>'Inline', 'block'=>'Block')
                ),
                array(
                    'label' => __('Align', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'align',
                    'type' 	=> 'select',
                    'value' => 'center',
                    'options' => array('left'=>'Left', 'center'=>'Center','right'=>'Right'),
                    'required' => 'display->block'
                ),
                array(
                    'label' => __('Padding left', APS_PB_LANG),
                    'desc' 	=> __('ex: 50px', APS_PB_LANG),
                    'id' 	=> 'padding_left',
                    'type' 	=> 'input',
                    'value' => ''
                ),
                array(
                    'label' => __('Padding right', APS_PB_LANG),
                    'desc' 	=> __('ex: 50px', APS_PB_LANG),
                    'id' 	=> 'padding_left',
                    'type' 	=> 'input',
                    'value' => ''
                ),
				
			);
		}
				
		function shortcode_handler($atts, $content='')
		{
			extract( shortcode_atts( array(
				'id'    => '',
				'class' => '',
				'style' => '',
				'icon'			 => '',
                'customize' => 'no',
 				'icon_color' => '',
				'icon_bg_color' => '',
				'icon_bg_type'	=> '',//square,circle
				'size'					=> '',
				'border_color'	=> '',
				'border_width'  => '',
                'display'   => 'inline',
                'align' => 'left',
                'padding_left' => '',
                'padding_right' => ''
			), $atts ) );
			
			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? 'aps-icon ' . esc_attr( $class ) : 'aps-icon';

            //Size of icon con background color
            $style_size = '';
            if ($icon_bg_color!=''){
                $size_number = str_replace('px','',$size);
                $width = intval( $size_number * 1.5 );
                //$line_height = intval(($width+$size_number)/2);
                $line_height = $width;
                $style_size = "width:{$width}px;height:{$width}px;line-height:{$line_height}px;";
            }

			$size = ( $size != '' ) ? ' font-size:'.$size.';' : '';

            if ($customize = 'yes')
            {
                $border_color = ( $border_color != '' ) ? ' border-color:'.$border_color.';' : '';
                $border_width = ( $border_width != '' ) ? ' border-width:'.$border_width.'; border-style:solid;' : '';

                //Icon
                $icon_color = ( $icon_color != '' ) ? " color:{$icon_color};" : '';
                $icon_bg_color = ( $icon_bg_color != '' ) ? " background-color:{$icon_bg_color};" : '';
                switch ($icon_bg_type){
                    case ('square'):
                        $icon_bg_type = " border-radius:0em;";
                        break;
                    case ('rounded'):
                        $icon_bg_type = " border-radius:5%;";
                        break;
                    default:
                        $icon_bg_type = " border-radius:99em;";
                }
            } else
            {
                $icon_color = '';
                $icon_bg_color = '';
                $icon_bg_type = '';
                $border_color = '';
                $border_width = '';
            }

            if ($padding_left!='0px' && $padding_left!='') {
                $padding_left = 'padding-left:'.$padding_left.';';
            }
            if ($padding_right!='0px' && $padding_right!='') {
                $padding_right = 'padding-right:'.$padding_right.';';
            }




            $html = '';
            if ( $display=='block' ) { $html .= "<div style=\"text-align:{$align};\">"; }

			$html .= "<i {$id} class=\"aps-icon fa {$icon}\" style=\"{$style}{$icon_color}{$icon_bg_color}{$icon_bg_type}{$size}{$style_size}{$border_color}{$border_width}{$padding_left}{$padding_right}\"></i>";

            if ($display=='block') { $html .= "</div>"; }

			return $html;
		}
		
	}
}