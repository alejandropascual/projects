<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_image' ) ) 
{
	class aps_image extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Image',
				'shortcode' => 'aps_image',
                'tab' 		=> __('MEDIA',APS_PB_LANG),
				'order' 	=> 40,
				//'direct_insert' => "[aps_line]"
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',	
				),
				array(
					'label'	=> __('Select image', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'image',
					'type' 	=> 'image_src',
					'value' => '',
					'button' => __('Select image',APS_PB_LANG)
				),
                array(
                    'label'	=> __('Custom size', APS_PB_LANG),
                    'desc' 	=> __('Image can be resized to custom dimensions.<br> If image cannot be resized then the original image will be shown.', APS_PB_LANG),
                    'id' 	=> 'size',
                    'type' 	=> 'select',
                    'value' => 'no',
                    'options' => array(
                        'wp' => 'Size from wordpress',
                        'custom' => 'Resize image'
                    )
                ),
                array(
                    'label'	=> __('Width in pixels', APS_PB_LANG),
                    'desc' 	=> __('ex: 300', APS_PB_LANG),
                    'id' 	=> 'width',
                    'type' 	=> 'input',
                    'value' => '300',
                    'required' => 'size->custom'
                ),
                array(
                    'label'	=> __('Height in pixels', APS_PB_LANG),
                    'desc' 	=> __('ex: 300', APS_PB_LANG),
                    'id' 	=> 'height',
                    'type' 	=> 'input',
                    'value' => '300',
                    'required' => 'size->custom'
                ),
			);
		}
		
		
		

		
		function shortcode_handler($atts, $content='')
		{
			extract( shortcode_atts( array(
                'id'     => '',
                'class'  => '',
                'style'  => '',
                'image_src' => '',
                'image_id' => '',
                'image_size' => 'full',
                'size' => 'wp',
                'width' => 300,
                'height' => 300
			), $atts ) );
			
			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? ' ' . esc_attr( $class ) : '';
			$style = ( $style != '' ) ? 'style="' . $style . '"' : '';

			
			$html = '';
			$img_src = '';
			$title = '';
			$description = '';

            if ($size=='custom')
            {
                $image_resized = aps_get_image_resized_for_id($image_id, $width, $height, 0, 'no');
                if (isset($image_resized['resized'])){
                    $img_html = $image_resized['resized']['img'];
                } else {
                    $img_html = $image_resized['full']['img'];
                }


            } else {
                if ($image_src!='')
                {
                    $img_src = $image_src;
                    $img_html = '<img src="'.$img_src.'">';

                } else {
                    $attachment = get_post($image_id);
                    if ($attachment)
                    {
                        $img_poster = wp_get_attachment_image_src($attachment->ID, $image_size);
                        $img_src = $img_poster[0];
                        $title = trim($attachment->post_title) ? esc_attr($attachment->post_title) : "";
                        $description = trim($attachment->post_content) ? esc_attr($attachment->post_content) : "";
                        $alt = get_post_meta($image_id, '_wp_attachment_image_alt', true);
                        if( !count($alt)) { $alt = $description; }
                    }
                    $img_html = '<img src="'.$img_src.'" alt="'.$alt.'">';
                }
            }


			$html .= "<div {$id} {$style} class=\"{$class} image poster\">";
			$html .= $img_html;
			$html .= '</div>';
			return $html;	
		}
			
		
	}
}