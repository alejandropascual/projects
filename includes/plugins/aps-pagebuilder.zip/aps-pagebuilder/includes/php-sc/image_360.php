<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }


if ( !class_exists( 'aps_image360' ) )
{
    class aps_image360 extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' 		=> 'Image 360',
                'shortcode' => 'aps_image360',
                'tab' 		=> __('MEDIA',APS_PB_LANG),
                'order' 	=> 401,
                //'direct_insert' => "[aps_image360]"
            );
        }


        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),
                array(
                    'label'	=> __('URL first image', APS_PB_LANG),
                    'desc' 	=> __('ex: http://.../images/image_001.jpg<br>First image must begin with number 1', APS_PB_LANG),
                    'id' 	=> 'url_first_image',
                    'type' 	=> 'input',
                    'value' => 'http://',
                ),
                array(
                    'label'	=> __('Number last image', APS_PB_LANG),
                    'desc' 	=> __('ex: 100', APS_PB_LANG),
                    'id' 	=> 'last_image',
                    'type' 	=> 'input',
                    'value' => '100',
                ),
                array(
                    'label'	=> __('Autoload images', APS_PB_LANG),
                    'desc' 	=> __('Images are loaded when page is loaded (YES), <br>or when user touches the 360 view (NO)', APS_PB_LANG),
                    'id' 	=> 'autoload',
                    'type' 	=> 'select_yes_no',
                    'value' => 'no',
                )
            );
        }


        function shortcode_handler($atts, $content='')
        {
            extract( shortcode_atts( array(
                'id'     => 'id-'.uniqid(),
                'class'  => '',
                'style'  => '',
                'url_first_image' => '',
                'last_image' => 100,
                'autoload' => 'no'
            ), $atts ) );

            $class = ( $class != '' ) ? ' ' . esc_attr( $class ) : '';
            $style = ( $style != '' ) ? 'style="' . $style . '"' : '';

            $html = '';

            preg_match('/(http:.+\/.+_)(\d+)\.(.+)/', $url_first_image, $match);

            if ( $match && isset($match[3]) )
            {
                $html .= '
	<div id="'.$id.'" data-autoload="'.$autoload.'" class="aps_image_360" class="'.$class.'" '.$style.'
	    data-url_images="'.$match[1].'"
	    data_first_image="'.$match[2].'" data-last_image="'.$last_image.'" data-image_extension="'.$match[3].'"
	    >
		<div class="aps_image_360_preview">
			<img class="image_preview" src="'.$url_first_image.'">
			<div class="icon_load_360 fa fa-arrows-h"></div>
		</div>
		<div class="aps_image_360_spinner"><span>0%</span></div>
		<ol class="aps_image_360_images"></ol>
	</div>';
            }

            return $html;
        }


    }
}