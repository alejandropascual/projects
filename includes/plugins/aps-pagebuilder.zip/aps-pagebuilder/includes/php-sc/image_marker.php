<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_image_marker' ) )
{
    class aps_image_marker extends APSShortcode
    {
        function create_shortcode_options()
        {
            $this->options = array(
                'name' 		=> 'Image Markers',
                'shortcode' => 'aps_image_marker',
                'tab' 		=> __('MEDIA',APS_PB_LANG),
                'order' 	=> 130,
                'direct_insert' => "[aps_image_marker image_id='123' image_size='full' icon_size='31px' icon_color='black' icon_back_color='rgba(255,255,255,0.7)']<br>
[aps_marker top=20% left=30% title='The title 1' place='left']Description[/aps_marker]<br>
[aps_marker top=40% left=30% title='The title 2' place='top']Description[/aps_marker]<br>
[aps_marker top=80% left=30% title='The title 3' place='right']Description[/aps_marker]<br>
[/aps_image_marker]"
            );
        }


        function modal_fields()
        {
            $this->fields = array();
        }



        function shortcode_handler($atts, $content='')
        {
            extract( shortcode_atts( array(
                'id'    		=> 'id-'.uniqid(),
                'class'  		=> '',
                'style'  	    => '',
                'image_id'		=> '',
                'image_size'	=> '',
                //'icon_id' 	=> '',
                'icon_width' 	=> '',
                'icon_height'   => '',
                'icon_size'     => '31px',
                'icon_color'    => 'black',
                'icon_back_color' => 'rgba(255,255,255,0.7)'

            ), $atts ) );

            $id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $class = ( $class != '' ) ? ' ' . esc_attr( $class ) : '';
            $style = ( $style != '' ) ? 'style="' . $style . '"' : '';


            //Imagen
            $img_poster = '';
            $attachment = get_post($image_id);
            if ($attachment) {
                $img_poster = wp_get_attachment_image_src($attachment->ID, $image_size);
                $img_poster = $img_poster[0];

                $title = trim($attachment->post_title) ? esc_attr($attachment->post_title) : "";
                $description = trim($attachment->post_content) ? esc_attr($attachment->post_content) : "";
                $alt = get_post_meta($image_id, '_wp_attachment_image_alt', true);
                if( !count($alt)) { $alt = $description; }
            }

            $str = " icon_width=\"{$icon_size}\" icon_height=\"{$icon_size}\" icon_color=\"{$icon_color}\" icon_back_color=\"{$icon_back_color}\"";
            $new_content = $this->add_to_shortcode( $content, 'aps_marker', $str);

            $html = "<div {$id} {$style} class=\"aps-image-marker{$class}\">";
            $html .= "<img class=\"image-poster\" src=\"{$img_poster}\" alt=\"{$alt}\">";
            $html .= do_shortcode($new_content);
            $html .= "</div>";
            return $html;
        }

    }
}




if ( !class_exists( 'aps_marker' ) )
{
    class aps_marker extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' 		=> 'Marker',
                'shortcode' => 'aps_marker',
                'tab' 		=> __('Wrap-Content',APS_PB_LANG),
                'order' 	=> 30,
                'direct_insert' => "[aps_marker top=20% left=30% title='Title' content='Description' place='left']",
                'hidden' => 'yes'
            );
        }


        function modal_fields()
        {
            $this->fields = array();
        }


        function shortcode_handler($atts, $content='')
        {
            extract( shortcode_atts( array(
                'top'	 				=> '', //%
                'left' 				=> '', //%
                'title' 			=> '',
                //'content' 		=> '',
                'place'				=> '',//left,right,top,bottom
                //'icon_src' 		=> '',
                'icon_width' 	=> '',
                'icon_height'   => '',
                'icon_color'    => 'black',
                'icon_back_color' => 'rgba(255,255,255,0.7)'
            ), $atts ) );

            $ancho = str_replace('px','',$icon_width);
            $alto = str_replace('px','',$icon_height);

            $w2 = intval($ancho/2);
            $h2 = intval($alto/2);

            static $count = 0; $count++;

            //$content = esc_html(do_shortcode($content));
            $content = esc_attr(do_shortcode($content));

            $html = '';
            $html .= "<div class=\"marker marker-{$count}\" data-container=\"body\"";
            $html .= " data-placement=\"{$place}\"";
            $html .= " data-title=\"{$title}\"";
            $html .= " data-content=\"{$content}\"";
            $html .= " style=\"width:{$icon_width}; height:{$icon_height}; top:{$top}; left:{$left}; margin-top:-{$w2}px; margin-left:-{$h2}px;\">";

            $html .= '<?xml version="1.0" encoding="utf-8"?><!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
            <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                 width="100%" height="100%" viewBox="0 0 42 42" enable-background="new 0 0 42 42" xml:space="preserve">
            <circle fill="' . $icon_back_color. '" stroke="' . $icon_color. '" stroke-miterlimit="10" cx="21" cy="21" r="20"/>
            <line fill="none" stroke="' . $icon_color. '" stroke-miterlimit="10" x1="21" y1="6" x2="21" y2="36"/>
            <line fill="none" stroke="' . $icon_color. '" stroke-miterlimit="10" x1="6" y1="21" x2="36" y2="21"/>
            </svg>';

            //$html .= "<img src=\"{$icon_src}\">";
            //$html .= '<span class="marker-icon" style="border-color:'.$icon_color.';background-color:'.$icon_back_color.';">';
            //$html .= '<span class="before" style="background-color:'.$icon_color.';"></span>';
            $html .= '<span class="after" style="background-color:'.$icon_color.';"></span>';
            $html .= '</span>';
            $html .= "</div>";

            return $html;
        }




    }
}
