<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_infobox' ) ) {
    class aps_infobox extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Info Box',
                'shortcode' => 'aps_infobox',
                'tab' => __('CONTENT', APS_PB_LANG),
                'order' => 80
            );

        }

        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),
                array(
                    'label'	=> __('Type', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'type',
                    'type' 	=> 'select',
                    'value' => '1',
                    'options' => array(
                        '1'   => 'No-border',
                        '2'   => 'Border 1px',
                        '3'   => 'Border 3px',
                        '4'   => 'Dashed',
                        '5'   => 'Border top strong',
                        '6'   => 'Border left strong',
                        '7'   => 'Border left and right',
                        '8'   => 'Border top and bottom'
                    )
                ),
                array(
                    'label'	=> __('Align text', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'align',
                    'type' 	=> 'select',
                    'value' => 'left',
                    'options' => array(
                        'left'   => 'left',
                        'center'   => 'center',
                        'right'   => 'right'
                    )
                ),
                array(
                    'label'	=> __('Title heading', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'title_size',
                    'type' 	=> 'select',
                    'value' => 'h1',
                    'options' => array(
                        'h1'   => 'H1',
                        'h2'   => 'H2',
                        'h3'   => 'H3',
                        'h4'   => 'H4',
                        'h5'   => 'H5',
                        'h6'   => 'H6'
                    )
                ),
                array(
                    'label'	=> __('Title', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'title',
                    'type' 	=> 'textarea',
                    'value' => 'Title here'
                ),
                array(
                    'label'	=> __('Text', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'content_sc',
                    'type' 	=> 'textarea',
                    'value' => 'Text here'
                ),

                array(
                    'label'	=> __('With button ?', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'use_button',
                    'type' 	=> 'select',
                    'value' => 'no',
                    'options' => array('yes'=>'YES','no'=>'NO')
                ),
                array(
                    'label'	=> __('Button text', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'btn_text',
                    'type' 	=> 'input',
                    'value' => 'BUTTON',
                    'required' => 'use_button->yes'
                ),
                array(
                    'label'	=> __('Button link', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'btn_link',
                    'type' 	=> 'input',
                    'value' => 'http://',
                    'required' => 'use_button->yes'
                ),
                array(
                    'label'	=> __('Button target', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'btn_target',
                    'type' 	=> 'select',
                    'value' => '_blank',
                    'options' => array(
                        '_self'   => __('Open in the same window',APS_PB_LANG),
                        '_blank'  => __('Open in a new window',APS_PB_LANG)
                    ),
                    'required' => 'use_button->yes'
                ),
                array(
                    'label'	=> __('Button position', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'btn_position',
                    'type' 	=> 'select',
                    'value' => 'bottom',
                    'options' => array(
                        'bottom'   => 'Bottom',
                        'left'   => 'Left',
                        'right'   => 'Right'
                    ),
                    'required' => 'use_button->yes'
                ),

                array(
                    'label'	=> __('Button size', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'btn_size',
                    'type' 	=> 'select',
                    'value' => 'bottom',
                    'options' => array(
                        'x-small'  => __('X-Small',APS_PB_LANG),
                        'small'	   => __('Small',APS_PB_LANG),
                        'medium'   => __('Medium',APS_PB_LANG),
                        'large'    => __('Large',APS_PB_LANG),
                        'x-large'  => __('X-Large',APS_PB_LANG),
                        'super'    => __('Super',APS_PB_LANG),
                    ),
                    'required' => 'use_button->yes'
                ),
                array(
                    'label' => __('Full Width Button ?', APS_PB_LANG),
                    'desc' 	=> __('Is valid only when the button is at the Bottom.', APS_PB_LANG),
                    'id' 	=> 'btn_full_width',
                    'type' 	=> 'select',
                    'value' => 'no',
                    'options' => array(
                        'yes'	=> __('Yes',APS_PB_LANG),
                        'no'	=>__('No',APS_PB_LANG),
                    ),
                    'required' => 'use_button->yes'
                ),
                array(
                    'label' => __('TYPE of Button', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'btn_type',
                    'type' 	=> 'select',
                    'value' => 'flat',
                    'options' => array(
                        'flat'	=> __('Flat',APS_PB_LANG),
                        'ghost'	=> __('Ghost',APS_PB_LANG),
                    ),
                    'required' => 'use_button->yes'
                ),
                array(
                    'label' => __('Button SHAPE', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'btn_shape',
                    'type' 	=> 'select',
                    'value' => 'square',
                    'options' => array(
                        'square'	=> __('Square',APS_PB_LANG),
                        'rounded'	=> __('Rounded',APS_PB_LANG),
                        'pill'	    => __('Pill',APS_PB_LANG),
                    ),
                    'required' => 'use_button->yes'
                ),
                array(
                    'label'	=> __('Color Style', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'btn_skin',
                    'type' 	=> 'select',
                    'value' => '',
                    'options' => array(
                        'heading'   => __('Heading color',APS_PB_LANG),
                        'text'	    =>__('Text color',APS_PB_LANG),
                        'title'	    => __('Title color',APS_PB_LANG),
                        'link'	    => __('Link color',APS_PB_LANG),
                        'hoverlink'	=> __('Hover Link color',APS_PB_LANG)
                    ),
                    'required' => 'use_button->yes'
                ),

            );
        }

        function shortcode_handler($atts, $content='')
        {
            extract( shortcode_atts( array(
                'id'     => '',
                'class'  => '',
                'style'  => '',
                'type'  => '1',//Define el estilo del infobox
                'align' => 'left',
                'title' => '',
                'title_size' => 'h1',

                'use_button' => 'yes',

                'btn_text' => '',
                'btn_link' => '',
                'btn_target' => '_self',
                'btn_size' => 'medium',
                'btn_full_width' => 'no',
                'btn_position' => 'bottom', //left,right
                'btn_type' => 'flat',
                'btn_shape' => 'square',
                'btn_skin' => 'heading'
            ), $atts ) );

            $id = ( $id != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $class = ( $class != '' ) ? ' ' . esc_attr( $class ) : '';

            $style = "text-align:{$align};".$style;

            $html = '';
            $html .= "<div {$id} style=\"{$style}\" class=\"{$class} aps-infobox infobox-type_{$type}\">";

            //Title
            $html_title = '';
            if ($title!='') {
                $html_title = "<{$title_size} class=\"info-title\">{$title}</{$title_size}>";
            }

            //Content
            $html_content = do_shortcode(apply_filters('the_content', $content));

            //Button
            $html_button = '';
            if ($use_button=='yes')
            {
                $class_button  = 'aps-btn-theme';
                $class_button .= ' aps-btn-'.$btn_size;
                $class_button .= ' aps-btn-'.$btn_shape;
                $class_button .= ' type-'.$btn_type;
                $class_button .= ' btn-theme-'.$btn_skin;

                //Full width at the bottom
                if ($btn_full_width == 'yes' && $btn_position=='bottom') {
                    $class_button .= ' aps-btn-fullwidth';
                }
                //Fullwidth on left or right
                else if ($btn_full_width == 'yes' && $btn_position != 'bottom' ) {
                    $class_button .= ' aps-btn-fullwidth';
                }
                else {
                    $class_button .= ' button-'.$btn_position;
                }

                $html_button = "<a class=\"info-button {$class_button}\" href=\"{$btn_link}\" target=\"{$btn_target}\">{$btn_text}</a>";
            }

            //HTML completo
            if ($btn_position == 'left' || $btn_position == 'right') {
                $html .= $html_button.$html_title.$html_content;
            } else {
                $html .= $html_title.$html_content.$html_button;
            }


            $html .= "</div>";
            return $html;
        }
    }
}