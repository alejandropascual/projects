<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_line' ) ) 
{
	class aps_line extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Line',
				'shortcode' => 'aps_line',
                'tab' 		=> __('CONTENT',APS_PB_LANG),
				'order' 	=> 40,
				//'direct_insert' => "[aps_line]"
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',	
				),
				array(
					'label'	=> __('Color', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'color',
					'type' 	=> 'colorpicker',	
					'value' => '#000000',
				),
				array(
					'label'	=> __('Width', APS_PB_LANG),
					'desc' 	=> __('Insert in pixels, example: 5px', APS_PB_LANG),
					'id' 	=> 'width',
					'type' 	=> 'input',	
					'value' => '1px',
				),
				array(
					'label'	=> __('Type', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'type',
					'type' 	=> 'select',	
					'value' => 'solid',
					'options' => array('solid'=>'Solid','dashed'=>'Dashed', 'dotted'=>'Dotted')
				),
				
				
			);
		}
		
		
		

		
		function shortcode_handler($atts, $content='')
		{
		  extract( shortcode_atts( array(
		    'id'    => '',
		    'class' => '',
		    'style' => '',
		    'color' => '',
		    'width' => '',
		    'type' 	=> ''
		    
		  ), $atts ) );
		  $id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
		  $class = ( $class != '' ) ? 'aps-line ' . esc_attr( $class ) : 'aps-line';
		  $style = "style=\"{$style}; border-color:{$color}; border-width:{$width}; border-top-style:{$type};\"";
		  
		  $html = "<hr {$id} class=\"{$class}\" {$style}>";
		  return $html;
		}
		
	}
}