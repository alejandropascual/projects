<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_list' ) )
{
    class aps_list extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' 		=> 'List with icons',
                'shortcode' => 'aps_list',
                //'shortcode_nested' => array('aps_list_li'),
                'tab' 		=> __('CONTENT',APS_PB_LANG),
                'order' 	=> 70,
                //'direct_insert' => "[aps_line]"
            );
        }


        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),

                array(
                    'label' => __('Content', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'content_sc',
                    'type' 	=> 'tinymce',
                    'value' => '<ul><li>List item 1</li><li>List item 2</li><li>List item 3</li></ul>',
                ),
                array(
                    'label' => __('Icon', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'icon',
                    'type' 	=> 'iconfont',
                    'value' => '',
                ),
                array(
                    'label'	=> __('Color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'color',
                    'type' 	=> 'colorpicker',
                    'value' => '#000000',
                ),
                array(
                    'label' => __('Use Back Color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'use_bc_color',
                    'type' 	=> 'select',
                    'value' => 'no',
                    'options' => array(
                        'yes'	=>'Yes',
                        'no'	=>'No',
                    )
                ),
                array(
                    'label'	=> __('Back color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'bc_color',
                    'type' 	=> 'colorpicker',
                    'value' => '#000000',
                    'required'=>'use_bc_color->yes'
                ),
                array(
                    'label'	=> __('Back shape', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'bc_shape',
                    'type' 	=> 'select',
                    'value' => 'circle',
                    'options' => array(
                        'circle' => 'Circle',
                        'square' => 'Square'
                    ),
                    'required'=>'use_bc_color->yes'
                ),

            );
        }





        function shortcode_handler($atts, $content='')
        {
            extract( shortcode_atts( array(
                'id'    => '',
                'class' => '',
                'style' => '',
                'icon' => '',
                'color' => '',
                'use_bc_color' 	=> '',
                'bc_color' => '',
                'bc_shape' => ''

            ), $atts ) );

            static $count = 0; $count++;

            global $list_icons;
            //echo '<pre>'; print_r( $list_icons ); echo '</pre>';
            $code = $list_icons[$icon];
            //echo '<pre>'; print_r( $code ); echo '</pre>';

            $id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $class = ( $class != '' ) ? 'aps-list-icon ' . esc_attr( $class ): 'aps-list-icon';
            $style = ( $style != '' ) ? 'style="' . $style . '"' : '';

            $style_icon = '';
            if ( $color != '') {
                $style_icon .= "color:{$color};";
            }
            if ($use_bc_color == 'yes') {
                $style_icon .= "background-color:{$bc_color};";

                if ($bc_shape == 'circle') {
                    $class .= ' icon-circle';
                } else if ($bc_shape == 'square') {
                    $class .= ' icon-square';
                }
            }


            $html = '<style>#id-list-icon-'.$count.' li:before { content:"'.$code.'";'.$style_icon.'}</style>';

            $html .= "<div id=\"id-list-icon-{$count}\">";

            $html .= "<div {$id} class=\"{$class}\" {$style}>";
            $html .= do_shortcode($content);
            $html .= "</div>";
            $html .= "</div>";
            return $html;
        }

    }
}

/*
if ( !class_exists( 'aps_list_li' ) ) {
    class aps_list_li extends APSShortcode
    {
        function create_shortcode_options()
        {
            $this->options = array(
                'name' 		=> 'List item',
                'shortcode' => 'aps_list_li',
                'tab' 		=> __('Wrap-Content',APS_PB_LANG),
                'order' 	=> 30,
                'direct_insert' => '[aps_list_li]Content here[/aps_list_li]',
                'hidden' => 'yes'
            );
        }

        function modal_fields()
        {
            $this->fields = array();
        }

        function shortcode_handler($atts, $content='')
        {
            return '<li>'.do_shortcode($content).'</li>';
        }
    }
}
*/