<?php
if (have_posts())
{
	while (have_posts())
	{
 		the_post();
 		?>
 		<article id="post-<?php the_ID(); ?>" <?php post_class('selector'); ?>>
			<?php echo_pb_template_media('bottom-left',4); ?>
			<div class="post_text">
				<?php echo_pb_template_date(); ?>
				<?php echo_pb_template_meta(); ?>
				<?php echo_pb_template_title(); ?>
				<?php echo_pb_template_content(); ?>
				<?php echo_pb_template_social(); ?>
			</div>
		</article>
 		<?php
 	}
}

