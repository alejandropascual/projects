<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_map' ) ) {
    class aps_map extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Map address',
                'shortcode' => 'aps_map',
                'tab' => __('MAPS', APS_PB_LANG),
                'order' => 60,

            );
        }

        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),
                array(
                    'label' => __('MAP Width', APS_PB_LANG),
                    'desc'  => __('example: 100% , 500px , etc', APS_PB_LANG),
                    'id'    => 'map_width',
                    'type'  => 'input',
                    'value' => '100%',
                ),
                array(
                    'label' => __('MAP Height', APS_PB_LANG),
                    'desc'  => __('example: 500px', APS_PB_LANG),
                    'id'    => 'map_height',
                    'type'  => 'input',
                    'value' => '500px',
                ),
                array(
                    'label' => __('MAP Border', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'map_border',
                    'type'  => 'select_yes_no',
                    'value' => 'yes',
                ),
                array(
                    'id'		=> 'map_style',
                    'label'		=> __('Maps style', APS_PB_LANG),
                    'desc'		=> __('', APS_PB_LANG),
                    'type' 		=> 'select',
                    'options' => array(
                        'Default Google' => 'Default Google',
                        'Pale Dawn' => 'Pale Dawn',
                        'Subtle Grayscale' => 'Subtle Grayscale',
                        'Blue Water' => 'Blue Water',
                        'Midnight Commander' => 'Midnight Commander',
                        'Retro' => 'Retro',
                        'Shades of Gray' => 'Shades of Gray',
                        'Light Monochrome' => 'Light Monochrome',
                        'Grayscale' => 'Grayscale',
                        'Subtle' => 'Subtle',
                        'Paper' => 'Paper',
                        'Neutral Blue' => 'Neutral Blue',
                        'Apple Maps-esque' => 'Apple Maps-esque',
                        'Shift Worker' => 'Shift Worker',
                        'Pink & Blue' => 'Pink & Blue',
                        'Night vision' => 'Night vision',
                        'Light Green' => 'Light Green',
                        'Hints of Gold' => 'Hints of Gold'
                    )
                ),
                array(
                    'id'		=> 'icon_color',
                    'label'		=> __('Color icons', APS_PB_LANG),
                    'desc'		=> __('', APS_PB_LANG),
                    'type' 		=> 'colorpicker',
                ),
                array(
                    'id'		=> 'icon_type',
                    'label'		=> __('Project icon type', APS_PB_LANG),
                    'desc'		=> __('', APS_PB_LANG),
                    'type' 		=> 'select',
                    'options'	=> array(
                        'icon-map-square-40'=>'Square',
                        'icon-map-circle-40'=>'Circle',
                    ),
                ),
                array(
                    'id'		=> 'address',
                    'label'		=> __('Address', APS_PB_LANG),
                    'desc'		=> __('Add address for the map here. <br>For multiple addresses, separate addresses by using the | symbol.<br>ex: Address 1|Address 2|Address 3', APS_PB_LANG),
                    'type' 		=> 'textarea',
                ),
                array(
                    'id'		=> 'zoom',
                    'label'		=> __('Zoom', APS_PB_LANG),
                    'desc'		=> __('1 to 20', APS_PB_LANG),
                    'type' 		=> 'input',
                    'value'     => 3
                )
            );
        }

        function shortcode_handler( $atts, $content = null )
        {
            extract( shortcode_atts( array(
                'id'        => '',
                'class'     => '',
                'style'     => '',
                'map_width' => '100%',
                'map_height' => '400px',
                'map_border' => 'yes',
                'icon_type' => 'icon-map-circle-40',
                'icon_color' => 'black',
                'map_style' => 'Default Google',
                'address' => '',
                'zoom' => 3,
            ), $atts ) );


            $html = '';

            $html  = '<div class="map_canvas_address"';
            $html .= ' style="width:'.$map_width.';height:'.$map_height.';display:block;"';
            $html .= ' data-address="'.esc_attr($address).'"';
            $html .= ' data-zoom="'.$zoom.'"';
            $html .= ' data-coord="-122.423401,37.757959"';
            $html .= ' data-icon-class="'.$icon_type.'"'; //icon-map-circle-70
            $html .= ' data-color="'.$icon_color.'"';
            $html .= ' data-mapstyle="'.$map_style.'"';
            $html .= '></div>';

            wp_enqueue_script( 'aps-maps' );

            return $html;
        }
    }
}