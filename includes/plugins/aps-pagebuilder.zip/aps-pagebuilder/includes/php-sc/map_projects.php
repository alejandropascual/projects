<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_map_projects' ) )
{
    class aps_map_projects extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' 		=> 'Projects Map',
                'shortcode' => 'aps_map_projects',
                'tab' 		=> __('MAPS',APS_PB_LANG),
                'order' 	=> 50,

            );
        }

        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),

                //Select by filter or specific posts
                array(
                    'label' => __('Select posts by', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'select_by',
                    'type'  => 'select',
                    'options' => array('by_filter'=>'Filter by category | tag', 'by_ids'=>'Posts by ID')
                ),

                //Muestra las categorias de cada custom post
                array(
                    'label' => __('Filter categories', APS_PB_LANG),
                    'desc'  => __('Select multiple categories or leave it blank for all', APS_PB_LANG),
                    'id'    => 'categories_post',
                    'type'  => 'select_custom_categories',
                    'required' => 'select_by->by_filter',
                    'include_custom_posts' => array('aps_project')
                ),

                //Muestra los tags de cada custom post
                array(
                    'label' => __('Filter tags', APS_PB_LANG),
                    'desc'  => __('Select multiple tags or leave it blank for all', APS_PB_LANG),
                    'id'    => 'tags_post',
                    'type'  => 'select_custom_tags',
                    'required' => 'select_by->by_filter',
                    'include_custom_posts' => array('aps_project')
                ),

                //Escribir los ids
                array(
                    'label' => __('Post ID', APS_PB_LANG),
                    'desc'  => __('Write the ID of the posts you want to display.<br>For example: 45,78', APS_PB_LANG),
                    'id'    => 'post_ids',
                    'type'  => 'input',
                    'value' => '',
                    'required' => 'select_by->by_ids',
                ),

                // Dimensones mapa
                array(
                    'id'		=> 'map_style',
                    'label'		=> __('Maps style', APS_PB_LANG),
                    'desc'		=> __('', APS_PB_LANG),
                    'type' 		=> 'select',
                    'options' => array(
                        'Default Google' => 'Default Google',
                        'Pale Dawn' => 'Pale Dawn',
                        'Subtle Grayscale' => 'Subtle Grayscale',
                        'Blue Water' => 'Blue Water',
                        'Midnight Commander' => 'Midnight Commander',
                        'Retro' => 'Retro',
                        'Shades of Gray' => 'Shades of Gray',
                        'Light Monochrome' => 'Light Monochrome',
                        'Grayscale' => 'Grayscale',
                        'Subtle' => 'Subtle',
                        'Paper' => 'Paper',
                        'Neutral Blue' => 'Neutral Blue',
                        'Apple Maps-esque' => 'Apple Maps-esque',
                        'Shift Worker' => 'Shift Worker',
                        'Pink & Blue' => 'Pink & Blue',
                        'Night vision' => 'Night vision',
                        'Light Green' => 'Light Green',
                        'Hints of Gold' => 'Hints of Gold'
                    )
                ),
                array(
                    'id'		=> 'icon_color',
                    'label'		=> __('Color icons', APS_PB_LANG),
                    'desc'		=> __('', APS_PB_LANG),
                    'type' 		=> 'colorpicker',
                ),
                array(
                    'id'		=> 'icon_type',
                    'label'		=> __('Project icon type', APS_PB_LANG),
                    'desc'		=> __('', APS_PB_LANG),
                    'type' 		=> 'select',
                    'options'	=> array(
                        'icon-map-square-70'=>'Square with image',
                        'icon-map-circle-70'=>'Circle with image',
                        'icon-map-square-40'=>'Square',
                        'icon-map-circle-40'=>'Circle',
                    ),
                ),

                array(
                    'label' => __('MAP Width', APS_PB_LANG),
                    'desc'  => __('example: 100% , 500px , etc', APS_PB_LANG),
                    'id'    => 'map_width',
                    'type'  => 'input',
                    'value' => '100%',
                ),
                array(
                    'label' => __('MAP Height', APS_PB_LANG),
                    'desc'  => __('example: 500px', APS_PB_LANG),
                    'id'    => 'map_height',
                    'type'  => 'input',
                    'value' => '500px',
                ),
                array(
                    'label' => __('MAP Border', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'map_border',
                    'type'  => 'select_yes_no',
                    'value' => 'yes',
                ),
            );

        }

        function shortcode_handler( $atts, $content = null )
        {
            extract( shortcode_atts( array(
                'id'        => '',
                'class'     => '',
                'style'     => '',
                'select_by' => '',
                'post_ids'  => '',
                'categories_post' => '',
                'tags_post' => '',
                'map_width' => '100%',
                'map_height' => '400px',
                'map_border' => 'yes',
                'icon_type' => 'icon-map-circle-70',
                'icon_color' => 'black',
                'map_style' => 'Default Google'
            ), $atts ) );

            $id = ( $id != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $class = ( $class != '' ) ? esc_attr( $class ) : '';
            $style = ( $style != '' ) ? esc_attr( $style ) : '';

            if ($map_border == 'no') {
                $class .= ' hidden-border';
            }

            $html = '';

            //Esto no lo estoy usando al final
            /*$resize_data = array(
                'width'     => 70,
                'height'    => 70,
                'prop'      => 1,
                'aumentar'  => 'no'
            );*/

            $query_data = array(
                'post_type'         => 'aps_project',
                'posts_per_page'    => -1,
                'post_status'       => 'publish',
            );

            //Posts especificos
            if ($post_ids)
            {
                $query_data['post__in'] = explode(',',$post_ids);
            }

            $projects_data = $this->query_posts_data( $query_data, $categories_post, $tags_post);

            /*$map_options = array(
                'icon_type' => aps_get_option('map_icons_type'),
                'icon_color' => aps_get_option('map_icons_color'),
                'map_style' => aps_get_option('map_style')
            );*/
            $map_options = array(
                'icon_type' => $icon_type,
                'icon_color' => $icon_color,
                'map_style' => $map_style
            );

            $html .= "<div {$id} style=\"{$style};width:{$map_width};\" class=\"map_projects post-box other-border {$class}\">";

            $html .= '<div class="map_canvas_projects" style="width:100%;height:'.$map_height.';"';
            $html .= ' data-projects_data="'.esc_attr(json_encode($projects_data)).'"';
            $html .= ' data-map_options="'.esc_attr(json_encode($map_options)).'"';
            $html .= '>MAPA</div>';

            $html .= '<div class="map_popup clearfix"><a class="popup-close">X</a><div class="popup-info"></div></div>';
            $html .= '</div>';

            wp_enqueue_script( 'aps-maps' );
            return $html;
        }

        function query_posts_data($query_data, $filter_categories, $filter_tags)
        {
            //Preparar query con categorias y tags
            $tax_query = array( 'relation' => 'AND' );

            //preparar categorias
            if (!empty($filter_categories)) {
                $cats = explode(',', $filter_categories);
                $query_cats = array();
                foreach( $cats as $cat ) {
                    list($taxonomy, $term) = explode('::', $cat);
                    if ( !array_key_exists($taxonomy, $query_cats) ) {
                        $query_cats[$taxonomy] = array(
                            'taxonomy' => $taxonomy,
                            'field' => 'slug',
                            'terms' => array($term)
                        );
                    } else {
                        $query_cats[$taxonomy]['terms'][] = $term;
                    }
                }
                $tax_query = array_merge($tax_query, $query_cats);
            }
            //preparar tags
            if (!empty($filter_tags)) {
                $tags = explode(',', $filter_tags);
                $query_tags = array();
                foreach( $tags as $tag ) {
                    list($taxonomy, $term) = explode('::', $tag);
                    if ( !array_key_exists($taxonomy, $query_tags) ) {
                        $query_tags[$taxonomy] = array(
                            'taxonomy' => $taxonomy,
                            'field' => 'slug',
                            'terms' => array($term)
                        );
                    } else {
                        $query_tags[$taxonomy]['terms'][] = $term;
                    }
                }
                $tax_query = array_merge($tax_query, $query_tags);
            }

            $query_data['tax_query'] = $tax_query;

            $my_query = new WP_Query( $query_data );
            $data = array();

            if ( $my_query->have_posts() ) {

                while ($my_query->have_posts()) {

                    $my_query->the_post();

                    $post_id = get_the_ID();
                    $has_map = get_post_meta( $post_id, 'project_has_map', true);
                    $map_coord = get_post_meta( $post_id, 'project_coord', true);
                    $map_address = get_post_meta( $post_id, 'project_address', true);

                    if ( $has_map == 'yes' )
                    {
                        //Thumbnail por defecto
                        $thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()));
                        $thumbnail_url = $thumbnail[0];

                        //Cojo uma imagen de 150px de alto mejor
                        $thumb_id = get_post_thumbnail_id(get_the_ID());
                        if ($thumb_id) {
                            $resized = aps_get_image_resized_for_id($thumb_id,0,150,0,'no');
                            $resized_url = $resized['resized']['url'];
                            //echo '<pre>'; print_r( $resized ); echo '</pre>';
                        } else {
                            $resized_url = null;
                        }


                        $data[] = array(
                            'title' => get_the_title(),
                            'excerpt' => get_the_excerpt(),
                            'thumbnail_url' => $thumbnail_url,
                            'image_resized_url' => $resized_url,
                            'map_coord' => $map_coord,
                            'map_address' => $map_address,
                            'permalink' => get_permalink()
                        );
                    }

                }
            }

            wp_reset_query();

            return $data;
        }
    }
}

