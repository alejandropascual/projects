<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_maps_all' ) ) {
    class aps_maps_all extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Maps all',
                'shortcode' => 'aps_maps_all',
                'tab' => __('MAPS', APS_PB_LANG),
                'order' => 60,
                'hidden' => 'yes'
            );
        }

        function modal_fields()
        {
            $this->fields = array(
            );
        }

        function shortcode_handler( $atts, $content = null )
        {
            extract( shortcode_atts( array(
                'id'        => '',
                'class'     => '',
                'style'     => '',
                'map_width' => '25%',
                'map_height' => '250px',
                'map_border' => 'no',
                'icon_type' => 'icon-map-circle-40',
                'icon_color' => 'black',
                'address' => '',
                'zoom' => 21,
            ), $atts ) );


            $html = '';

            //Genero los shortcodes para todos los mapas
            $maps =  array(
            'Default Google' => 'Default Google',
            'Pale Dawn' => 'Pale Dawn',
            'Subtle Grayscale' => 'Subtle Grayscale',
            'Blue Water' => 'Blue Water',
            'Midnight Commander' => 'Midnight Commander',
            'Retro' => 'Retro',
            'Shades of Gray' => 'Shades of Gray',
            'Light Monochrome' => 'Light Monochrome',
            'Grayscale' => 'Grayscale',
            'Subtle' => 'Subtle',
            'Paper' => 'Paper',
            'Neutral Blue' => 'Neutral Blue',
            'Apple Maps-esque' => 'Apple Maps-esque',
            'Shift Worker' => 'Shift Worker',
            'Pink & Blue' => 'Pink & Blue',
            'Night vision' => 'Night vision',
            'Light Green' => 'Light Green',
            'Hints of Gold' => 'Hints of Gold'
            );

            $shortcodes = '';
            foreach ($maps as $name){
                $shortcodes .= '<div style="display:inline-block;vertical-align: top;">';
                $shortcodes .= "[aps_map map_width='{$map_width}' map_height='{$map_height}' map_border='{$map_border}' map_style='{$name}' icon_color='{$icon_color}' icon_type='{$icon_type}' address='{$address}' zoom='{$zoom}']";
                $shortcodes .= '</div>';
            }
            $html .= do_shortcode($shortcodes);

            return $html;
        }
    }
}