<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_person' ) ) {
    class aps_person extends APSShortcode
    {
        function create_shortcode_options()
        {
            $this->options = array(
                'name' 		=> 'Person',
                'shortcode' => 'aps_person',
                'tab' 		=> __('CONTENT-2',APS_PB_LANG),
                'order' 	=> 50,
                'use_line_break' => 'no'
            );
        }
        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),
                array(
                    'label'	=> __('Layout style', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'layout',
                    'type' 	=> 'select',
                    'value' => '',
                    'options' => array('full' => 'Image full width', 'left' => 'Image small left')
                ),
                array(
                    'label'	=> __('Select image', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'image',
                    'type' 	=> 'image', //image_src
                    'value' => '',
                    'button' => __('Select image',APS_PB_LANG)
                ),
                /*array(
                    'label'	=> __('Man / Woman', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'man_woman',
                    'type' 	=> 'select',
                    'value' => '',
                    'options' => array('man'=>'Man','woman'=>'Woman')
                ),*/
                array(
                    'label'	=> __('Name', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'name',
                    'type' 	=> 'input',
                    'value' => '',
                ),
                array(
                    'label'	=> __('Title', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'title',
                    'type' 	=> 'input',
                    'value' => '',
                ),
                array(
                    'label'	=> __('Mail', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'mail',
                    'type' 	=> 'input',
                    'value' => '',
                ),
                array(
                    'label'	=> __('Facebook', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'facebook',
                    'type' 	=> 'input',
                    'value' => '',
                ),
                array(
                    'label'	=> __('Twitter', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'twitter',
                    'type' 	=> 'input',
                    'value' => '',
                ),
                array(
                    'label'	=> __('Linkedin', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'linkedin',
                    'type' 	=> 'input',
                    'value' => '',
                ),
                array(
                    'label'	=> __('Google Plus', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'googleplus',
                    'type' 	=> 'input',
                    'value' => '',
                ),
                array(
                    'label'	=> __('Dribble', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'dribbble',
                    'type' 	=> 'input',
                    'value' => '',
                ),
                array(
                    'label'	=> __('Brief', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'content_sc',
                    'type' 	=> 'textarea',
                    'value' => '',
                ),
            );
        }

        function shortcode_handler($atts, $content='')
        {
            extract( shortcode_atts( array(
                'id'     => '',
                'class'  => '',
                'style'  => '',
                'layout' => 'full',
                'image_src' => '',
                'image_id' => '',
                'image'	=> '',
                //'image_size' => 'large',
                //'man_woman' => '',
                'name' => '',
                'title' => '',
                'mail' => '',
                'facebook' => '',
                'twitter' => '',
                'linkedin' => '',
                'googleplus' => '',
                'dribbble' => ''
            ), $atts ) );

            //echo '<pre>'; print_r( $atts ); echo '</pre>';

            $id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $class = ( $class != '' ) ? ' ' . esc_attr( $class ) : '';
            $style = ( $style != '' ) ? 'style="' . $style . '"' : '';

            $html = '';
            $img_src = '';
            $title_img = '';
            $description = '';

            if ($image_src!=''){
                $img_src = $image_src;
            } else {
                if ($image_id == '') $image_id = $image;

                $attachment = get_post($image_id);
                if ($attachment)
                {
                    if ( $layout == 'full' ) { $image_size = 'large'; }
                    else { $image_size = 'thumbnail'; }

                    //echo '<pre>'; print_r($image_size); echo '</pre>';

                    $img_poster = wp_get_attachment_image_src($attachment->ID, $image_size);
                    $img_src = $img_poster[0];
                    $title_img = trim($attachment->post_title) ? esc_attr($attachment->post_title) : "";
                    $description = trim($attachment->post_content) ? esc_attr($attachment->post_content) : "";
                    $alt = get_post_meta($image_id, '_wp_attachment_image_alt', true);
                    if( !count($alt)) { $alt = $description; }}
            }

            $html .= "<div {$id} {$style} class=\"{$class} person person-{$layout}\">";
            $html .= '<img class="person-image" src="'.$img_src.'" alt="'.$alt.'">';

            //Social
            $html_social = '<span class="person-social">';
            //$html .= '<span class="person_social_holder">';
            $tooltip = 'data-toggle="tooltip" data-placement="top"';
            //Mail
            if ( $mail != '' ) {
                $html_social .= '<a href="mailto:' . $mail . '" target="_blank"><i class="fa fa-envelope aps-tooltip" '.$tooltip.' title="Mail"></i></a>';
            }
            //Facebook
            if ( $facebook != '' ) {
                $html_social .= '<a href="' . $facebook . '" target="_blank"><i class="fa fa-facebook aps-tooltip" '.$tooltip.' title="Facebook"></i></a>';
            }
            //Twitter
            if ( $twitter != '' ) {
                $html_social .= '<a href="' . $twitter . '" target="_blank"><i class="fa fa-twitter aps-tooltip" '.$tooltip.' title="Twitter"></i></a>';
            }
            //Linkedin
            if ( $linkedin != '' ) {
                $html_social .= '<a href="' . $linkedin . '" target="_blank"><i class="fa fa-linkedin aps-tooltip" '.$tooltip.' title="linkedin"></i></a>';
            }
            //Googleplus
            if ( $googleplus != '' ) {
                $html_social .= '<a href="' . $googleplus . '" target="_blank"><i class="fa fa-google-plus aps-tooltip" '.$tooltip.' title="Google Plus"></i></a>';
            }
            //Dribbble
            if ( $dribbble != '' ) {
                $html_social .= '<a href="' . $dribbble . '" target="_blank"><i class="fa fa-dribbble aps-tooltip" '.$tooltip.' title="Dribbble"></i></a>';
            }
            //$html .= '</span>';
            $html_social .= '</span>';



            $html .= '<div class="person-text">';

            //Social
            if ($layout=='full') { $html .= $html_social; }

            //Name , title
            $html .= '<span class="person-name">'.$name.'</span>';
            $html .= '<span class="person-title">'.$title.'</span>';

            //Brief
            $html .= '<div class="person-brief">'.do_shortcode($content).'</div>';

            if ($layout=='left') { $html .= $html_social; }

            $html .= '</div>';

            $html .= '</div>';
            return $html;
        }

    }
}