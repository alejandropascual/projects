<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_pills' ) )
{
    class aps_pills extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' 		=> 'Pills',
                'shortcode' => 'aps_pills',
                'shortcode_nested' => array('aps_pill'),
                'tab' 		=> __('STRUCTURE',APS_PB_LANG),
                'order' 	=> 155,
            );
        }


        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),
                array(
                    'label'	=> __('ADD EDIT ITEMS', APS_PB_LANG),
                    'desc' 	=> __('Add or remove items here.', APS_PB_LANG),
                    'id' 	=> 'content_wrap',
                    'type' 	=> 'group_fields',
                    'value' => array(
                        array('title'=>'PILL 1', 'content_sub'=>'Content PILL 1'),
                        array('title'=>'PILL 2', 'content_sub'=>'Content PILL 2'),
                        array('title'=>'PILL 3', 'content_sub'=>'Content PILL 3'),
                    ),
                    'subfields' => array(
                        array(
                            'label' => __('Title', APS_PB_LANG),
                            'desc' 	=> __('Enter the title here', APS_PB_LANG),
                            'id' 	=> 'title',
                            'type' 	=> 'input',
                            'value' => 'TAB Title',
                        ),
                        array(
                            'label' => __('Content', APS_PB_LANG),
                            'desc' 	=> __('Enter the content here', APS_PB_LANG),
                            'id' 	=> 'content_sub',
                            'type' 	=> 'tinymce',
                            'value' => 'Write the content here',
                        ),
                    )// cierre subfields
                ),
                array(
                    'label' => __('Float Pills', APS_PB_LANG),
                    'desc' 	=> __('Enter the content here', APS_PB_LANG),
                    'id' 	=> 'float',
                    'type' 	=> 'select',
                    'value' => 'none',
                    'options' => array('none'=>'No float','left'=>'Left','right'=>'Right')
                ),
                array(
                    'label' => __('Pills border color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'border_color',
                    'type' 	=> 'colorpicker',
                    'value' => 'black',
                ),

                array(
                    'label' => __('Pill text color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'title_active_color',
                    'type' 	=> 'colorpicker',
                    'value' => 'black',
                ),
                array(
                    'label' => __('Pill inactive text color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'title_inactive_color',
                    'type' 	=> 'colorpicker',
                    'value' => 'white',
                ),
                array(
                    'label' => __('Pill inactive back color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'title_inactive_bc_color',
                    'type' 	=> 'colorpicker',
                    'value' => 'black',
                ),
            );//Cierre fields
        }

        function shortcode_handler( $atts, $content = null )
        {
            extract( shortcode_atts( array(
                'id'    => 'id-'.uniqid(),
                'class' => '',
                'style' => '',
                'float' => '',
                'border_color' => 'transparent',
                'title_active_color' => 'black',
                'title_inactive_color' => 'white',
                'title_inactive_bc_color' => 'black'
            ), $atts ) );

            $html = '';

            //$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            //$class = ( $class != '' ) ? esc_attr( $class ) : '';
            $style = ( $style != '' ) ? 'style="' . $style . '"' : '';

            static $counter = 0;
            $counter++;

            //Navegacion tabs
            preg_match_all("#\[aps_pill title=\'(.+?)\'](.+?)\[\/aps_pill\]#sm", $content, $matches);
            if (isset($matches))
            {
                //Numero de pills, no me hace falta ya
                $number = count($matches[0]);
                $number_str = strval($number);
                //$types = array('2'=>'two','3'=>'three','4'=>'four','5'=>'five','6'=>'six','7'=>'seven','8'=>'eight');
                //$type=$types[$number_str].'-up';
                $type = '';

                //Algo de estilo
                $html .= "<div id=\"{$id}\" class=\"aps-tabs-wrap {$class}\" {$style}>";
                $html .= "<style>
#{$id} .aps-nav-tabs, #{$id} .aps-nav-tabs-item, #{$id} .aps-tab-content { border: 0px ; }
#{$id} .aps-nav-tabs-item a        { color: {$title_inactive_color} ; background-color: {$title_inactive_bc_color} ;}
#{$id} .aps-nav-tabs-item.active a { color: {$title_active_color} ; background-color: transparent; }
#{$id} .aps-pills .aps-pill.active a { border-color: {$border_color} ; }
                </style>";


                //Inicio navegador tabs
                $html .= "<ul class=\"aps-nav aps-nav-tabs aps-pills {$type} {$float}\">";

                //Cada tab
                for($i=0;$i<$number;$i++)
                {
                    if (isset($matches[1][$i])) {
                        $title = $matches[1][$i];
                    }
                    else {
                        $title = 'ERROR title pill';
                    }
                    $count = $counter.'-'.($i+1);
                    if ($i==0) $active = 'active';
                    else $active = '';
                    $html .= "<li class=\"aps-nav-tabs-item aps-pill {$active}\"><a href=\"#tab-{$count}\" data-toggle=\"tab\">{$title}</a></li>";
                }
                $html .= '</ul>';


                //Ahora los contenidos de cada tab
                $html .= "<div class=\"aps-tab-content aps-pill-content\">";
                // Cada tab
                for($i=0;$i<$number;$i++)
                {
                    if (isset($matches[2][$i])) {
                        $content = $matches[2][$i];
                    } else {
                        $content = 'ERROR getting content for Pill '.($i+1);
                    }
                    $count = $counter.'-'.($i+1);
                    if ($i==0) $active = 'active';
                    else $active = '';
                    $html .= "<div id=\"tab-{$count}\" class=\"aps-tab-pane fade in {$active}\">" . do_shortcode( $content ) . "</div>";
                }
                $html .= '</div>';

            }
            else {
                $html .= '<p>ERROR in shortcode Pills, you don\'t have the pills well formatted</p>';
            }

            $html .= '</div>';
            $html .= '<hr class="aps-clear">';
            return $html;
        }
    }

}