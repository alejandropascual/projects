<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_post_content' ) )
{
    class aps_post_content extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' 		=> 'Post Content',
                'shortcode' => 'aps_post_content',
                'tab' 		=> __('CONTENT-2',APS_PB_LANG),
                'order' 	=> 90,
                'direct_insert' => "[aps_post_content post_id=0]"
            );
        }

        function modal_fields()
        {
            $this->fields = array();
        }

        function shortcode_handler($atts, $content='')
        {
            extract( shortcode_atts( array(
                'id'     => '',
                'class'  => '',
                'style'  => '',
                'post_id' => ''
            ), $atts ) );

            $id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $class = ( $class != '' ) ? ' ' . esc_attr( $class ) : '';
            $style = ( $style != '' ) ? 'style="' . $style . '"' : '';

            $html = '';

            $content_post = get_post($post_id);
            $content = $content_post->post_content;
            $content = apply_filters('the_content', $content);
            $content = do_shortcode($content);
            $html = $content;

            return $html;
        }

    }
}