<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_posts_carousel' ) ) 
{
	class aps_posts_carousel extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Carousel: Posts & Projects',
				'shortcode' => 'aps_posts_carousel',
                'tab' 		=> __('GALLERIES',APS_PB_LANG),
                'order' 	=> 120,
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',	
				),
                // Type of slider
                array(
                    'label' => __('Type of carousel', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'type',
                    'type'  => 'select',
                    'value' => 'top',
                    'options' => array(
                        'photo-slider'      => 'Only images',
                        'image-slider'      => 'Images with top title',
                        'featured-slider'   => 'Images with bottom title and excerpt',
                    )
                ),
                array(
                    'label' => __('Image size for carousel', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'size',
                    'type'  => 'select',
                    'value' => 'top',
                    'options' => array(
                        'large'       => 'Large image',
                        'medium'      => 'Medium image',
                        'thumbnail'   => 'Small square image',
                        'thumbnail-v' => 'Small vertical image'
                    )
                ),

                /*
                array(
                    'label' => __('Type of carousel', APS_PB_LANG),
                    'desc'  => __('', APS_PB_LANG),
                    'id'    => 'type',
                    'type'  => 'select',
                    'value' => 'top',
                    'options' => array(
                        'large::photo-slider'       => 'Image Large',
                        'medium::photo-slider'      => 'Image Medium',
                        'thumbnail::photo-slider'   => 'Image Small',
                        'large::image-slider'       => 'Image Large - Top title',
                        'medium::image-slider'      => 'Image Medium - Top title',
                        'thumbnail::image-slider'   => 'Image Small - Top title',
                        'large::featured-slider'    => 'Image Large - Bottom title + description',
                        'medium::featured-slider'   => 'Image Medium - Bottom title + description',
                        'thumbnail::featured-slider'=> 'Image Small - Bottom title + description',
                    )
                ),
                */
                //Muestra los custom posts
				array(
                    'label' => __('Content source', APS_PB_LANG),
                    'desc'  => __('Select from where you want to the content for the slider', APS_PB_LANG),
                    'id'    => 'source',
                    'type'  => 'select_custom_post',
                    'value' => 'post',
                    'exclude_custom_posts' => array('attachment','aps_layout','page')
                ),
                //Muestra las categorias de cada custom post
                array(
                    'label' => __('Filter categories', APS_PB_LANG),
                    'desc'  => __('Select multiple categories or leave it blank for all', APS_PB_LANG),
                    'id'    => 'categories',
                    'type'  => 'select_custom_categories',
                    'required_post_type' => 'source',
                    'exclude_custom_posts' => array('attachment','aps_layout')
                ),
                //Muestra los tags de cada custom post
                array(
                    'label' => __('Filter tags', APS_PB_LANG),
                    'desc'  => __('Select multiple tags or leave it blank for all', APS_PB_LANG),
                    'id'    => 'tags',
                    'type'  => 'select_custom_tags',
                    'required_post_type' => 'source',
                    'exclude_custom_posts' => array('attachment','aps_layout')
                ),
                //Number of posts
                array(
                    'label'	=> __('Number of posts', APS_PB_LANG),
                    'desc' 	=> __('Input number of posts or -1 for all', APS_PB_LANG),
                    'id' 	=> 'limit',
                    'type' 	=> 'input',
                    'value' => '10',
                ),
                //Order
                array(
                    'label'	=> __('Order posts By', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'orderby',
                    'type' 	=> 'select',
                    'value' => 'date',
                    'options' => array(
                        'none'          => 'None',
                        'title'         => 'Title',
                        'author'        => 'Author',
                        'date'          => 'Date',
                        'comment_count' => 'Popularity',
                        'rand'          => 'Random'
                    )
                ),
                //Order
                array(
                    'label'	=> __('Order of posts', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'order',
                    'type' 	=> 'select',
                    'value' => 'ASC',
                    'options' => array(
                        'ASC' => 'Ascending',
                        'DESC' => __('Descending', APS_PB_LANG)
                    )
                ),
                /*array(
                    'label'	=> __('Exclude post', APS_PB_LANG),
                    'desc' 	=> __('Insert the id of the post you want to exclude.<br>For example if you insert this shortcode in the content of the post with id=55, and want related posts to this one, then you should have to exclude the post 55 here.', APS_PB_LANG),
                    'id' 	=> 'exclude_id',
                    'type' 	=> 'input',
                    'value' => '',

                ),*/
                //Image size
                /*
                array(
                    'label'	=> __('Image size', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'size_image',
                    'type' 	=> 'select',
                    'value' => 'medium',
                    'options' => $this->get_image_sizes(),
                ),
                */
			);
		}
		

		
		function shortcode_handler($atts, $content='')
		{
            global $post;

			extract( shortcode_atts( array(
				'id'    => '',
				'class' => '',//no-margin para hacerlas completas
				'style' => '',
                'source' => 'post',
                'limit' => '-1',
                'orderby'=>'rand',
                'order' => 'ASC',
                'size' => 'medium',
                'type' => 'image-slider',
                'exclude_id' => '' //Para excluir el propio post donde inserto los related
			), $atts ) );
			
			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? '' . esc_attr( $class ) : '';
			$style = ( $style != '' ) ? 'style="' . $style . '"' : '';


            // tax query
            $tax_query = array( 'relation' => 'AND' );

            $atts_cats = 'categories_'.$source;
            $atts_tags = 'tags_'.$source;

            // process categories (hierarchical taxonomy)
            if ( isset( $atts[$atts_cats] )  && !empty($atts[$atts_cats]) ) {
                $cats = explode(',',$atts[$atts_cats]);
                $query_cats = array();
                foreach( $cats as $cat ) {
                    list($taxonomy, $term) = explode('::', $cat);
                    if ( !array_key_exists($taxonomy, $query_cats) ) {
                        $query_cats[$taxonomy] = array(
                            'taxonomy' => $taxonomy,
                            'field' => 'slug',
                            'terms' => array($term)
                        );
                    } else {
                        $query_cats[$taxonomy]['terms'][] = $term;
                    }
                }
                $tax_query = array_merge($tax_query, $query_cats);
            }

            // process tags (non-hierarchical taxonomy)
            if ( isset($atts[$atts_tags]) && !empty($atts[$atts_tags]) ) {
                $tags = explode(',',$atts[$atts_tags]);
                $query_tags = array();
                foreach( $tags as $tag ) {
                    list($taxonomy, $term) = explode('::', $tag);
                    if ( !array_key_exists($taxonomy, $query_tags) ) {
                        $query_tags[$taxonomy] = array(
                            'taxonomy' => $taxonomy,
                            'field' => 'slug',
                            'terms' => array($term)
                        );
                    } else {
                        $query_tags[$taxonomy]['terms'][] = $term;
                    }
                }
                $tax_query = array_merge($tax_query, $query_tags);
            }

            $html = '';

            // run WP_Query
            $args = array(
                'post_type' => $source,
                'tax_query' => $tax_query,
                'orderby'   => $orderby,
                'order'     => $order,
                'posts_per_page' => $limit,
                //'post__not_in' => get_option("sticky_posts")
            );
            //Solo dentro de un post, no de una pagina
            if (is_single()){
                $args['post__not_in'] = array(get_the_ID());
                //$args['post__not_in'] = array_merge(get_option("sticky_posts"), get_the_ID());
            }

            $query = new WP_Query($args);

            //Create slider from posts
            if ( $query->have_posts() ) {

                $templates = $this->get_templates();

                //Tipo de slider
                /*
                list($size_image, $type_slider) = explode('::',$type);
                $class_slider = $type_slider;
                $template_slider = $type_slider;
                if ($type_slider=='photo-slider') {
                    $class_slider = 'featured-slider';
                }
                */
                $type_slider = $type;
                $size_image = $size;
                $class_slider = $type_slider;
                $template_slider = $type_slider;
                if ($type_slider=='photo-slider') {
                    $class_slider = 'featured-slider';
                }

                $sizes = array(
                    'large' => array( 'width'=> '600', 'height' => '400'),
                    'medium' => array( 'width'=> '300', 'height' => '225'),
                    'thumbnail' => array( 'width'=> '150', 'height' => '150'),
                    'thumbnail-v' => array( 'width'=> '150', 'height' => '270'),
                );
                $width = $sizes[$size_image]['width'];
                $height = $sizes[$size_image]['height'];

                //Cojo el tamaño de la primera imagen
                /*
                $options = array('size_image' => $size_image);
                $sizes = $this->get_image_sizes_array();
                //echo '<pre>'; print_r($sizes); echo '</pre>';
                $width = '300';
                $height = '200';
                if ( isset($sizes[$size_image][0]) ) {
                    $width = $sizes[$size_image][0];
                    $height = $sizes[$size_image][1];
                    if ($height==0) $height = 0.5*$width;
                }
                */

                $html .= '<div '.$id.' class="related-posts-container '.$class.'" '.$style.'>';
                $html .= '<div class="everslider aps-everslider '.$class_slider.'" data-slide_width="'.$width.'" data-slide_height="'.$height.'">';
                $html .= '<ul class="es-slides">';

                while( $query->have_posts() )
                {
                    $query->the_post();
                    //$html .= '<li>' . apply_filters('aps_template', $templates[$template_slider], $post, $options) . '</li>';
                    $excerpt = wp_trim_words(get_the_excerpt(), 12, '');
                    $excerpt = preg_replace('/\W+$/', '', $excerpt);
                    $excerpt .= ' ..';


                    //Con las imagenes de wordpress
                    //$image = '';
                    //$image = get_the_post_thumbnail(get_the_ID(), $size_image);

                    //Con aqua resize
                    $image_html = '';
                    $image_resized = aps_get_image_resized_for_post_id(get_the_ID(), $width, $height, 0, 'no');
                    //echo '<pre>'; print_r( $image_resized ); echo '</pre>';

                    if ( isset($image_resized['resized']['img']) ){
                        $image_html = $image_resized['resized']['img'];
                    } else {
                        $image_html = $image_resized['full']['img'];
                    }

                    $data = array(
                        'title' => get_the_title(),
                        'permalink' => get_permalink(),
                        'excerpt' => $excerpt,
                        'image' => $image_html
                    );
                    //echo '<pre>'; print_r( $data ); echo '</pre>';

                    $html .= '<li>'.$this->render_template( $templates[$template_slider] , $data ).'</li>';
                }

                $html .= '</ul>';
                $html .= '</div>';
                $html .= '</div>';

                // restore post data
                wp_reset_postdata();

            } else {
                $html .= __('Slider has no slides' ,APS_PB_LANG);
                return false;
            }

			return $html;
		}

        function get_templates()
        {
            $templates = array();

            $templates['photo-slider'] = <<<TMPL
            <div class="featured-pic">
				<a title="Preview project" href="%permalink%"><i class="fa fa-link"></i></a>
				%image%
			</div>
TMPL;

            $templates['image-slider'] = <<<TMPL
            <div class="featured-pic">%image%</div>
            <a href="%permalink%">
                <div class="image-caption">
                    <span>%title%</span>
                </div>
            </a>
TMPL;

            $templates['featured-slider'] = <<<TMPL
            <div class="featured-pic">
				<a title="Preview project" href="%permalink%"><i class="fa fa-link"></i></a>
				%image%
			</div>
			<div class="featured-title">
				<a href="#" title="Click to preview">%title%</a>
				<span>%excerpt%</span>
			</div>
TMPL;

            return $templates;
        }


        function render_template( $tmpl, $data )
        {
            $html = $tmpl;
            foreach( $data as $key=>$value) {
                $html = str_replace('%'.$key.'%', $value, $html);
            }
            return $html;
        }
		
	}
}