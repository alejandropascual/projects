<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_protected' ) ) 
{
	class aps_protected extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Protected Content',
				'shortcode' => 'aps_protected',
                'tab' 		=> __('STRUCTURE',APS_PB_LANG),
                'order' 	=> 180,
				
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',	
				),
				array(
					'label'	=>__('Description', APS_PB_LANG),
					'desc' 	=> __('This lets you protect the content.<br>Only users that are logged in can see this content.', APS_PB_LANG),
					'id' 	=> '',
					'type' 	=> 'description',	
					'value' => '',
					'class-wrap' => 'field-description',
					'class' => ''
				),
				array(
					'label'	=> __('CONTENT', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'content_sc',
					'type' 	=> 'tinymce',	
					'value' => 'Write the content here',
				)
			);
		}
		

		
		function shortcode_handler($atts, $content='')
		{
			extract( shortcode_atts( array(
				'id'    => '',
				'class' => '',//no-margin para hacerlas completas
				'style' => ''
			), $atts ) );
			
			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? 'aps-protect ' . esc_attr( $class ) : 'aps-protect';
			$style = ( $style != '' ) ? 'style="' . $style . '"' : '';
			
			global $user_login;
			
			if (is_user_logged_in()) {
			  $html = do_shortcode( $content );
			} else {
			  $html  = "<div {$id} class=\"{$class}\" {$style}>";
			  $html .= '<form autocomplete="off" action="' . esc_url( site_url( 'wp-login.php' ) ) . '" method="post" class="aps-protect-form">';
			  $html .= '<h3 class="aps-protect-title">' . esc_html__( 'Login - Restricted content', APS_PB_LANG ) . '</h3>';
			  $html .= '<div><label>' . esc_html__( 'Username', APS_PB_LANG ) . '</label><input type="text" name="log" id="log" value="' . esc_attr( $user_login ) . '" /></div>';
			  $html .= '<div><label>' . esc_html__( 'Password', APS_PB_LANG ) . '</label><input type="password" name="pwd" id="pwd" /></div>';
			  $html .= '<div><input class="button-style-1 aps-protect-btn" type="submit" name="submit" value="' . esc_html__( 'Login', APS_PB_LANG ) . '" class="aps-btn aps-protect-btn" /></div>';
			  $html .= '<input type="hidden" name="redirect_to" value="' . esc_url( get_permalink() ) . '">';
			  $html .= '</form>';
			  $html .= '</div>';
			}
			
			return $html;
		}
		
	}
}