<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_pullquote' ) ) 
{
	class aps_pullquote extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Pullquote',
				'shortcode' => 'aps_pullquote',
                'tab' 		=> __('CONTENT-2',APS_PB_LANG),
				'order' 	=> 30,
                'use_line_break' => 'no'
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',	
				),
				array(
					'label'	=>__('Description', APS_PB_LANG),
					'desc' 	=> __('This quote floats to the left or the right of the content', APS_PB_LANG),
					'id' 	=> '',
					'type' 	=> 'description',	
					'value' => '',
					'class-wrap' => 'field-description',
					'class' => ''
				),
				array(
					'label'	=> __('TYPE', APS_PB_LANG),
					'desc' 	=> __('Select where to float the quote inside the page', APS_PB_LANG),
					'id' 	=> 'type',
					'type' 	=> 'select',	
					'value' => 'left',
					'options' => array('left'=>'Left', 'right'=>'Right')
				),
				array(
					'label'	=> __('TEXT ALIGN', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'align',
					'type' 	=> 'select',	
					'value' => 'left',
					'options' => array('left'=>'Left', 'center'=>'Center', 'right'=>'Right')
				),
				array(
					'label'	=> __('AUTHOR', APS_PB_LANG),
					'desc' 	=> __('The author of the quote', APS_PB_LANG),
					'id' 	=> 'cite',
					'type' 	=> 'input',	
					'value' => 'Steve Jobs',
				),
				array(
					'label'	=> __('CONTENT', APS_PB_LANG),
					'desc' 	=> __('Edit the content of the quote', APS_PB_LANG),
					'id' 	=> 'content_sc',
					'type' 	=> 'tinymce',	
					'value' => 'Design is not just what it looks like and feels like. Design is how it works.',
				),
				
			);
		}
		
		function shortcode_handler($atts, $content='')
		{
			extract( shortcode_atts( array(
				'id'    => '',
				'class' => '',
				'style' => '',
				'cite'  => '',
				'type'  => '',
				'align'  => ''
			), $atts ) );
			
			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? 'aps-pullquote ' . esc_attr( $class ) : 'aps-pullquote';
			$style = ( $style != '' ) ? 'style="' . $style . '"' : '';
			$cite  = ( $cite  != '' ) ? '<cite class="aps-cite">' . $cite . '</cite>' : '';
			
			switch ( $align ) {
			case 'right' :
			  $align = ' align-right';
			  break;
			case 'center' :
			  $align = ' align-center';
			  break;
			default :
			  $align = '';
			}
			
			switch ( $type ) {
			  case 'right':
			  	$type = ' float-right';
			  	break;
			  default:
			  	$type = ' float-left';
			}

            //$html = "<blockquote {$id} class=\"{$class}{$align}{$type}\" {$style}>" . do_shortcode( $content ) . $cite . "</blockquote>";

            $html  = "<blockquote {$id} class=\"{$class}{$align}{$type}\" {$style}>";
            $html .= "<span class=\"fa fa-quote-left\"></span>";
            $html .= do_shortcode( $content );
            $html .= "<span class=\"fa fa-quote-right\"></span>";
            $html .= $cite;
            $html .= "</blockquote>";


			return $html;
		}
		
	}
}