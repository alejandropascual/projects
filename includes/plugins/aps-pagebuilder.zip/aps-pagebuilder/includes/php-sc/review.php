<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_review' ) ) {
    class aps_review extends APSShortcode
    {
        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Review',
                'shortcode' => 'aps_review',
                'tab' => __('CONTENT-2', APS_PB_LANG),
                'order' => 60,
                'use_line_break' => 'no',
            );
        }

        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),
                array(
                    'label'	=> __('Genre', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'genre',
                    'type' 	=> 'select',
                    'value' => 'male',
                    'options' => array(
                        'male' => __('Male', APS_PB_LANG),
                        'female'=>__('Female', APS_PB_LANG)
                    )
                ),
                array(
                    'label'	=> __('Name', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'name',
                    'type' 	=> 'input',
                    'value' => '',
                ),
                array(
                    'label'	=> __('Link caption', APS_PB_LANG),
                    'desc' 	=> __('Leave it blank if you dont want any link', APS_PB_LANG),
                    'id' 	=> 'link_caption',
                    'type' 	=> 'input',
                    'value' => '',
                ),
                array(
                    'label'	=> __('Link', APS_PB_LANG),
                    'desc' 	=> __('Web link', APS_PB_LANG),
                    'id' 	=> 'link',
                    'type' 	=> 'input',
                    'value' => '',
                ),
                array(
                    'label'	=> __('target link', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'target',
                    'type' 	=> 'select',
                    'value' => '_blank',
                    'options' => array(
                        '_self' => __('Open in the same window', APS_PB_LANG),
                        '_blank'=> __('Open in a new window', APS_PB_LANG)
                    )
                ),
                array(
                    'label'	=> __('Review Back Color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'back_color',
                    'type' 	=> 'colorpicker',
                    'value' => '#acacac',
                ),
                array(
                    'label'	=> __('Review Text Color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'text_color',
                    'type' 	=> 'colorpicker',
                    'value' => '#ffffff',
                ),
                array(
                    'label'	=> __('Review Text', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'content_Sc',
                    'type' 	=> 'textarea',
                    'value' => 'Write the review ...'
                )
            );
        }

        function shortcode_handler($atts, $content='')
        {
            extract( shortcode_atts( array(
                'id'     => 'id-'.uniqid(),
                'class'  => '',
                'style'  => '',
                'back_color' => 'black',
                'text_color' => 'white',
                'genre' => 'male',
                'name' => 'John Doe',
                'link_caption' => '',
                'link' => '',
                'target' => '_blank'
            ), $atts ) );

            $class = ( $class != '' ) ? ' ' . esc_attr( $class ) : '';
            $style = ( $style != '' ) ? 'style="' . $style . '"' : '';

            $html = '';
            $html .= "<style>
            #{$id} .quote { background-color: {$back_color}; color: {$text_color}; }
            #{$id} .quote:before { border-top-color: {$back_color}; }
            </style>";
            $html .= "<div id=\"{$id}\" {$style} class=\"{$class} aps-review\">";
            $html .= "<div>";
            $html .= "<div class='quote'>{$content}</div>";
            $html .= "<span class=\"review-name review-{$genre}\">{$name}</span>";
            if ( $link_caption != '' ) {
                $html .= ',';
                $html .= "<a class=\"review-link\" target=\"{$target}\" href=\"{$link}\">{$link_caption}</a>";
            }
            $html .= "</div>";
            $html .= "</div>";
            return $html;

        }
    }
}