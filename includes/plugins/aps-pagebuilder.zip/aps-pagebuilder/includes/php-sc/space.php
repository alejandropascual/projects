<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_space' ) ) 
{
	class aps_space extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Space',
				'shortcode' => 'aps_space',
				'tab' 		=> __('STRUCTURE',APS_PB_LANG),
				'order' 	=> 115,
				'direct_insert' => "[aps_space size='30px']"
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',	
				),
				array(
					'label'	=>__('Size', APS_PB_LANG),
					'desc' 	=> __('Define the space in pixels, example: 30px', APS_PB_LANG),
					'id' 	=> 'size',
					'type' 	=> 'input',	
					'value' => '30px',
				),
			);
		}
		

		
		function shortcode_handler($atts, $content='')
		{
			extract( shortcode_atts( array(
				'id'    => '',
				'class' => '',
				'style' => '',
				'size'	=> ''
			), $atts ) );
			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? 'aps-space ' . esc_attr( $class ) : 'aps-space';
			$size  = ( $size  != '' ) ? "margin: {$size} 0 0 0;" : 'margin: 0;';
			
			$html = "<hr {$id} class=\"{$class}\" style=\"{$style}{$size}\">";
			return $html;
		}
		
	}
}