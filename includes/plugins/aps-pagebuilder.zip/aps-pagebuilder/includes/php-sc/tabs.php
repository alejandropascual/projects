<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_tabs' ) ) 
{
	class aps_tabs extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Tabs',
				'shortcode' => 'aps_tabs',
				'shortcode_nested' => array('aps_tab'),
                'tab' 		=> __('STRUCTURE',APS_PB_LANG),
				'order' 	=> 150,
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',	
				),
				array(
					'label'	=> __('ADD EDIT ITEMS', APS_PB_LANG),
					'desc' 	=> __('Add or remove items here. You can have from 2 to 10 tabs.', APS_PB_LANG),
					'id' 	=> 'content_wrap',
					'type' 	=> 'group_fields',
					'value' => array(
						array('title'=>'TAB 1', 'content_sub'=>'Content TAB 1'),
						array('title'=>'TAB 2', 'content_sub'=>'Content TAB 2'),
						array('title'=>'TAB 3', 'content_sub'=>'Content TAB 3'),
					),
					'subfields' => array(
						array(
							'label' => __('Title', APS_PB_LANG),
							'desc' 	=> __('Enter the title here', APS_PB_LANG),
							'id' 	=> 'title',
							'type' 	=> 'input',
							'value' => 'TAB Title',
						),
						array(
							'label' => __('Content', APS_PB_LANG),
							'desc' 	=> __('Enter the content here', APS_PB_LANG),
							'id' 	=> 'content_sub',
							'type' 	=> 'tinymce',
							'value' => 'Write the content here',
						),
					)// cierre subfields
				),
				array(
					'label' => __('Float tabs', APS_PB_LANG),
					'desc' 	=> __('Enter the content here', APS_PB_LANG),
					'id' 	=> 'float',
					'type' 	=> 'select',
					'value' => 'none',
					'options' => array('none'=>'No float','left'=>'Left','right'=>'Right')
				),
                array(
                    'label' => __('Tabs border color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'border_color',
                    'type' 	=> 'colorpicker',
                    'value' => 'red',
                ),
                array(
                    'label' => __('Tab header active color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'title_text_color',
                    'type' 	=> 'colorpicker',
                    'value' => '#000000',
                ),
                array(
                    'label' => __('Tab header inactive color', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'title_inactive_color',
                    'type' 	=> 'colorpicker',
                    'value' => '#dedede',
                ),
			);//Cierre fields
		}
		
		function shortcode_handler( $atts, $content = null )
		{
			extract( shortcode_atts( array(
			'id'    => 'id-'.uniqid(),
			'class' => '',
			'style' => '',
			'float' => '',
            'border_color' => 'black',
            'title_text_color' => 'black',
            'title_inactive_color' => '#dedede'
			), $atts ) );
			
			$html = '';

            //$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            //$class = ( $class != '' ) ? esc_attr( $class ) : '';
            $style = ( $style != '' ) ? 'style="' . $style . '"' : '';
			
			static $counter = 0;
			$counter++;
			
			//Navegacion tabs
			preg_match_all("#\[aps_tab title=\'(.+?)\'](.+?)\[\/aps_tab\]#sm", $content, $matches);
			if (isset($matches))
			{
				//Numero de tabs
				$number = count($matches[0]);
				$number_str = strval($number);
				$types = array('2'=>'two','3'=>'three','4'=>'four','5'=>'five','6'=>'six','7'=>'seven','8'=>'eight');
				$type=$types[$number_str].'-up';
				
				//Algo de estilo
                $html .= "<div id=\"{$id}\" class=\"aps-tabs-wrap {$class}\" {$style}>";
                $html .= "<style>
#{$id} .aps-nav-tabs { border-color: {$border_color} ; }
#{$id} .aps-nav-tabs-item { border-color: {$border_color} ; }
#{$id} .aps-nav-tabs-item a        { color: {$title_text_color} ; background-color: {$title_inactive_color} ;}
#{$id} .aps-nav-tabs-item.active a { background-color: transparent; }
#{$id} .aps-tab-content { border-color: {$border_color} ; }
                </style>";


				//Inicio navegador tabs
				$html .= "<ul class=\"aps-nav aps-nav-tabs {$type} {$float}\">";

                //Cada tab
				for($i=0;$i<$number;$i++)
				{
					if (isset($matches[1][$i])) {
						$title = $matches[1][$i];
					}
					else {
						$title = 'ERROR title tab';
					}
					$count = $counter.'-'.($i+1);
					if ($i==0) $active = 'active';
					else $active = '';
					$html .= "<li class=\"aps-nav-tabs-item {$active}\"><a href=\"#tab-{$count}\" data-toggle=\"tab\">{$title}</a></li>";
				}
				$html .= '</ul>';
			  
			  
				//Ahora los contenidos de cada tab
				$html .= "<div class=\"aps-tab-content\">";
				// Cada tab
				for($i=0;$i<$number;$i++)
				{
					if (isset($matches[2][$i])) {
						$content = $matches[2][$i];
					} else {
						$content = 'ERROR getting content for Tab '.($i+1);
					}
					$count = $counter.'-'.($i+1);
					if ($i==0) $active = 'active';
					else $active = '';
					$html .= "<div id=\"tab-{$count}\" class=\"aps-tab-pane fade in {$active}\">" . do_shortcode( $content ) . "</div>";
				}
				$html .= '</div>';
			  
			}
			else {
			  $html .= '<p>ERROR in shortcode Tabs, you don\'t have the tabs well formatted</p>';
			}

            $html .= '</div>';
            $html .= '<hr class="aps-clear">';
			return $html;
		}
	}
		
}