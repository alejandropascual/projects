<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_tooltip' ) ) {
    class aps_tooltip extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Tooltip',
                'shortcode' => 'aps_tooltip',
                'tab' => __('CONTENT', APS_PB_LANG),
                'order' => 110
            );

        }

        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),

            );

        }

        function shortcode_handler($atts, $content='')
        {
            extract(shortcode_atts(array(
                'id' => '',
                'class' => '',
                'style' => '',
                'align' => '',
                'place' => 'top',
                'title' => 'Text tooltip',
            ), $atts));


            $id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $class = ( $class != '' ) ? 'aps-tooltip ' . esc_attr( $class ) : 'aps-tooltip';
            $style = ( $style != '' ) ? 'style="' . $style . '"' : '';

            $html  = "<span {$id} {$style} class=\"{$class}\" data-toggle=\"tooltip\" data-placement=\"{$place}\" title=\"{$title}\">";
            $html .= $content;
            $html .= "</span>";

            return $html;
        }
    }
}