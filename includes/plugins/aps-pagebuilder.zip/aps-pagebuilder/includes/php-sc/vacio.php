<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_vacio' ) ) {
    class aps_vacio extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' => 'Aps',
                'shortcode' => '==',
                'hidden' => 'yes'
            );
        }

        function modal_fields()
        {
            $this->fields = array();
        }

        function shortcode_handler($atts, $content = '')
        {
            return '';
        }
    }
}