<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_video' ) ) 
{
	class aps_video extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Video',
				'shortcode' => 'aps_video',
				'tab' 		=> __('MEDIA',APS_PB_LANG),
				'order' 	=> 110,
				//'direct_insert' => "[aps_gallery ids='']"
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',	
				),
				array(
					'label'	=> __('VIDEO HOSTED / EMBEDDED', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'type',
					'type' 	=> 'select',	
					'value' => 'embed_link',
					'options' => array(
						'hosted' => 'HOSTED',
						'embed_iframe' => 'EMBEDDED iframe',
						'embed_link' => 'EMBEDDED link'
					)
				),
				array(
					'label'	=> __('SCREEN ratio', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'ratio',
					'type' 	=> 'select',	
					'value' => '',
					'options' => array(
						'video-16_9' => '16 : 9',
						'video-5_3' => '5 : 3',
						'video-5_4' => '5 : 4',
						'video-4_3' => '4 : 3',
						'video-3_2' => '3 : 2'
					)
				),
				array(
					'label'	=> __('VIDEO link', APS_PB_LANG),
					'desc' 	=> __('Insert video link for Youtube, Vimeo or Ted.<br>Example:<br>Youtube: http://www.youtube.com/watch?v=Lmnf25BWdwg<br>Youtube: http://youtu.be/0v95y96O4CY<br>Youtube: http://www.youtube.com/embed/0v95y96O4CY<br>Vimeo: http://vimeo.com/65289245<br>TED: http://embed.ted.com/talks/geraldine_hamilton_body_parts_on_a_chip.html', APS_PB_LANG),
					'id' 	=> 'url',
					'type' 	=> 'input',	
					'value' => 'http://www.youtube.com/watch?v=RsJDCgk2OnI',
					'required' => 'type->embed_link'
				),
				
				array(
					'label'	=> __('VIDEO iframe', APS_PB_LANG),
					'desc' 	=> __('Insert embedded code here.', APS_PB_LANG),
					'id' 	=> 'iframe',
					'type' 	=> 'textarea',	
					'value' => '<iframe width="560" height="315" src="//www.youtube.com/embed/FrjQrXc80cY" frameborder="0" allowfullscreen></iframe>',
					'required' => 'type->embed_iframe'
				),
				array(
					'label'	=> __('Use FRAME', APS_PB_LANG),
					'desc' 	=> __('Create a frame around the video', APS_PB_LANG),
					'id' 	=> 'frame',
					'type' 	=> 'select',	
					'value' => 'yes',
					'options' => array(
						'yes' => 'YES',
						'no'  => 'NO'
					),
				),
				
				array(
					'label'	=> __('Video m4v', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'm4v',
					'type' 	=> 'input',	
					'value' => 'http://www.jplayer.org/video/m4v/Big_Buck_Bunny_Trailer.m4v',
					'required' => 'type->hosted'
				),
				array(
					'label'	=> __('Video ogv', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'ogv',
					'type' 	=> 'input',	
					'value' => 'http://www.jplayer.org/video/ogv/Big_Buck_Bunny_Trailer.ogv',
					'required' => 'type->hosted'
				),
				array(
					'label'	=> __('Video webm', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'webm',
					'type' 	=> 'input',	
					'value' => 'http://www.jplayer.org/video/webm/Big_Buck_Bunny_Trailer.webm',
					'required' => 'type->hosted'
				),
				array(
					'label'	=> __('Poster Image', APS_PB_LANG),
					'desc' 	=> __('Insert direct link of an Image or select one from media.', APS_PB_LANG),
					'id' 	=> 'poster',
					'type' 	=> 'image_src_visible',	
					'value' => 'http://www.jplayer.org/video/poster/Big_Buck_Bunny_Trailer_480x270.png',
					'required' => 'type->hosted',
					'button' => 'Select image'
				),
				array(
					'label'	=> __('Autoplay', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'autoplay',
					'type' 	=> 'select',	
					'value' => 'no',
					'options' => array(
						'yes' => 'YES',
						'no'  => 'NO'
					),
				),
				array(
					'label'	=> __('Skin', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'skin',
					'type' 	=> 'select',	
					'value' => 'black',
					'options' => array(
						'white' => 'White',
						'gray'  => 'Gray',
						'black' => 'Black'
					),
				),
			);
		}
		
		
		

		
		function shortcode_handler( $atts, $content = null )
		{
			if (isset($atts['type']))
				$type = $atts['type'];
			else 
				$type = null;
			
			if ($type=='hosted'){
				return $this->html_video_hosted($atts, $content);
				
			} else if ($type=='embed_link'){
				return $this->html_video_embed_link($atts, $content);
				
			} else if ($type=='embed_iframe'){
				return $this->html_video_embed_iframe($atts, $content);
				
			} else {
				return '';
			}
			
		}

		function html_video_embed_iframe($atts,$content=null)
		{
			extract( shortcode_atts( array(
				'id'		=> '',
				'class'		=> '',
				'style'		=> '',
				'ratio'		=> '',
                'ratio_custom' => '',//Para sobreescribir el normal, ejemplo 0.45
				'frame'		=> '',
				'iframe'	=> ''
			), $atts ) );
			
			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? 'aps-video aps-video-embed ' . esc_attr( $class ) : 'aps-video aps-video-embed';
			$style = ( $style != '' ) ? 'style="' . $style . '"' : '';

            if ($ratio_custom != '') {
                $cr = 100.00 * floatval($ratio_custom);
                $ratio_custom = 'style="padding-bottom:'.$cr.'%;"';
            }
			
			$frame = ( $frame=='false' || $frame=='no' ) ? '' : ' video-with-frame';
			$html = "<div {$id} class=\"{$class}{$frame}\" {$style}><div class=\"aps-video-inner {$ratio}\" {$ratio_custom}>{$iframe}</div></div>";
			return $html;
		}
				
		function html_video_embed_link($atts,$content=null)
		{
			extract( shortcode_atts( array(
				'id'		=> '',
				'class'		=> '',
				'style'		=> '',
				'ratio'		=> '',
                'ratio_custom' => '',//Para sobreescribir el normal, ejemplo 0.45
				'url'		=> '',
				'frame'		=> '',
			), $atts ) );
			
			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? 'aps-video aps-video-embed ' . esc_attr( $class ) : 'aps-video aps-video-embed';
			$style = ( $style != '' ) ? 'style="' . $style . '"' : '';
			
			$frame = ( $frame=='false' || $frame=='no' ) ? '' : ' video-with-frame';
			
			if ($url=='') return '';
			$iframe = '';

            if ($ratio_custom != '') {
                $cr = 100.00 * floatval($ratio_custom);
                $ratio_custom = 'style="padding-bottom:'.$cr.'%;"';
            }

			//YOUTUBE
			//http://www.youtube.com/embed/0v95y96O4CY
			//http://youtu.be/0v95y96O4CY
			//http://www.youtube.com/watch?v=Lmnf25BWdwg
			if (strstr($url, 'youtube') || strstr($url, 'youtu.be'))
			{
					if (preg_match('/v=(.+)$/',$url,$matches)==1) {
							$numero = $matches[1];
					} else if (preg_match('/be\/(.+)$/', $url, $matches)==1) {
							$numero = $matches[1];
					}
					if (isset($numero)){
						$iframe = '<iframe width="100%" height="100%" src="http://www.youtube.com/embed/'.$numero.'" frameborder="0" allowfullscreen></iframe>';
					}
			}
			
			//VIMEO
			//http://vimeo.com/65289245
			else if (strstr($url, 'vimeo')) {
			  preg_match('/\d+/', $url,$matches);
			  $numero = $matches[0];
			  $iframe = '<iframe src="http://player.vimeo.com/video/'.$numero.'?portrait=0&amp;badge=0" width="100%" height="100%" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>';
			}
			
			//TED
			//<iframe src="http://embed.ted.com/talks/geraldine_hamilton_body_parts_on_a_chip.html" width="560" height="315" frameborder="0" scrolling="no" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>
			else if (strstr($url, 'ted')) {
			  if (preg_match('/talks\/(.+)/', $url,$matches))
			  {
				 	 $iframe = '<iframe src="http://embed.ted.com/talks/'.$matches[1].'" width="100%" height="100%" frameborder="0" scrolling="no" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>';
			  }
			}
			
			//HULU, solo USA
  
			$html = "<div {$id} class=\"{$class}{$frame}\" {$style}><div class=\"aps-video-inner {$ratio}\" {$ratio_custom}>{$iframe}</div></div>";
			return $html;
		}
		

		
		function html_video_hosted($atts,$content=null)
		{
			extract( shortcode_atts( array(
			'id'        => '',
			'class'     => '',
			'style'     => '',
			'ratio'     => '',
            'ratio_custom' => '',//Para sobreescribir el normal, ejemplo 0.45
			'frame'		=> '',
			'm4v'		=> '',
			'ogv'		=> '',
			'webm'		=> '',
			'poster'	=> '',
			'autoplay'	=> '',
			'skin'		=> '' 
			), $atts ) );
			
			
			//Calcular bien los url por si son parciales
			$m4v 	= $this->get_url_media($m4v);
			$ogv 	= $this->get_url_media($ogv);
			$webm 	= $this->get_url_media($webm);
			$poster = $this->get_url_media($poster);
			
			
			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? 'aps-video aps-video-hosted ' . esc_attr( $class ) : 'aps-video aps-video-hosted';
			$style = ( $style != '' ) ? 'style="' . $style . '"' : '';
			$autoplay = ( $autoplay == 'true' || $autoplay == 'yes' ) ? '.jPlayer("play")' : '';
			$skin = ( $skin != '' ) ? ' jp-skin-'.$skin : ' jp-skin-black';

            if ($ratio_custom != '') {
                $cr = 100.00 * floatval($ratio_custom);
                $ratio_custom = 'style="padding-bottom:'.$cr.'%;"';
            }

			
			$frame = ( $frame=='false' || $frame=='no' ) ? '' : ' video-with-frame';
			
			static $count = 0; $count++;
			
			$script = '<script>'.
			  'jQuery(document).ready(function($){
			  	//console.log("Preparando el video "+'.$count.');
			  	if ($().jPlayer) {
						$("#aps_jplayer_video_'.$count.'").jPlayer({
							ready: function () {
								$(this).jPlayer("setMedia", {'
								. ( ( $m4v!="" ) ? "m4v: '{$m4v}'," : '' )
								. ( ( $ogv!="" ) ? "ogv: '{$ogv}'," : '' )
								. ( ( $webm!="" ) ? "webmv: '{$webm}'," : '' )
								. ( ( $poster!="" ) ? "poster: '{$poster}'," : '' )
								//	m4v: "http://www.jplayer.org/video/m4v/Big_Buck_Bunny_Trailer.m4v",
								//	ogv: "http://www.jplayer.org/video/ogv/Big_Buck_Bunny_Trailer.ogv",
								//	webmv: "http://www.jplayer.org/video/webm/Big_Buck_Bunny_Trailer.webm",
								//	poster: "http://www.jplayer.org/video/poster/Big_Buck_Bunny_Trailer_480x270.png"
								.'})'.$autoplay.';
							},
							swfPath: "'.APS_PAGEBUILDER_URL.'/includes/js/vendor/jplayer",
							//supplied: "webmv, ogv, m4v",
							supplied: '
							. '"'
							. ( ($webm!="") ? "webmv," : "")
							. ( ($ogv !="") ? "ogv," : "")
							. ( ($m4v !="") ? "m4v," : "")
							. '"'
							. ',size: {
								width: "100%",
								height: "100%"
							},
							//cssSelectorAncestor: "#jp_interface_video_'.$count.'"
							cssSelectorAncestor: ".jp-video-'.$count.'"
						});
			
			
										
						$("#aps_jplayer_video_'.$count.'").bind($.jPlayer.event.playing, function (event) {
			        $(this).add("#jp_interface_video_'.$count.'").hover(function () {
			            $("#jp_interface_video_'.$count.'").stop().animate({
			                opacity: 1
			            }, 300);
			        }, function () {
			            $("#jp_interface_video_'.$count.'").stop().animate({
			                opacity: 0
			            }, 300);
			        });
			    });
			      
						$("#aps_jplayer_video_'.$count.'").bind($.jPlayer.event.pause, function (event) {
			        $("#aps_jplayer_video_'.$count.'").add("#jp_interface_video_'.$count.'").unbind("hover");
			        $("#jp_interface_video_'.$count.'").stop().animate({
			            opacity: 1
			        }, 300);
			    });
			    
			    
			    //Corregir ids porque jplayer les asigna el mismo a todos los videos
			    $("#aps_jplayer_video_'.$count.' > img").attr("id","aps-jp-poster-'.$count.'");
			    $("#aps_jplayer_video_'.$count.' > video").attr("id","aps-jp-video-'.$count.'");        
						
					}
				});'
				.'</script>';
			
			$controls = '<div class="jp-controls-wrapper">'
									.'<div id="jp_interface_video_'.$count.'" class="jp-interface">'
			  						
			  						. '<ul class="jp-controls">'
			  							. '<li><a href="javascript:;" class="jp-play" tabindex="1"></a></li>'
											. '<li><a href="javascript:;" class="jp-pause" tabindex="1"></a></li>'
										. '</ul>'
										
										. '<div class="jp-progress-wrapper">'
											. '<div class="jp-progress">'
												. '<div class="jp-seek-bar">'
													.	'<div class="jp-play-bar"></div>'
												. '</div>'
											. '</div>'
										. '</div>'
										
										. '<ul class="jp-toggles">'
											. '<li><a href="javascript:;" class="jp-full-screen" tabindex="1" title="full screen"></a></li>'
											. '<li><a href="javascript:;" class="jp-restore-screen" tabindex="1" title="restore screen"></a></li>'
										. '</ul>'
										
									.'</div>'
								.'</div>';
			
			
			$html = $script
							. "<div {$id} class=\"{$class}{$frame}{$skin} jp-video jp-video-{$count}\" {$style}>"
								. "<div class=\"aps-video-inner {$ratio}\" {$ratio_custom}>"
									. "<div id=\"aps_jplayer_video_{$count}\" class=\"jp-jplayer\"></div>"
									. $controls
								. "</div>"
							. "</div>";

            wp_enqueue_script( 'aps-jplayer');
			return $html;
			
			
		}
	}
}




