<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_visible' ) ) 
{
	class aps_visible extends APSShortcode
	{
		
		function create_shortcode_options()
		{
			$this->options = array(
				'name' 		=> 'Visible Content',
				'shortcode' => 'aps_visible',
                'tab' 		=> __('STRUCTURE',APS_PB_LANG),
                'order' 	=> 160,
			);
		}
		
		
		function modal_fields()
		{
			$this->fields = array(
				array(
					'type' 	=> 'id_class_style',	
				),
				array(
					'label'	=> __('Type', APS_PB_LANG),
					'desc' 	=> __('Select where you want your content to be visible or hidden', APS_PB_LANG),
					'id' 	=> 'type',
					'type' 	=> 'select',	
					'value' => 'show-desktop',
					'options' => array(
						'show-desktop' 	=> 'Show only with Desktops',
						'show-tablet'  	=> 'Show only with Tablets',
						'show-phone'	=> 'Show only with Phones',
						'hide-desktop'  => 'Hide in Desktops',
						'hide-tablet'	=> 'Hide in tablets',
						'hide-phone'	=> 'Hide in Phones'
					)
				),
				array(
					'label'	=> __('Inline content', APS_PB_LANG),
					'desc' 	=> __('This content can be inline with the rest or in a new line.', APS_PB_LANG),
					'id' 	=> 'inline',
					'type' 	=> 'select',	
					'value' => 'inline',
					'options' => array(
						'yes' 	=> 'Content inline',
						'on'  	=> 'Content in a new line'
					)
				),
				array(
					'label'	=> __('CONTENT', APS_PB_LANG),
					'desc' 	=> __('', APS_PB_LANG),
					'id' 	=> 'content_sc',
					'type' 	=> 'tinymce',	
					'value' => 'Write the content here',
				)
			);
		}
		

		
		function shortcode_handler($atts, $content='')
		{
			extract( shortcode_atts( array(
				'id'     => '',
				'class'  => '',
				'style'  => '',
				'type'   => '',
				'inline' => 'yes'
			), $atts ) );
			
			$id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
			$class = ( $class != '' ) ? 'aps-visible ' . esc_attr( $class ) : 'aps-visible';
			$style = ( $style != '' ) ? 'style="' . $style . '"' : '';
			$type  = ( $type  != '' ) ? ' aps-' . $type : '';
			
			if ($inline=='yes') 
				{ $tag = 'span';}
			else 
				{ $tag = 'div'; }
			
			$html = "<$tag {$id} class=\"{$class}{$type}\" {$style}>" . do_shortcode( $content ) . "</$tag>";
			return $html;
		}
		
	}
}