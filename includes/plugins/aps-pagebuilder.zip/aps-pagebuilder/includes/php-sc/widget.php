<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'aps_widget' ) )
{
    class aps_widget extends APSShortcode
    {

        function create_shortcode_options()
        {
            $this->options = array(
                'name' 		=> 'Widget',
                'shortcode' => 'aps_widget',
                'tab' 		=> __('CONTENT-2',APS_PB_LANG),
                'order' 	=> 100,
                //'direct_insert' => "[aps_widget size='30px']"
            );
        }


        function modal_fields()
        {
            $this->fields = array(
                array(
                    'type' 	=> 'id_class_style',
                ),
                array(
                    'label'	=>__('Widget', APS_PB_LANG),
                    'desc' 	=> __('', APS_PB_LANG),
                    'id' 	=> 'widget',
                    'type' 	=> 'select_widget',
                    'value' => '',
                ),
            );
        }



        function shortcode_handler($atts, $content='')
        {
            extract( shortcode_atts( array(
                'id'    => '',
                'class' => '',
                'style' => '',
                'widget'=> ''
            ), $atts ) );

            $id    = ( $id    != '' ) ? 'id="' . esc_attr( $id ) . '"' : '';
            $class = ( $class != '' ) ? 'widget ' . esc_attr( $class ) : 'widget';

            $html = "<div {$id} class=\"{$class}\" style=\"{$style}\">";
            ob_start();
            dynamic_sidebar( $widget );
            $html .= ob_get_clean();
            $html .= "</div>";
            return $html;
        }

    }
}