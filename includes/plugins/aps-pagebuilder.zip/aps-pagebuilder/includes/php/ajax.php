<?php


// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }


// Copiado del theme

add_action('wp_ajax_aps_get_image_src','aps_get_image_src_ajax');


if (!function_exists('aps_get_image_src_ajax')):
	function aps_get_image_src_ajax()
	{	
	/*	
		$images_ids = explode(',',$_POST['images_ids']);
		$ultimo = $_POST['ultimo'];
		$field_id = $_POST['field_id'];
		$checkbox = ($_POST['with_checkbox']=='true')?true:false;
		
		foreach($images_ids as $image_id){
			echo html_repeatable_image_item($field_id, $ultimo++, $image_id, $checkbox);
		}
	*/
	
		$image_id = $_REQUEST['image_id'];
		$size = $_REQUEST['size'];
		$src = wp_get_attachment_image_src($image_id, $size);
		
		if (!empty($src))
			echo $src[0];
		else
			echo 0;
			
		die();
	}
endif;


add_action('wp_ajax_aps_gallery_preview', 'aps_gallery_preview');

if (!function_exists('aps_gallery_preview')):
	function aps_gallery_preview()
	{
		$result = array('success' => false, 'output' => '');
		
		$ids = $_REQUEST['attachments_ids'];
		if (empty($ids)){
			echo json_encode( $result );
			exit;
		}
		
		$ids = explode( ',', $ids );

		foreach ( $ids as $id ) {
			$attach = wp_get_attachment_image_src( $id, 'thumbnail', false);
	
			$link_edit = admin_url('post.php?post='.$id.'&action=edit');
			$result["output"] .= '<li><a target="_blank" href="'.$link_edit.'"><img src="'.$attach[0] .'" /></a></li>';
	
		}
		$result["success"] = true;
		echo json_encode( $result );
		exit;
	}
endif;



add_action('wp_ajax_aps_gallery_template_ajax', 'aps_gallery_template_ajax');
add_action('wp_ajax_nopriv_aps_gallery_template_ajax', 'aps_gallery_template_ajax');

if (!function_exists('aps_gallery_template_ajax')):
    function aps_gallery_template_ajax()
    {
        $sc_atts = $_REQUEST['sc_atts'];
        //echo '<pre>'; print_r( $sc_atts ); echo '</pre>';

        //Ejecuto el shortcode desde aqui
        $shortcode = '[aps_gallery_template';
        foreach($sc_atts as $key=>$value){
            $shortcode .= ' '.$key.'="'.$value.'"';
        }
        $shortcode .= ']';

        $html = do_shortcode($shortcode);

        /*if (preg_match_all('/<article.+?\/article>/sm', $html, $matches))
        {
            //echo '<pre>'; print_r( $matches[0] ); echo '</pre>';
            echo json_encode($matches[0]);
        }*/


        $response = array(
            'success' => true,
            'html' => $html
        );
        echo json_encode($response);


        die();
    }
endif;