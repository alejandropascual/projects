<?php


if ( !defined('ABSPATH') ) { die('-1'); }


if ( !class_exists( 'APShtmlBuilder' ) ) {

class APShtmlBuilder 
{
	static function render_several_elements($elements, $parent = false)
	{
		$html = '';
		foreach($elements as $element)
		{
			$html .= self::render_element($element, $parent);
		}
		return $html;
	}
	
	//Para cada field del modal window
	static function render_element($element, $parent = false)
	{
		//Este es un campo triple que se repite en todos
		if ($element['type']=='id_class_style') {
			return self::render_id_class_style($element, $parent);
		}
		
		$defaults = array(
			'label' 		=> __('', APS_PB_LANG),
			'desc'			=> __('', APS_PB_LANG),
			'id' 			=> '',
			'class-wrap' 	=> '',//para el wrapper
			'class' 		=> '', //Para el input
			'type' 			=> '',//Posibles campos
			'options' 		=> '',//Para select
			'value' 		=> '',
			'required' 		=> '' //Para depender de select
		);
		
		$element = array_merge($defaults, $element);
		
		$required = ($element['required'] != '') ? 'data-required="'.$element['required'].'"' : '';
		
		$html  = '<div class="aps-modal-field '.$element['class-wrap'].'" id="field-'.$element['id'].'" '.$required.'>';
		$html .= '	<div class="aps-modal-field-desc">';
		$html .= '		<div class="title">'.$element['label'].'</div>';
		$html .= '		<div class="desc">'.$element['desc'].'</div>';
		$html .= '	</div>';
		$html .= '	<div class="aps-modal-field-form">';
		
		$func = 'render_'.$element['type'];
		$html .= self::$func($element, $parent);

		//$html .= '		<input type="text" name="'.$element['att'].'" value="'.$element['value'].'">';
		
		$html .= '	</div>';
		$html .= '</div>';
		
		return $html;
	}
	
	
	
	//ID_CLASS_STYLE
	static function render_id_class_style($element, $parent = false)
	{
		$html  = '<div class="aps-modal-field-wrap-id_class_style">';
		$html .= '<div class="aps-icon-id_class_style">ID CLASS STYLE</div>';
		$html .= '<div class="aps-modal-field-id_class_style">';
		$elements = array(
			array(
				'label'	=>__('', APS_PB_LANG),
				'desc' 	=> __('Use these fields when you need target specific CSS rules', APS_PB_LANG),
				'id' 	=> '',
				'type' 	=> 'description',	
				'value' => '',
				'class-wrap' => 'field-description no-border',
				'class' => ''
			),
			array(
				'label'	=>__('ID', APS_PB_LANG),
				'desc' 	=> __('', APS_PB_LANG),
				'id' 	=> 'id',
				'type' 	=> 'input',	
				'value' => '',
				'class-wrap' => 'field-general field-width-1_3',
				'class' => ''
			),
			array(
				'label'	=>__('CLASS', APS_PB_LANG),
				'desc' 	=> __('', APS_PB_LANG),
				'id' 	=> 'class',
				'type' 	=> 'input',	
				'value' => '',
				'class-wrap' => 'field-general field-width-1_3'
			),
			array(
				'label'	=>__('STYLE', APS_PB_LANG),
				'desc' 	=> __('', APS_PB_LANG),
				'id' 	=> 'style',
				'type' 	=> 'textarea',	
				'value' => '',
				'class-wrap' => 'field-general field-width-1_3'
			)
		);
		foreach($elements as $subelement)
		{
			$html .= self::render_element($subelement, $parent);
		}
		
		$html .= '</div>';
		$html .= '</div>';
		return $html;
	}
	
	
	
	//DESCRIPTION
	static function render_description($element, $parent = false)
	{
		return '';
	}
	
	
	// INPUT
	static function render_input($element, $parent = false)
	{
		$html = '<input type="text" class="aps-modal-field-input '.$element['class'].'" name="'.$element['id'].'" id="'.$element['id'].'" value="'.$element['value'].'">';
		return $html;
	}
	
	
	// TETAREA
	static function render_textarea($element, $parent = false)
	{
		$html = '<textarea class="aps-modal-field-textarea '.$element['class'].'" rows="5" name="'.$element['id'].'" id="'.$element['id'].'">'.$element['value'].'</textarea>';
		return $html;
	}
	
	
	// SELECT
	static function render_select($element, $parent = false)
	{
		$html  = '<div class="field-select-wrap">';
		$html .= '<div class="field-select-arrow">+</div>';
		$html .= '<select class="aps-modal-field-select '.$element['class'].'" name="'.$element['id'].'" id="'.$element['id'].'">';
		$options = $element['options'];
		foreach($options as $key=>$value) {
			$selected = '';
			if ($element['value']==$key) $selected = ' selected';
			$html .= '<option value="'.$key.'" '.$selected.'>'.$value.'</option>';
		}
		$html .= '</select>';
		$html .= '</div>';
		return $html;
	}

    static function render_select_contactform7($element, $parent = false)
    {
        $options = array();

        $query_data = array(
            'post_type'         => 'wpcf7_contact_form',
            'posts_per_page'    => -1,
            'orderby'           => 'date',
            'post_status'       => 'publish',
        );

        $my_query = new WP_Query( $query_data );
        global $post;
        if ( $my_query->have_posts() ) {
            while ($my_query->have_posts()) {
                $my_query->the_post();
                $options[$post->ID] = '['.$post->ID.'] '.$post->post_title;
            }
        }
        wp_reset_postdata();

        $element['options'] = $options;
        return self::render_select($element, $parent = false);
    }

    static function render_select_widget($element, $parent = false)
    {
        $options = array();
        foreach ( $GLOBALS['wp_registered_sidebars'] as $sidebar )
        {
            $options[$sidebar['id']] = $sidebar['name'];
        }
        $element['options'] = $options;
        return self::render_select($element, $parent = false);
    }

    // SELECT MULTIPLE
    static function render_select_multiple($element, $parent = false)
    {
        $html  = '<div class="field-select-wrap">';
        $html .= '<select multiple="multiple" size="5" class="aps-modal-field-select '.$element['class'].'" name="'.$element['id'].'" id="'.$element['id'].'">';
        $options = $element['options'];
        foreach($options as $key=>$value) {
            $selected = '';
            if ($element['value']==$key) $selected = ' selected';
            $html .= '<option value="'.$key.'" '.$selected.'>'.$value.'</option>';
        }
        $html .= '</select>';
        $html .= '</div>';
        return $html;
    }

    // SELECT MULTIPLE CHOSEN
    static function render_select_multiple_chosen($element, $parent = false)
    {
        $html  = '<div class="field-select-wrap">';
        $html .= '<select multiple="multiple" size="5" data-placeholder="Select..." class="aps-modal-field-select chosen-select '.$element['class'].'" name="'.$element['id'].'" id="'.$element['id'].'">';
        $options = $element['options'];
        foreach($options as $key=>$value) {
            $selected = '';
            if ($element['value']==$key) $selected = ' selected';
            $html .= '<option value="'.$key.'" '.$selected.'>'.$value.'</option>';
        }
        $html .= '</select>';
        $html .= '</div>';
        return $html;
    }

    //SELECT ANIMATION
    static function render_select_animation($element, $parent = false)
    {
        $html  = '<div class="field-select-wrap">';
        $html .= '<div class="field-select-arrow"></div>';
        $html .= '<select class="aps-modal-field-select select-animation" name="'.$element['id'].'" id="'.$element['id'].'">
        <optgroup label="Attention Seekers">
          <option value="bounce">bounce</option>
          <option value="flash">flash</option>
          <option value="pulse">pulse</option>
          <!--option value="rubberBand">rubberBand</option-->
          <option value="shake">shake</option>
          <option value="swing">swing</option>
          <option value="tada">tada</option>
          <option value="wobble">wobble</option>
        </optgroup>

        <optgroup label="Bouncing Entrances">
          <option value="bounceIn">bounceIn</option>
          <option value="bounceInDown">bounceInDown</option>
          <option value="bounceInLeft">bounceInLeft</option>
          <option value="bounceInRight">bounceInRight</option>
          <option value="bounceInUp">bounceInUp</option>
        </optgroup>

        <optgroup label="Bouncing Exits">
          <option value="bounceOut">bounceOut</option>
          <option value="bounceOutDown">bounceOutDown</option>
          <option value="bounceOutLeft">bounceOutLeft</option>
          <option value="bounceOutRight">bounceOutRight</option>
          <option value="bounceOutUp">bounceOutUp</option>
        </optgroup>

        <optgroup label="Fading Entrances">
          <option value="fadeIn" selected>fadeIn</option>
          <option value="fadeInDown">fadeInDown</option>
          <option value="fadeInDownBig">fadeInDownBig</option>
          <option value="fadeInLeft">fadeInLeft</option>
          <option value="fadeInLeftBig">fadeInLeftBig</option>
          <option value="fadeInRight">fadeInRight</option>
          <option value="fadeInRightBig">fadeInRightBig</option>
          <option value="fadeInUp">fadeInUp</option>
          <option value="fadeInUpBig">fadeInUpBig</option>
        </optgroup>

        <optgroup label="Fading Exits">
          <option value="fadeOut">fadeOut</option>
          <option value="fadeOutDown">fadeOutDown</option>
          <option value="fadeOutDownBig">fadeOutDownBig</option>
          <option value="fadeOutLeft">fadeOutLeft</option>
          <option value="fadeOutLeftBig">fadeOutLeftBig</option>
          <option value="fadeOutRight">fadeOutRight</option>
          <option value="fadeOutRightBig">fadeOutRightBig</option>
          <option value="fadeOutUp">fadeOutUp</option>
          <option value="fadeOutUpBig">fadeOutUpBig</option>
        </optgroup>

        <optgroup label="Flippers">
          <option value="flip">flip</option>
          <option value="flipInX">flipInX</option>
          <option value="flipInY">flipInY</option>
          <option value="flipOutX">flipOutX</option>
          <option value="flipOutY">flipOutY</option>
        </optgroup>

        <optgroup label="Lightspeed">
          <option value="lightSpeedIn">lightSpeedIn</option>
          <option value="lightSpeedOut">lightSpeedOut</option>
        </optgroup>

        <optgroup label="Rotating Entrances">
          <option value="rotateIn">rotateIn</option>
          <option value="rotateInDownLeft">rotateInDownLeft</option>
          <option value="rotateInDownRight">rotateInDownRight</option>
          <option value="rotateInUpLeft">rotateInUpLeft</option>
          <option value="rotateInUpRight">rotateInUpRight</option>
        </optgroup>

        <optgroup label="Rotating Exits">
          <option value="rotateOut">rotateOut</option>
          <option value="rotateOutDownLeft">rotateOutDownLeft</option>
          <option value="rotateOutDownRight">rotateOutDownRight</option>
          <option value="rotateOutUpLeft">rotateOutUpLeft</option>
          <option value="rotateOutUpRight">rotateOutUpRight</option>
        </optgroup>

        <optgroup label="Sliders">
          <option value="slideInDown">slideInDown</option>
          <option value="slideInLeft">slideInLeft</option>
          <option value="slideInRight">slideInRight</option>
          <option value="slideOutLeft">slideOutLeft</option>
          <option value="slideOutRight">slideOutRight</option>
          <option value="slideOutUp">slideOutUp</option>
        </optgroup>

        <optgroup label="Specials">
          <option value="hinge">hinge</option>
          <option value="rollIn">rollIn</option>
          <option value="rollOut">rollOut</option>
        </optgroup>
      </select>';
        $html .= '<h1 class="animation" style="text-align:center; color:#ff3300;font-size:4em;">ANIMATION</h1>';
        $html .= '</div>';
        return $html;
    }

	
	// COLORPICKER
	static function render_colorpicker($element, $parent = false)
	{
		$html = '<input type="text" class="aps-modal-field-colorpicker '.$element['class'].'" value="'.$element['value'].'" id="'.$element['id'].'" name="'.$element['id'].'"/>';
		return $html;
	}
	
	
	//TINYMCE
	static function render_tinymce($element, $parent = false)
	{
		//Filter id for tinymce, solo admite letras
		$element['id']  = preg_replace('![^a-zA-Z_]!', "", $element['id']);
		
		//Rich editor optional
		$user_ID = get_current_user_id();			
		if(get_user_meta($user_ID, 'rich_editing', true) == "true")
		{
			//Replace new lines with brs
			$element['value'] = str_replace("\n",'<br>',$element['value']);
		}
		
		ob_start();
		wp_editor( $element['value'], $element['id'] , array('editor_class' => 'aps-modal-field-tinymce '.$element['class'], 'media_buttons' => true ) );
	    $html = ob_get_clean();

		return $html;
	}

    static function render_joder($element, $parent = false)
    {
        return '<h1>tinymce_for_metabox</h1>';

        //Filter id for tinymce, solo admite letras
        $element['id']  = preg_replace('![^a-zA-Z_]!', "", $element['id']);

        //Rich editor optional
        $user_ID = get_current_user_id();
        if(get_user_meta($user_ID, 'rich_editing', true) == "true")
        {
            //Replace new lines with brs
            $element['value'] = str_replace("\n",'<br>',$element['value']);
        }

        $html = '<h1>EDITOR</h1>';
        return $html;

        ob_start();
        //wp_editor( $element['value'], $element['id'] , array('editor_class' => 'aps-modal-field-tinymce '.$element['class'], 'media_buttons' => true ) );
        wp_editor( $element['value'], $element['id']);
        $html .= ob_get_clean();

        //return '<h1>TINYMCE</h1>';
        //echo '<pre>'; print_r( $html ); echo '</pre>';
        return $html;
    }
	
	
	//GROUP_FIELDS
	static function render_group_fields($element, $parent = false)
	{
		$html  = '<div class="aps-modal-group-wrap">';
		$html .= '<div class="aps-modal-group" id="'.$element['id'].'">';
		
		//Lista reordenables con los elementos
		$number = count($element['value']);
		for ($i=0; $i<$number; $i++)
		{
			$html .= self::render_group_fields_element($element,$parent,$i);
		}
		
		$html .= '</div>'; //Cierro lista de elementos
		
		//Para añadir mas elementos
		$html .= '<a class="aps-modal-group-field-add">+</a>';
		
		//Template vacio para añadir mas elementos
		$html .= '<script type="text/html" class="aps-modal-group-field-template">';
		$html .= self::render_group_fields_element($element,$parent,0);
		$html .= '</script>';
		
		$html .= '</div>';
		return $html;
	}
	
	static function create_data_string($data)
	{
		$data_str = '';
		foreach($data as $key=>$value) {
			$data_str .= ' data-'.$key.'="'.$value.'"';
		}
		return $data_str;
	}
	
	static function render_group_fields_element($element, $parent = false, $i = false)
	{
		// Iterate the subelement
		//foreach($element['subfields'] as $subelement){}
		
		
		//Data para el submodal
		$data['modal_title'] = $element['label'];
		$data['modal_shortcode_nested'] = $parent->options['shortcode_nested'][0]; 
		$data['modal_ajax_hook'] = $parent->options['shortcode_nested'][0];
		$data_str = self::create_data_string($data);
		
		//Campo representativo en la fila
		$keys = array_keys($element['value'][$i]);
		$first_key = $keys[0];
		$data2['update_with'] = $first_key;
		$data2['update_template'] = '{{'.$first_key.'}}';
		$data_str2 = self::create_data_string($data2);
		$html_inner = '<div class="title-content" '.$data_str2.'">'.$element['value'][$i][$first_key].'</div>';
		
		//HTML completo
		$html  = '<div class="aps-modal-group-field" '.$data_str.'>';
		$html .= '<a class="aps-modal-group-field-move">move</a>';
		$html .= '<a class="aps-modal-group-field-delete">X</a>';
		$html .= '<div class="aps-modal-group-field-inner">';
		$html .= $html_inner;
		$html .= '</div>';
		$html .= '<textarea class="shortcode-text use_always_sc" name="'.$element['id'].'">';
		//Create shortcode from array subelement
		$subvalues = $element['value'][$i];
		$html .= self::create_shortcode_from_fields($parent->options['shortcode_nested'][0],$subvalues);
		$html .= '</textarea>';
		$html .= '</div>';
		
		return $html;
	}
	
	//En un group forma un shortcode a partir de los valores de $element['value']
	//por ejemplo: array('title'=>'Slide1', 'content'=>'Content1')
	static function create_shortcode_from_fields($shortcode_name, $fields)
	{
		//Si hay un campo content entonces el shortcode se cierra
		$sc = "\n[".$shortcode_name;
		foreach($fields as $key=>$value)
		{
			if (preg_match('/content/', $key)) {
			//if ( $key == "content" ) {
				$sc .= "]".$value."[/".$shortcode_name;
			} else {
				$sc .= " ".$key."='".$value."'";
			}
		}
		$sc .= "]";
		return $sc;
	}
	
	
	//IMAGE
	static function render_image($element, $parent = false)
	{
		$html  = '<a href="#" class="button aps-modal-button-insert-image">'.$element['button'].'</a>';
		
		$html .= '<div class="aps-modal-preview-image-wrap without-image">';
		$html .= 	'<span class="aps-modal-preview-image"><img src=""></span>';
		$html .= 	'<a href="#delete" class="aps-modal-button-delete-image">X</a>';
		$html .= '</div>';
		
		//$html .= '<input type="text" class="preview-image-src" value="" name="'.$element['id'].'_src" id="'.$element['id'].'_src">';
		$html .= '<input type="hidden" class="preview-image-id use_always_sc" value="" name="'.$element['id'].'" id="'.$element['id'].'">';
		
		return $html;
	}
	
	
	
	//IMAGE_SRC
	static function render_image_src($element, $parent = false)
	{
		$html  = '<a href="#" class="button aps-modal-button-insert-image">'.$element['button'].'</a>';
		
		$html .= '<div class="aps-modal-preview-image-wrap without-image">';
		$html .= 	'<span class="aps-modal-preview-image"><img src=""></span>';
		$html .= 	'<a href="#delete" class="aps-modal-button-delete-image">X</a>';
		$html .= '</div>';
		
		$html .= '<input type="hidden" class="preview-image-src use_always_sc" value="" name="'.$element['id'].'_src" id="'.$element['id'].'_src">';
		$html .= '<input type="hidden" class="preview-image-id use_always_sc" value="" name="'.$element['id'].'_id" id="'.$element['id'].'_id">';
		$html .= '<input type="hidden" class="preview-image-size use_always_sc" value="" name="'.$element['id'].'_size" id="'.$element['id'].'_size">';
		return $html;
	}
	
	//IMAGE_SRC_VISIBLE
	//para seleccionar imagen src o poder escribirla directamente
	static function render_image_src_visible($element, $parent = false)
	{
		$html = '<input type="text" class="aps-modal-field-input preview-image-src" value="'.$element['value'].'" name="'.$element['id'].'" id="'.$element['id'].'">';
		
		$html .= '<a href="#" class="button aps-modal-button-insert-image">'.$element['button'].'</a>';
		
		$html .= '<div class="aps-modal-preview-image-wrap without-image">';
		$html .= 	'<span class="aps-modal-preview-image"><img src=""></span>';
		$html .= 	'<a href="#delete" class="aps-modal-button-delete-image">X</a>';
		$html .= '</div>';
		
		return $html;
	}
	
	
	//GALLERY
	static function render_gallery($element, $parent = false)
	{
		$html  = '<a href="#" class="button aps-modal-button-insert-gallery">'.$element['button'].'</a>';
		
		$html .= '<ul class="aps-modal-preview-gallery-wrap">';
		$html .= '</ul>';
		
		$html .= '<input type="hidden" class="use_always_sc preview-gallery-id" value="" name="'.$element['id'].'" id="'.$element['id'].'">';
		
		return $html;
	}
	
	
	//GALLERY iconfont
	static function render_iconfont($element, $parent = false)
	{
	
		//$icons = 'rub,pagelines,stack-exchange,arrow-circle-o-right,arrow-circle-o-left,caret-square-o-left,toggle-left,dot-circle-o,wheelchair,vimeo-square,try,turkish-lira,plus-square-o,adjust,anchor,archive,arrows,arrows-h,arrows-v,asterisk,ban,bar-chart-o,barcode,bars,beer,bell,bell-o,bolt,book,bookmark,bookmark-o,briefcase,bug,building-o,bullhorn,bullseye,calendar,calendar-o,camera,camera-retro,caret-square-o-down,caret-square-o-left,caret-square-o-right,caret-square-o-up,certificate,check,check-circle,check-circle-o,check-square,check-square-o,circle,circle-o,clock-o,cloud,cloud-download,cloud-upload,code,code-fork,coffee,cog,cogs,comment,comment-o,comments,comments-o,compass,credit-card,crop,crosshairs,cutlery,dashboard,desktop,dot-circle-o,download,edit,ellipsis-h,ellipsis-v,envelope,envelope-o,eraser,exchange,exclamation,exclamation-circle,exclamation-triangle,external-link,external-link-square,eye,eye-slash,female,fighter-jet,film,filter,fire,fire-extinguisher,flag,flag-checkered,flag-o,flash,flask,folder,folder-o,folder-open,folder-open-o,frown-o,gamepad,gavel,gear,gears,gift,glass,globe,group,hdd-o,headphones,heart,heart-o,home,inbox,info,info-circle,key,keyboard-o,laptop,leaf,legal,lemon-o,level-down,level-up,lightbulb-o,location-arrow,lock,magic,magnet,mail-forward,mail-reply,mail-reply-all,male,map-marker,meh-o,microphone,microphone-slash,minus,minus-circle,minus-square,minus-square-o,mobile,mobile-phone,money,moon-o,music,pencil,pencil-square,pencil-square-o,phone,phone-square,picture-o,plane,plus,plus-circle,plus-square,plus-square-o,power-off,print,puzzle-piece,qrcode,question,question-circle,quote-left,quote-right,random,refresh,reply,reply-all,retweet,road,rocket,rss,rss-square,search,search-minus,search-plus,share,share-square,share-square-o,shield,shopping-cart,sign-in,sign-out,signal,sitemap,smile-o,sort,sort-alpha-asc,sort-alpha-desc,sort-amount-asc,sort-amount-desc,sort-asc,sort-desc,sort-down,sort-numeric-asc,sort-numeric-desc,sort-up,spinner,square,square-o,star,star-half,star-half-empty,star-half-full,star-half-o,star-o,subscript,suitcase,sun-o,superscript,tablet,tachometer,tag,tags,tasks,terminal,thumb-tack,thumbs-down,thumbs-o-down,thumbs-o-up,thumbs-up,ticket,times,times-circle,times-circle-o,tint,toggle-down,toggle-left,toggle-right,toggle-up,trash-o,trophy,truck,umbrella,unlock,unlock-alt,unsorted,upload,user,users,video-camera,volume-down,volume-off,volume-up,warning,wheelchair,wrench,check-square,check-square-o,circle,circle-o,dot-circle-o,minus-square,minus-square-o,plus-square,plus-square-o,square,square-o,bitcoin,btc,cny,dollar,eur,euro,gbp,inr,jpy,krw,money,rmb,rouble,rub,ruble,rupee,try,turkish-lira,usd,won,yen,align-center,align-justify,align-left,align-right,bold,chain,chain-broken,clipboard,columns,copy,cut,dedent,eraser,file,file-o,file-text,file-text-o,files-o,floppy-o,font,indent,italic,link,list,list-alt,list-ol,list-ul,outdent,paperclip,paste,repeat,rotate-left,rotate-right,save,scissors,strikethrough,table,text-height,text-width,th,th-large,th-list,underline,undo,unlink,angle-double-down,angle-double-left,angle-double-right,angle-double-up,angle-down,angle-left,angle-right,angle-up,arrow-circle-down,arrow-circle-left,arrow-circle-o-down,arrow-circle-o-left,arrow-circle-o-right,arrow-circle-o-up,arrow-circle-right,arrow-circle-up,arrow-down,arrow-left,arrow-right,arrow-up,arrows,arrows-alt,arrows-h,arrows-v,caret-down,caret-left,caret-right,caret-square-o-down,caret-square-o-left,caret-square-o-right,caret-square-o-up,caret-up,chevron-circle-down,chevron-circle-left,chevron-circle-right,chevron-circle-up,chevron-down,chevron-left,chevron-right,chevron-up,hand-o-down,hand-o-left,hand-o-right,hand-o-up,long-arrow-down,long-arrow-left,long-arrow-right,long-arrow-up,toggle-down,toggle-left,toggle-right,toggle-up,arrows-alt,backward,compress,eject,expand,fast-backward,fast-forward,forward,pause,play,play-circle,play-circle-o,step-backward,step-forward,stop,youtube-play,adn,android,apple,bitbucket,bitbucket-square,bitcoin,btc,css3,dribbble,dropbox,facebook,facebook-square,flickr,foursquare,github,github-alt,github-square,gittip,google-plus,google-plus-square,html5,instagram,linkedin,linkedin-square,linux,maxcdn,pagelines,pinterest,pinterest-square,renren,skype,stack-exchange,stack-overflow,trello,tumblr,tumblr-square,twitter,twitter-square,vimeo-square,vk,weibo,windows,xing,xing-square,youtube,youtube-play,youtube-square,ambulance,h-square,hospital-o,medkit,plus-square,stethoscope,user-md,wheelchair';
		$icons = 'glass,music,search,envelope-o,heart,star,star-o,user,film,th-large,th,th-list,check,times,search-plus,search-minus,power-off,signal,gear,cog,trash-o,home,file-o,clock-o,road,download,arrow-circle-o-down,arrow-circle-o-up,inbox,play-circle-o,rotate-right,repeat,refresh,list-alt,lock,flag,headphones,volume-off,volume-down,volume-up,qrcode,barcode,tag,tags,book,bookmark,print,camera,font,bold,italic,text-height,text-width,align-left,align-center,align-right,align-justify,list,dedent,outdent,indent,video-camera,photo,image,picture-o,pencil,map-marker,adjust,tint,edit,pencil-square-o,share-square-o,check-square-o,arrows,step-backward,fast-backward,backward,play,pause,stop,forward,fast-forward,step-forward,eject,chevron-left,chevron-right,plus-circle,minus-circle,times-circle,check-circle,question-circle,info-circle,crosshairs,times-circle-o,check-circle-o,ban,arrow-left,arrow-right,arrow-up,arrow-down,mail-forward,share,expand,compress,plus,minus,asterisk,exclamation-circle,gift,leaf,fire,eye,eye-slash,warning,exclamation-triangle,plane,calendar,random,comment,magnet,chevron-up,chevron-down,retweet,shopping-cart,folder,folder-open,arrows-v,arrows-h,bar-chart-o,twitter-square,facebook-square,camera-retro,key,gears,cogs,comments,thumbs-o-up,thumbs-o-down,star-half,heart-o,sign-out,linkedin-square,thumb-tack,external-link,sign-in,trophy,github-square,upload,lemon-o,phone,square-o,bookmark-o,phone-square,twitter,facebook,github,unlock,credit-card,rss,hdd-o,bullhorn,bell,certificate,hand-o-right,hand-o-left,hand-o-up,hand-o-down,arrow-circle-left,arrow-circle-right,arrow-circle-up,arrow-circle-down,globe,wrench,tasks,filter,briefcase,arrows-alt,group,users,chain,link,cloud,flask,cut,scissors,copy,files-o,paperclip,save,floppy-o,square,navicon,reorder,bars,list-ul,list-ol,strikethrough,underline,table,magic,truck,pinterest,pinterest-square,google-plus-square,google-plus,money,caret-down,caret-up,caret-left,caret-right,columns,unsorted,sort,sort-down,sort-desc,sort-up,sort-asc,envelope,linkedin,rotate-left,undo,legal,gavel,dashboard,tachometer,comment-o,comments-o,flash,bolt,sitemap,umbrella,paste,clipboard,lightbulb-o,exchange,cloud-download,cloud-upload,user-md,stethoscope,suitcase,bell-o,coffee,cutlery,file-text-o,building-o,hospital-o,ambulance,medkit,fighter-jet,beer,h-square,plus-square,angle-double-left,angle-double-right,angle-double-up,angle-double-down,angle-left,angle-right,angle-up,angle-down,desktop,laptop,tablet,mobile-phone,mobile,circle-o,quote-left,quote-right,spinner,circle,mail-reply,reply,github-alt,folder-o,folder-open-o,smile-o,frown-o,meh-o,gamepad,keyboard-o,flag-o,flag-checkered,terminal,code,mail-reply-all,reply-all,star-half-empty,star-half-full,star-half-o,location-arrow,crop,code-fork,unlink,chain-broken,question,info,exclamation,superscript,subscript,eraser,puzzle-piece,microphone,microphone-slash,shield,calendar-o,fire-extinguisher,rocket,maxcdn,chevron-circle-left,chevron-circle-right,chevron-circle-up,chevron-circle-down,html5,css3,anchor,unlock-alt,bullseye,ellipsis-h,ellipsis-v,rss-square,play-circle,ticket,minus-square,minus-square-o,level-up,level-down,check-square,pencil-square,external-link-square,share-square,compass,toggle-down,caret-square-o-down,toggle-up,caret-square-o-up,toggle-right,caret-square-o-right,euro,eur,gbp,dollar,usd,rupee,inr,cny,rmb,yen,jpy,ruble,rouble,rub,won,krw,bitcoin,btc,file,file-text,sort-alpha-asc,sort-alpha-desc,sort-amount-asc,sort-amount-desc,sort-numeric-asc,sort-numeric-desc,thumbs-up,thumbs-down,youtube-square,youtube,xing,xing-square,youtube-play,dropbox,stack-overflow,instagram,flickr,adn,bitbucket,bitbucket-square,tumblr,tumblr-square,long-arrow-down,long-arrow-up,long-arrow-left,long-arrow-right,apple,windows,android,linux,dribbble,skype,foursquare,trello,female,male,gittip,sun-o,moon-o,archive,bug,vk,weibo,renren,pagelines,stack-exchange,arrow-circle-o-right,arrow-circle-o-left,toggle-left,caret-square-o-left,dot-circle-o,wheelchair,vimeo-square,turkish-lira,try,plus-square-o,space-shuttle,slack,envelope-square,wordpress,openid,institution,bank,university,mortar-board,graduation-cap,yahoo,google,reddit,reddit-square,stumbleupon-circle,stumbleupon,delicious,digg,pied-piper-square,pied-piper,pied-piper-alt,drupal,joomla,language,fax,building,child,paw,spoon,cube,cubes,behance,behance-square,steam,steam-square,recycle,automobile,car,cab,taxi,tree,spotify,deviantart,soundcloud,database,file-pdf-o,file-word-o,file-excel-o,file-powerpoint-o,file-photo-o,file-picture-o,file-image-o,file-zip-o,file-archive-o,file-sound-o,file-audio-o,file-movie-o,file-video-o,file-code-o,vine,codepen,jsfiddle,life-bouy,life-saver,support,life-ring,circle-o-notch,ra,rebel,ge,empire,git-square,git,hacker-news,tencent-weibo,qq,wechat,weixin,send,paper-plane,send-o,paper-plane-o,history,circle-thin,header,paragraph,sliders,share-alt,share-alt-square,bomb';

        $icons = preg_split('/,/', $icons);
	
		$html  = '';
		//$html .= '<div class="aps-modal-icon-preview preview-white"><i class=""></i></div>';
		//$html .= '<div class="aps-modal-icon-preview preview-black"><i class=""></i></div>';
		//$html .= '<div class="aps-modal-icon-preview preview-square"><i class=""></i></div>';
		//$html .= '<div class="aps-modal-icon-preview preview-rounded-fill"><i class=""></i></div>';
		//$html .= '<div class="aps-modal-icon-preview preview-rounded"><i class=""></i></div>';
		//$html .= '<div class="aps-modal-icon-preview preview-circle-fill"><i class=""></i></div>';
		//$html .= '<div class="aps-modal-icon-preview preview-circle"><i class=""></i></div>';
		
		
		$html .= '<div class="aps-modal-select-icon-wrap">';
		foreach($icons as $icon){
			//$html .= '<div class="modal-select-icon-inner">';
			if ($element['value']==$icon) {
				$selected = ' icon-selected';
			} else {
				$selected = '';
			}
			$html .= '<i class="modal-select-icon'.$selected.' fa fa-'.$icon.'" data-icon="'.$icon.'"></i>';
			//$html .= '<span class="text">'.$icon.'</span>';
			//$html .= '</div>';
		}
		$html .= '</div>';
		$html .= '<input class="selected-icon" value="" name="'.$element['id'].'" id="'.$element['id'].'">';
		
		return $html;
	}

	
	static function render_select_categories($element, $parent = false)
	{
		//Listado de opciones
		$args = array(
		'type'                     => 'post',
		'child_of'                 => 0,
		'parent'                   => '',
		'orderby'                  => 'name',
		'order'                    => 'ASC',
		'hide_empty'               => false,
		'hierarchical'             => 1,
		'exclude'                  => '',
		'include'                  => '',
		'number'                   => '',
		'taxonomy'                 => 'category',
		'pad_counts'               => false 
		);
		$categories = get_categories( $args );
		
		$options = array();
		if ($categories) {
			foreach($categories as $cat){
				$options[$cat->slug] = $cat->name;
			}
		}
		//$field['options'] = $options;
		
		$html  = '<div class="field-select-wrap">';
		$html .= '<select class="aps-modal-field-select chosen-select'.$element['class'].'" name="'.$element['id'].'" id="'.$element['id'].'" data-placeholder="Select..." multiple>';
		foreach($options as $key=>$value){
			$html .= '<option value="'.$key.'">'.$value.'</option>';
		}
		$html .= '</select>';
		$html .= '</div>';
		return $html;
	}




    static function render_select_custom_post($element, $parent=false)
    {
        $post_types = get_post_types(array('public' => true), 'objects');

        $html  = '<div class="field-select-wrap">';
        $html .= '<div class="field-select-arrow">+</div>';
        $html .= '<select class="aps-modal-field-select '.$element['class'].'" name="'.$element['id'].'" id="'.$element['id'].'" data-placeholder="Select...">';

        foreach( $post_types as $post_type) {
            if (in_array($post_type->name, $element['exclude_custom_posts'])) continue;
            $html .= '<option value="' . $post_type->name . '">' . $post_type->label . '</option>';
        }
        $html .= '</select>';
        $html .= '</div>';
        return $html;
    }

    static function render_select_custom_categories($element, $parent=false)
    {

        $post_types = get_post_types(array('public' => true), 'objects');
        $html = '';

        foreach( $post_types as $post_type) {

            if (isset($element['exclude_custom_posts']) && in_array($post_type->name, $element['exclude_custom_posts'])) continue;

            if ( isset($element['include_custom_posts']) && !in_array($post_type->name, $element['include_custom_posts']) ) continue;

            $field = array(
                'label' => __('', APS_PB_LANG),
                'desc' => __('', APS_PB_LANG),
                'id' => $element['id'] . '_' . $post_type->name,
                'type' => 'select_multiple_chosen',
                'class-wrap' => 'field-fullwidth'
            );

            if (isset($element['required'])){
                $field['required'] = $element['required'];
            }
            if (isset($element['required_post_type'])) {
                $field['required'] = $element['required_post_type'].'->'.$post_type->name;
            }
            //echo '<pre>'; print_r( $element ); echo '</pre>';
            //echo '<pre>'; print_r( $field ); echo '</pre>';

            $options = [];
            $taxonomies = get_object_taxonomies($post_type->name);
            foreach ($taxonomies as $taxonomy) {
                if (is_taxonomy_hierarchical($taxonomy)) {
                    $terms = get_terms($taxonomy);
                    foreach ($terms as $term) {
                        $value = $taxonomy . '::' . $term->slug;
                        $options[$value] = $term->name;
                    }
                }
            }
            $field['options'] = $options;
            //echo '<pre>'; print_r($field); echo '</pre>';
            $html .= self::render_element($field, $parent);

        }
        return $html;
    }

    static function render_select_custom_tags($element, $parent=false)
    {
        $post_types = get_post_types(array('public' => true), 'objects');
        $html = '';

        foreach( $post_types as $post_type) {

            if (isset($element['exclude_custom_posts']) && in_array($post_type->name, $element['exclude_custom_posts'])) continue;

            if ( isset($element['include_custom_posts']) && !in_array($post_type->name, $element['include_custom_posts']) ) continue;

            $field = array(
                'label' => __('', APS_PB_LANG),
                'desc' => __('', APS_PB_LANG),
                'id' => $element['id'] . '_' . $post_type->name,
                'type' => 'select_multiple_chosen',
                'class-wrap' => 'field-fullwidth'
            );

            if (isset($element['required'])){
                $field['required'] = $element['required'];
            }
            if (isset($element['required_post_type'])) {
                $field['required'] = $element['required_post_type'].'->'.$post_type->name;
            }

            $options = [];
            $taxonomies = get_object_taxonomies($post_type->name);
            foreach ($taxonomies as $taxonomy) {
                if (!is_taxonomy_hierarchical($taxonomy)) {
                    $terms = get_terms($taxonomy);
                    foreach ($terms as $term) {
                        $value = $taxonomy . '::' . $term->slug;
                        $options[$value] = $term->name;
                    }
                }
            }
            $field['options'] = $options;
            //echo '<pre>'; print_r($field); echo '</pre>';
            $html .= self::render_element($field, $parent);

        }
        return $html;

    }
    static function render_select_yes_no($element, $parent=false)
    {
        if ($element['value']=='yes') {
            $cheked_yes = 'checked="checked"';
            $cheked_no = '';
        } else {
            $cheked_no = 'checked="checked"';
            $cheked_yes = '';
        }
        $html  = '<label><input type="radio" name="'.$element['id'].'" id="'.$element['id'].'" '.$cheked_yes.' value="yes">Yes </label>&nbsp;&nbsp;&nbsp;';
        $html .= '<label><input type="radio" name="'.$element['id'].'" id="'.$element['id'].'" '.$cheked_no.' value="no">No</label>';
        return $html;
    }


    //Componente facil para un strip
    static function render_strip($element, $parent=false)
    {
        //Tengo un campo general que indica el numero de strips
        //Por cada strip:
        // - input para guardar el shortcode del strip
        // - tinymce para el content del shortcode

        $html = '<input type="text" class="aps-modal-field-input '.$element['class'].'" name="'.$element['id'].'" id="'.$element['id'].'" value="'.$element['value'].'">';

        $html .= '<div class="aps-modal-group">';
        $html .= '</div>';

        return $html;
    }
	
}//class
}










