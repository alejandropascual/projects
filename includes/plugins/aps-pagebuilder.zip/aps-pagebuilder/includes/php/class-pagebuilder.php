<?php
/**************************************
* Clase principal del Page Builder
*/

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'APSPageBuilder' ) ) {


	class APSPageBuilder
	{
		public $path;
		public $shortcode_classes;
		
		public function __construct()
		{
			$this->path = trailingslashit(dirname( dirname(__FILE__)));
			add_action('init', array($this,'init'), 10);
			add_action('init', array($this,'load_shortcodes'), 5);
			add_action('load-post.php', 	array($this, 'admin_init') , 5 );
			add_action('load-post-new.php', array($this, 'admin_init') , 5 );
		}
	
		public function init()
		{
			$this->create_shortcodes();
			$this->create_tinymce_button();
			
			
			//Solo mis shortcodes
			//Al hacer esto me esta alterando el orden de aplicacion del shortcode
			//y aplica el filter the_content despues de aplicar el shortcode y me da problemas
			//por ejemplo en aps_gallery
			//add_filter('the_content',array($this,'fix_shortcodes'),7);
		}
		
		public function admin_init()
		{
			$this->load_admin_filters();
			$this->load_admin_actions();
		}
		
		public function load_shortcodes()
		{
			//requiere_once($this->path.'class-shortcode.php');	
			$path_sc = $this->path.'php-sc/';
			
			//Cargar los shortcodes
			foreach(glob($path_sc.'*.php') as $file)
			{
				require_once($file);
			}
		}
		
		public function load_admin_filters()
		{
			
		}
		
		public function load_admin_actions()
		{
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts_styles' ) );
			//add_action( 'save_post', array($this, 'save_post'));
		}
		
		public function admin_scripts_styles()
		{
			//JS
			//wp_enqueue_script('chosen', APS_PAGEBUILDER_URL.'/includes/vendors/chosen/chosen.jquery.js', array('jquery'));
			wp_enqueue_script('aps_sc_modal_js', APS_PAGEBUILDER_URL.'/includes/js/admin/aps-sc-modal.js', array('jquery','jquery-ui-core', 'jquery-ui-sortable', 'jquery-ui-droppable','wp-color-picker'), TRUE);
			
			//CSS
			wp_enqueue_style( 'pagebuilder_css' , APS_PAGEBUILDER_URL.'/includes/styles/css/pagebuilder.css');
			wp_enqueue_style( 'wp-color-picker' );

		}
		
		public function save_post($post_id, $post)
		{
			
		}
		
		public function create_tinymce_button()
		{
			$sc = array();
			foreach($this->shortcode_classes as $class){
				$sc[] = $class->options;
			}

            //Tinymce segun version wp
            if ( floatval( get_bloginfo( 'version' ) ) >= 3.9 ) {
                $tinymce_js = 'aps-pb-tinymce.js';
            } else {
                $tinymce_js = 'aps-pb-tinymce-legacy.js';
            }

			$args = array(
				'id' 					=> 'aps_shortcodes_button',
				'title' 			=> __('Create shortcode',APS_PB_LANG),
				'icon' 				=> APS_PAGEBUILDER_URL.'/includes/js/admin/aps-shortcodes.png',
				'file' 				=> APS_PAGEBUILDER_URL.'/includes/js/admin/'.$tinymce_js,
				//'file' 				=> APS_PAGEBUILDER_URL.'/includes/js/admin/kk-tiny.js',
				'shortcodes' 	=> $sc
			);
			
			new APSTinymce($args);
		}
		
		public function fix_shortcodes($content)
		{
			global $shortcode_tags;
	
		    // Backup current registered shortcodes and clear them all out
		    $orig_shortcode_tags = $shortcode_tags;
		    
		    $shortcode_tags = array();
		    
		    //Borrar
		    remove_all_shortcodes();
		    
		    //Registrarlos denuevo
		    $this->register_shortcodes();
		    
		    //Aplicarlos
		    $content = do_shortcode( $content );
		    
		    //Restaurar los originales
		    $shortcode_tags = $orig_shortcode_tags;
		     
		    return $content; 
		}
	
		public function create_shortcodes()
		{
			$children = array();
			
			//var_dump(get_declared_classes());
			
			foreach(get_declared_classes() as $class)
			{
				if(is_subclass_of($class, 'APSShortcode'))
				{
					//Lo inicio pasandole el builder
					$shortcode = new $class($this);
					
					$this->shortcode_classes[$class] = $shortcode;
					
					//$name_shortcode = str_replace('SC_', '', $class);
					$name_shortcode = $class;
					
					//Guardo el nombre del shortcode
					$shortcode->config['shortcode'] = $name_shortcode;
					
					//Lamar al inicio
					$this->shortcode_classes[$class]->init();
				}
			}
		}
		
		
		public function register_shortcodes()
		{
			foreach($this->shortcode_classes as $shortcode)
			{
				$shortcode->register_shortcode();
			}
		}
		
		public function sort_by_order($a,$b)
		{
			if(empty($a['order'])) $a['order'] = 10;
			if(empty($b['order'])) $b['order'] = 10;
			
   			return $b['order'] >= $a['order'];
		}
	
	}//end class
	
	
}