<?php


// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }


if ( !class_exists( 'APSShortcode' ) )
{
	abstract class APSShortcode
	{
		var $builder;
		var $options = array();
		
		function __construct($builder)
		{
			$this->builder = $builder;
			$this->create_shortcode_options();
			$this->create_shortcode_fields();
		}
		
		public function init()
		{
			$this->register_shortcode();
			$this->register_actions_and_filters();
		}

		public function register_shortcode()
		{
			$name_shortcode = $this->options['shortcode'];
			add_shortcode($name_shortcode, array($this, 'shortcode_handler'));
			//echo 'REGISTRANDO SHORTCODE '.$name_shortcode.'<br>';
		}
		
		
		//Crear boton para el tiny editor
		abstract function create_shortcode_options();
		
		
		
		//Crear datos generales y cargar los fields
		protected function create_shortcode_fields()
		{		
			if(method_exists($this, 'modal_fields'))
			{
				$this->modal_fields();
				//$this->options['modal_editor'] = true;
			}
		}
		
		
		//Shortcode handler
		abstract function shortcode_handler($atts, $content = null);
		
		
		//Le añade una cadena al final del shortcode para
		//pasar valores de un shortcode al shortcode-nested
		public function add_to_shortcode($content, $name_shortcode, $cadena)
		{
			return preg_replace('/(\['.$name_shortcode.'.*?)(\])/', '$1 '.$cadena.']', $content);
		}
		
		protected function register_actions_and_filters()
		{
		
			//Si es por ejemplo el aps_accordion_item esta oculto y no tiene ajax 
			//porque se lo proporciona el nested dentro del aps_accordion
			//Por eso aqui debo evitarlo
			if (isset($this->options['hidden']) && $this->options['hidden'] == 'yes')
				return ;
			
			
			//Shortcode principal
			add_action('wp_ajax_aps_modal_'.$this->options['shortcode'], array($this, 'modal_window'));
			
			//Shortcode nested register hook
			
			if (!empty($this->options['shortcode_nested'])) {
				foreach($this->options['shortcode_nested'] as $sc)
				{
					add_action('wp_ajax_aps_modal_'.$sc, array($this, 'modal_window'));
				}
			}
		}
		
		
		
		// Modal window que envia desde ajax
		public function modal_window()
		{
			
			if (empty($this->fields)) die();
			//echo '<pre>'; print_r($this->fields); echo '</pre>';
			
			//Shortcode normal
			$fields = $this->fields;
			
			//Es un subelemento, lo busco dentro de los fields
			if (!empty($_POST['params']['submodal'])){
				foreach($fields as $field) {
					if (isset($field['subfields'])){
						$fields = $field['subfields'];
						break;
					}
				}
			}
			
			//Render
			$fields = $this->set_fields_values($fields);
			
			echo APShtmlBuilder::render_several_elements($fields, $this);
			die();
		}
		
		
		
		//Establece los valores recibidos para un submodal en los fields
		//antes de renderizarlos
		public function set_fields_values($fields)
		{

			if (empty($_POST['params']['shortcode'])) return $fields;
			
			$sc = $_POST['params']['shortcode'];
			
			$new_fields = array();
			
			//Extraer el shortcode para aplicar los valores
			foreach($fields as $field)
			{
                if ( !isset($field['id']) ) continue;
				//Es un content entre [sc]content[/sc]
				//if ($field['id']=='content') {
				if (preg_match('/content/', $field['id'])) {
					
					if (preg_match("/\[.+?\](.+)\[\/.+?\]/m", $sc, $matches))
					{
						$field['value'] = $matches[1];
					}
					
				} else {
					
					if (preg_match("/".$field['id']."=\\\'(.+?)\\\'/m", $sc, $matches))
					{
						$field['value'] = $matches[1];
					}
				}
				$new_fields[] = $field;
			}
			
			
			return $new_fields;
		}
		
		
		//UTIL
		function get_select_width_pixels($min=0, $max=20)
		{
			$options = array();
			for ($i=$min; $i<=$max; $i++)
			{
				$options[$i.'px']=$i.'px';
			}
			return $options;
		}
		
		//UTIL
		//Si $image_src existe devuelve este,
		//si no lo obtiene de los media
		public function get_image_from($image_src='',$image_id='',$image_size='medium')
		{
			//if ($image_src!='') return get_url_media($this->$image_src); //Por si es parcial
            if ($image_src != '') { return $image_src; }

			$attachment = get_post($image_id);
			if ($attachment) {
				$img_poster = wp_get_attachment_image_src($attachment->ID, $image_size);
				return $img_poster[0];	
  			}
  			return '';
		}
		
		
		//UTIL
		public function get_image_sizes()
		{
			global $_wp_additional_image_sizes;
	     	$sizes = array();
	 		foreach( get_intermediate_image_sizes() as $s ){
	 			$sizes[ $s ] = array( 0, 0 );
	 			if( in_array( $s, array( 'thumbnail', 'medium', 'large' ) ) ){
	 				$sizes[ $s ][0] = get_option( $s . '_size_w' );
	 				$sizes[ $s ][1] = get_option( $s . '_size_h' );
	 			}else{
	 				if( isset( $_wp_additional_image_sizes ) && isset( $_wp_additional_image_sizes[ $s ] ) )
	 					$sizes[ $s ] = array( $_wp_additional_image_sizes[ $s ]['width'], $_wp_additional_image_sizes[ $s ]['height'], );
	 			}
	 		}
	 		//echo '<pre>'; print_r($sizes); echo '</pre>';
	 		/*
	 		foreach( $sizes as $size => $atts ){
	 			echo $size . ' ' . implode( 'x', $atts ) . "\n";
	 		}
	 		*/
	 		$options = array();
	 		foreach ($sizes as $name=>$values)
	 		{
	 			if ($values[1]!=0){
		 			$options[$name]=$name.' ('.$values[0].'x'.$values[1].')';
	 			} else {
		 			$options[$name]=$name.' ('.$values[0].')';
	 			}
		 		
	 		}
	 		$options['original'] = 'Original Size';
	 		return $options;
		}

        public function get_image_sizes_array()
        {
            global $_wp_additional_image_sizes;
            $sizes = array();
            foreach( get_intermediate_image_sizes() as $s ){
                $sizes[ $s ] = array( 0, 0 );
                if( in_array( $s, array( 'thumbnail', 'medium', 'large' ) ) ){
                    $sizes[ $s ][0] = get_option( $s . '_size_w' );
                    $sizes[ $s ][1] = get_option( $s . '_size_h' );
                }else{
                    if( isset( $_wp_additional_image_sizes ) && isset( $_wp_additional_image_sizes[ $s ] ) )
                        $sizes[ $s ] = array( $_wp_additional_image_sizes[ $s ]['width'], $_wp_additional_image_sizes[ $s ]['height'], );
                }
            }
            return $sizes;
        }
		
		
		// =============================================================================
		//	Calcular url media cuando le pasa una parcial
		// =============================================================================
		
		public function get_url_media($path) {
			if (!isset($path) || $path=='' || strlen($path)<2){
				return '';
			} else {
				if (preg_match('/http:\/\//', $path)){
					return $path;
				} else {
					$upload_dir = wp_upload_dir();
					//echo '<pre>'; print_r($upload_dir); echo '</pre>';
					$url = $upload_dir['baseurl'].$path;
					return $url;
				}
			}
		}


        // =============================================================================
        //	Placehold image and text
        // =============================================================================

        public function dame_placehold_image ($width, $height, $text='no image')
        {
            $text = str_replace(' ','+',$text);
            $name = 'http://placehold.it/'.$width.'x'.$height.'&text='.$text;
            return array(
                'image' => '<img src="'.$name.'" width="'.$width.'" height="'.$height.'">',
                'src' => $name,
                'width' => $width,
                'height' => $height
            );
        }

        // =============================================================================
        //	Completar con px, ex 500 pasa a 500px
        // =============================================================================
        //Comprueba que no este vacio ni lleve %
        public function completar_numero_con_px ($text)
        {
            if ( $text=='' || $text==0 ) return $text;
            if ( strpos($text,'%') ) return $text;
            if ( strpos($text,'px') ) return $text;
            return $text.'px';
        }

    }
}