<?php

if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'APSTinymce' ) ) 
{
	class APSTinymce
	{
		var $button;
		
		function __construct($button=array()) 
		{
			$default = array(
				'id' 					=> '',
				'title' 			=> '',
				'icon' 				=> '',
				'file' 				=> '',
				'shortcodes' 	=> array()
			);
			
			$this->button = array_merge($default, $button);
			$this->create_button();
		}
		
		function create_button()
		{
			//echo '<pre>'; print_r($this->button); echo '</pre>';
			if ( current_user_can('edit_posts') &&  current_user_can('edit_pages') )
			{
				add_filter( 'mce_external_plugins' 	, array( $this, 'mce_add_js' ) );
				add_filter( 'admin_print_scripts' 	, array( $this, 'mce_add_js_globals' ) );
				add_filter( 'mce_buttons' 	, array( $this, 'mce_add_button' ) ); 
			}
		}
		
		// javascript for tinymce editor
		function mce_add_js($plugin_array)
		{
			$plugin_array[$this->button['id']] = $this->button['file'];
			//$plugin_array['aps_shortcodes'] = $this->button['file'];
			return $plugin_array; 
		}
		
		// globals for the tiny mce
		function mce_add_js_globals()
		{
			$id = $this->button['id'];
			
			echo "\n <script type='text/javascript'>\n";
			echo "var aps_globals = aps_globals || {};\n";
			echo "    aps_globals.sc = aps_globals.sc || {};\n";
			echo "    aps_globals.sc['".$id."'] = [];\n";
			echo "    aps_globals.sc['".$id."'].title = '".$this->button['title']."';\n";
			echo "    aps_globals.sc['".$id."'].icon = '".$this->button['icon']."';\n";
			echo "    aps_globals.sc['".$id."'].buttons = [];\n";
			
			foreach( $this->button['shortcodes'] as $shortcode)
			{
				if ( !( isset($shortcode['hidden']) && $shortcode['hidden']=='yes' ) ) {
					echo "    aps_globals.sc['".$id."'].buttons['".$shortcode['shortcode']."'] = ".json_encode($shortcode).";\n";
				}
			}
			
			echo "</script>\n \n ";
		}
		
		// buttons for the tiny mce editor
		function mce_add_button($buttons)
		{	
			//array_push( $buttons, 'aps_shortcodes_button' );
			array_push($buttons, $this->button['id']);
			return $buttons;
		}
		
		
		
	}
	
}