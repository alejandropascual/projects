<?php

/*
 Añade metaboxes a las pages para que sea mas facil ejecutar el shortcode
 para tipo blog y tipo aps_project si esta activo

Usa las clases;
class-metabox.php
class-htmlhelper.php

que estan en:

- EL tema aps_base
- El plugin : layout-builder
- El plugin : aps-projects
- El plugin : aps-postformats
-
*/

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

$boxes = array(
    array(
        'id' 		=> 'page_extra_content',
        'title' 	=> __('BLOG / GALLERY',APS_PB_LANG),
        'page' 		=> array('page'),
        'context' 	=> 'normal',
        'priority'	=> 'high'
    ),
    array(
        'id' 		=> 'page_extra_content_below',
        'title' 	=> __('CONTENT BELOW BLOG',APS_PB_LANG),
        'page' 		=> array('page'),
        'context' 	=> 'normal',
        'priority'	=> 'high'
    )
    /*array(
        'id' 		=> 'page_content_strips',
        'title' 	=> __('CONTENT with STRIPS',APS_PB_LANG),
        'page' 		=> array('page'),
        'context' 	=> 'normal',
        'priority'	=> 'high'
    )*/
);


$subfields = array(

    array(
        //'box_id'	=> 'page_content',
        'id'		=> 'display_position',
        'title'		=> __('Where to display this extra content.', APS_PB_LANG) ,
        'desc'      => __('', APS_PB_LANG) ,
        'type' 		=> 'select',
        'value'		=> 'post',
        'options'   => array(
            'above'  => 'ABOVE the main content of the page',
            'below'  => 'BELOW the main content of the page'
        )
    ),


    array(
        'title' => __('SOURCE', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'kk',
        'type'  => 'title',
        //'value' => '',
    ),

    array(
        //'box_id'	=> 'page_content',
        'id'		=> 'content_post_type',
        'title'		=> __('Select the source', APS_PB_LANG) ,
        'desc'      => __('', APS_PB_LANG) ,
        'type' 		=> 'select',
        'value'		=> 'post',
        'options'   => array(
            'post'  => 'Show posts',
            'aps_project' => 'Show projects'
        )
    ),


    //Seleccionar posts
    array(
        //'box_id'	=> 'page_content',
        'title' => __('Select by', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'select_by',
        'type'  => 'select',
        'value' => 'by_filter',
        'options' => array('by_filter'=>'Filter by category | tag', 'by_ids'=>'Posts by ID'),
    ),
    array(
        //'box_id'	=> 'page_content',
        'title' => __('Posts ID', APS_PB_LANG) ,
        'desc'  => __('Insert ID separated by commas. Example: 34,56,89', APS_PB_LANG) ,
        'id'    => 'post_ids',
        'type'  => 'input',
        'value' => '',
        'required'	=> array('select_by','by_ids')
    ),

    //Muestra las categorias de cada custom post
    array(
        //'box_id'	=> 'page_content',
        'title' => __('', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'categories',
        'type'  => 'select_custom_categories',
        'type-hierarchy' => 'yes', //Son categories
        //'required' => array('select_by','by_filter'),
        'include_custom_posts' => array('post'),
        'required'	=> array('content_post_type','post')
    ),
    array(
        //'box_id'	=> 'page_content',
        'title' => __('', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'categories',
        'type'  => 'select_custom_categories',
        'type-hierarchy' => 'yes', //Son categories
        //'required' => array('select_by','by_filter'),
        'include_custom_posts' => array('aps_project'),
        'required'	=> array('content_post_type','aps_project')
    ),

    //Muestra los tags de cada custom post
    array(
        //'box_id'	=> 'page_content',
        'title' => __('', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'tags',
        'type'  => 'select_custom_categories',
        'type-hierarchy' => 'no', //Son tags
        //'required' => array('select_by','by_filter'),
        'include_custom_posts' => array('post'),
        'required'	=> array('content_post_type','post')
    ),
    array(
        //'box_id'	=> 'page_content',
        'title' => __('', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'tags',
        'type'  => 'select_custom_categories',
        'type-hierarchy' => 'no', //Son tags
        //'required' => array('select_by','by_filter'),
        'include_custom_posts' => array('aps_project'),
        'required'	=> array('content_post_type', 'aps_project')
    ),

    //Relacion AND OR
    array(
        //'box_id'	=> 'page_content',
        'title' => __('Filter Relation', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'query_relation',
        'type'  => 'select',
        'required' => array('select_by','by_filter'),
        'options' => array('AND'=>'AND', 'OR'=>'OR')
    ),


    array(
        'title' => __('POST - featured image or gallery', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'kk',
        'type'  => 'title',
        'class' => 'title-featured-image-gallery'
        //'value' => '',
    ),
    //Use featured image or show all images of the gallery
    array(
        //'box_id'	=> 'page_content',
        'title' => __('Use featured Image or Gallery', APS_PB_LANG) ,
        'desc'  => __('You can show just the featured image if you want to create a list of posts, <br>or show all the images of the gallery for each filtered post', APS_PB_LANG) ,
        'id'    => 'use_gallery_of_post',
        'type'  => 'select',
        'value' => 'no',
        'options' => array('no'=>'Use only featured image', 'yes'=>'Use all the gallery images in the post'),
    ),


    // TIPO DE GALERIA
    array(
        'title' => __('TYPE OF GALLERY', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'kk',
        'type'  => 'title',
        //'value' => '',
    ),
    array(
        //'box_id'	=> 'page_content',
        'title' => __('Type', APS_PB_LANG) ,
        //'class' => 'aps-title-grande',
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'type',
        'type'  => 'select',
        'value' => 'masonry_image',
        'options' => array(
            'masonry_image'                     => 'Masonry with image',
            'masonry_image_and_text'            => 'Masonry with image and text',
            'grid_image'                        => 'Grid with image',
            'grid_image_and_text'               => 'Grid with image and text',
            'justified_grid_image'              => 'Justified grid image',
            'list_image_and_text'               => 'List',
            'list_image_and_text_alternate'     => 'List alternate',
            'gallery_image'                     => 'Slider',
            'gallery_image_and_text'            => 'Slider with text',
            'fullwidth_image'                   => 'Fullwidth image'
        ),
    ),



    //Masonry
    array(
        //'box_id'	=> 'page_content',
        'title' => __('Masonry: image width in pixels', APS_PB_LANG) ,
        'desc'  => __('example: 300', APS_PB_LANG) ,
        'id'    => 'masonry_width',
        'type'  => 'input',
        'value' => 300,
        'required' => array('type','masonry_image,masonry_image_and_text')
    ),
    array(
        //'box_id'	=> 'page_content',
        'title' => __('Masonry: separation between elements in pixels', APS_PB_LANG) ,
        'desc'  => __('example: 2', APS_PB_LANG) ,
        'id'    => 'masonry_margin',
        'type'  => 'input',
        'value' => 2,
        'required' => array('type','masonry_image,masonry_image_and_text')
    ),

//Grid
    array(
        'title' => __('Grid: number of columns', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'grid_cols',
        'type'  => 'select',
        'value' => '4',
        'required' => array('type','grid_image,grid_image_and_text'),
        'options' => array('2'=>'2', '3'=>'3', '4'=>'4', '5'=>'5', '6'=>'6')
    ),
    array(
        'title' => __('Grid: image width in pixels', APS_PB_LANG) ,
        'desc'  => __('example: 300', APS_PB_LANG) ,
        'id'    => 'grid_width',
        'type'  => 'input',
        'value' => 300,
        'required' => array('type','grid_image,grid_image_and_text'),
    ),
    array(
        'title' => __('Grid: separation between elements in pixels', APS_PB_LANG) ,
        'desc'  => __('example: 2', APS_PB_LANG) ,
        'id'    => 'grid_padding',
        'type'  => 'input',
        'value' => 2,
        'required' => array('type','grid_image,grid_image_and_text'),
    ),
    array(
        'title' => __('Grid: ratio image vertical/horizontal', APS_PB_LANG) ,
        'desc'  => __('examples: 1 (square)<br>0.5 (landscape)<br>2 (vertical)', APS_PB_LANG) ,
        'id'    => 'grid_ratio',
        'type'  => 'input',
        'value' => 0.75,
        'required' => array('type','grid_image,grid_image_and_text'),
    ),

    //Justified grid
    array(
        'title' => __('Justified grid: column height en pixels', APS_PB_LANG) ,
        'desc'  => __('example: 300', APS_PB_LANG) ,
        'id'    => 'jgrid_height',
        'type'  => 'input',
        'value' => 300,
        'required' => array('type','justified_grid_image'),
    ),
    array(
        'title' => __('Justified grid: separation between elements in pixels', APS_PB_LANG) ,
        'desc'  => __('example: 1', APS_PB_LANG) ,
        'id'    => 'jgrid_padding',
        'type'  => 'input',
        'value' => 1,
        'required' => array('type','justified_grid_image'),
    ),

    //List
    array(
        'title' => __('List: image width in pixels', APS_PB_LANG) ,
        'desc'  => __('example: 400', APS_PB_LANG) ,
        'id'    => 'list_width',
        'type'  => 'input',
        'value' => 400,
        'required' => array('type', 'list_image_and_text,list_image_and_text_alternate'),
    ),
    array(
        'title' => __('List: ratio image vertical/horizontal', APS_PB_LANG) ,
        'desc'  => __('examples: 1 (square)<br>0.5 (landscape)<br>2 (vertical)', APS_PB_LANG) ,
        'id'    => 'list_ratio',
        'type'  => 'input',
        'value' => 0.75,
        'required' => array('type', 'list_image_and_text,list_image_and_text_alternate'),
    ),

    //Slider
    array(
        'title' => __('Slider: image width in pixels', APS_PB_LANG) ,
        'desc'  => __('example: 800', APS_PB_LANG) ,
        'id'    => 'gallery_width',
        'type'  => 'input',
        'value' => 800,
        'required' => array('type', 'gallery_image,gallery_image_and_text'),
    ),
    array(
        'title' => __('Slider full-screen', APS_PB_LANG) ,
        'desc'  => __('This will force the height of the slider to the height of the screen (minus header height)', APS_PB_LANG) ,
        'id'    => 'gallery_fullscreen',
        'type'  => 'yes_no',
        'value' => 'no',
        'required' => array('type', 'gallery_image,gallery_image_and_text'),
    ),
    array(
        'title' => __('Slider: image height in pixels', APS_PB_LANG) ,
        'desc'  => __('example: 500 (only valid when not in full-screen)', APS_PB_LANG) ,
        'id'    => 'gallery_height',
        'type'  => 'input',
        'value' => 500,
        'required' => array('type', 'gallery_image,gallery_image_and_text'),
    ),
    array(
        'title' => __('Slider: image mode', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'gallery_mode',
        'type'  => 'select',
        'value' => 'fill',
        'required' => array('type', 'gallery_image,gallery_image_and_text'),
        'options' => array(
            'fill' => 'Fill: image will expand to fill the slider container',
            'fit' => 'Fit: image will fit inside the slider container'
        )
    ),
    array(
        'title' => __('Slider: display post excerpt', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'gallery_text_desc',
        'type'  => 'yes_no',
        'value' => 'yes',
        'required' => array('type', 'gallery_image_and_text'),
        'options' => array(
            'yes' => 'Yes, display below the title',
            'no' => 'No'
        )
    ),
    //Fullwidth image
    array(
        'title' => __('Slider: image width in pixels', APS_PB_LANG) ,
        'desc'  => __('example: 800', APS_PB_LANG) ,
        'id'    => 'fullwidth_width',
        'type'  => 'input',
        'value' => 800,
        'required' => array('type', 'fullwidth_image'),
    ),
    array(
        'title' => __('Slider: image height in pixels', APS_PB_LANG) ,
        'desc'  => __('Example: 400 or <br>Leave it blank if you do not want to crop the image.', APS_PB_LANG) ,
        'id'    => 'fullwidth_height',
        'type'  => 'input',
        'value' => 400,
        'required' => array('type', 'fullwidth_image'),
    ),



    //Paging
    array(
        'title' => __('PAGINATION', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'kk',
        'type'  => 'title',
        //'value' => '',
    ),
    array(
        'title' => __('Pagination type', APS_PB_LANG) ,
        //'class' => 'aps-title-grande',
        'desc'  => __('Not valid for Slider', APS_PB_LANG) ,
        'id'    => 'paging_type',
        'type'  => 'select',
        'value' => 'no',
        'required' => array('use_gallery_of_post', 'no'),
        'options' => array(
            'none'      => 'No pagination. Show all elements',
            'numbers'   => 'Pagination with Numbers',
            'ajax'      => 'Pagination with Load-More button',
            'scroll' => 'Infinite scroll'
        )
    ),
    array(
        'title' => __('Pagination: posts per page', APS_PB_LANG) ,
        'desc'  => __('Valid only when you are using pagination', APS_PB_LANG) ,
        'id'    => 'posts_per_page',
        'type'  => 'input',
        'required' => array('use_gallery_of_post', 'no'),
        'value' => 10
    ),
    /*array(
        'title' => __('Pagination: page number', APS_PB_LANG) ,
        'desc'  => __('When pagination is active you can select here de default page to display. By default = 1', APS_PB_LANG) ,
        'id'    => 'page_number',
        'type'  => 'input',
        'required' => array('use_gallery_of_post', 'no'),
        'value' => 1
    ),*/

    //Order
    array(
        'title' => __('ORDER', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'kk',
        'type'  => 'title',
        //'value' => '',
    ),
    array(
        'title'	=> __('Order posts By', APS_PB_LANG) ,
        //'class' => 'aps-title-grande',
        'desc' 	=> __('', APS_PB_LANG) ,
        'id' 	=> 'orderby',
        'type' 	=> 'select',
        'value' => 'date',
        'options' => array(
            'none'          => 'None',
            'title'         => __('Title', APS_PB_LANG) ,
            'author'        => 'Author',
            'date'          => 'Date',
            'comment_count' => 'Popularity',
            'rand'          => 'Random'
        )
    ),
    //Order
    array(
        'title'	=> __('Order of posts', APS_PB_LANG) ,
        'desc' 	=> __('', APS_PB_LANG) ,
        'id' 	=> 'order',
        'type' 	=> 'select',
        'value' => 'ASC',
        'options' => array(
            'ASC' => 'Ascending',
            'DESC' => __('Descending', APS_PB_LANG)
        )
    ),

    //DISPLAY
    array(
        'title' => __('DISPLAY OPTIONS', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'kk',
        'type'  => 'title',
        //'value' => '',
    ),
    array(
        'title' => __('Display border', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'with_border',
        'type'  => 'yes_no',
        'value' => 'yes',
        'required' => array('type', 'masonry_image,masonry_image_and_text,grid_image,grid_image_and_text,list_image_and_text,list_image_and_text_alternate,justified_grid_image,fullwidth_image'),
    ),
    array(
        'title' => __('Hover: display link to post', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'display_link_post',
        'type'  => 'yes_no',
        'value' => 'yes',
        'required' => array('type', 'masonry_image,masonry_image_and_text,grid_image,grid_image_and_text,list_image_and_text,list_image_and_text_alternate,justified_grid_image,fullwidth_image'),
    ),
    array(
        'title' => __('Hover: display link to lightbox', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'display_link_lightbox',
        'type'  => 'yes_no',
        'value' => 'yes',
        'required' => array('type', 'masonry_image,masonry_image_and_text,grid_image,grid_image_and_text,list_image_and_text,list_image_and_text_alternate,justified_grid_image,fullwidth_image'),
    ),

    array(
        'title' => __('Hover: display link to external page', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'display_link_external',
        'type'  => 'yes_no',
        'value' => 'yes',
        'required' => array('type', 'masonry_image,masonry_image_and_text,grid_image,grid_image_and_text,list_image_and_text,list_image_and_text_alternate,justified_grid_image,fullwidth_image'),
    ),
    array(
        'title' => __('Hover: display content text', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'display_curtain_text',
        'type'  => 'yes_no',
        'value' => 'yes',
        'required' => array('type', 'masonry_image,masonry_image_and_text,grid_image,grid_image_and_text,list_image_and_text,list_image_and_text_alternate,justified_grid_image,fullwidth_image'),
    ),
);



$fields = array(
    array(
        'box_id'	=> 'page_extra_content',
        'title' => __('Add List / Gallery content', APS_PB_LANG) ,
        'desc'  => __('In case of LIST it will be used the Featured Image of each post.<br>In case of GALLERY it will be used the gallery images of each post (only with the posts that have a gallery) ',APS_PB_LANG),
        //'desc'		=> __('You can define extra content for the page here.<br>Use it for list of posts or projects in different styles.<br>Masonry, Grid, Justified grid, List, Slider',APS_PB_LANG),
        'id'    => 'add_extra_content',
        'type'  => 'yes_no',
        'value' => 'no',
    ),
    array(
        'box_id'	=> 'page_extra_content',
        'title' => __('', APS_PB_LANG) ,
        'desc'  => __('', APS_PB_LANG) ,
        'id'    => 'subfields',
        'type'  => 'subfields',
        'subfields' => $subfields,
        'required' => array('add_extra_content','yes')
    ),


    array(
        'box_id'	=> 'page_extra_content_below',
        'title' => __('', APS_PB_LANG) ,
        'desc'  => __('IMPORTANT: YOU HAVE TO SET THIS PAGE AS THE -STATIC PAGE FOR POSTS- in Settings->Reading.<br>The page will display: page content + BLOG + below content.<br>ex: you can display a slider for some featured posts firest, then the Blog, and then use shortcodes to display posts from other categories.', APS_PB_LANG) ,
        'id'    => 'subfields_2',
        'type'  => 'subfields',
        'subfields' => array(
                array(
                    'title'     => __('', APS_PB_LANG),
                    'desc'      => __('', APS_PB_LANG),
                    'id'        => 'content_below',
                    'type'      => 'tiny_mce',
                    'value'     => ''
                )
        ),
    )

    //CONTENT STRIP

    //Pruebas en content strips
    /*array(
        'box_id'	=> 'page_content_strips',
        'title' => __('Content strip', APS_PB_LANG) ,
        'desc' => __('', APS_PB_LANG) ,
        'id'    => 'strip',
        'type'  => 'multiple_rows',
        'value' => '',
        'subfields' => array(
            array(
                'title' => '',
                'desc' => '',
                'id' => 'strip_title',
                'type' => 'input',
                'value' => 'por defecto'
            ),
            array(
                'title' => '',
                'desc' => '',
                'id' => 'strip_shortcode',
                'type' => 'input',
                'value' => 'por defecto shortcode'
            ),
            array(
                'title' => '',
                'desc' => '',
                'id' => 'strip_content',
                'type' => 'textarea',
                'value' => 'por defecto textarea'
            )
        )
    ),

    array(
        'box_id'	=> 'page_content_strips',
        'title' => __('Content strip', APS_PB_LANG) ,
        'desc' => __('', APS_PB_LANG) ,
        'id'    => 'strip',
        'type'  => 'strip',
        'value' => '',
    )
    */

);