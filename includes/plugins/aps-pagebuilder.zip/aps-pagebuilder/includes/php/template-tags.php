<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }


function echo_pb_template_media($more_position = 'top-right', $image='3')
{
	echo '
	<div class="post_image">
		<a href="http://elap.es"><img src="'.$image.'.png"></a>
		<div class="post_more '.$more_position.'">+</div>
	</div>';
}

function echo_pb_template_date()
{
	?>
	<div class="post_date">
		<div class="date_holder">
			<span class="date">04</span> 
			<span class="month">October</span>
			<span class="year">2013</span>
		</div>
	</div>
	<?php
}

function echo_pb_template_meta()
{
	//Autor
	
	
	
	?>
	<div class="post_meta">
		<div class="meta_holder">
			<a class="post_author" href="#">admin</a>&nbsp;&nbsp;|&nbsp;&nbsp;
			<a class="post_cat" href="#">Design</a>&nbsp;&nbsp;|&nbsp;&nbsp;
			<a class="post_cat" href="#">Technology</a>&nbsp;&nbsp;|&nbsp;&nbsp;
			<a class="post_comments" href="#">3 Comments</a>
		</div>
	</div>
	<?php
}


function echo_pb_template_title()
{
	$tit = esc_attr(sprintf(__('Permalink to: &#39;%s&#39;',APS_PB_LANG), the_title_attribute('echo=0')));
	?>
	<div class="post_title">
	<?php the_title( '<h3><a href="' . esc_url( get_permalink() ) . '" rel="bookmark" title="'.$tit.'">', '</a></h3>' ); ?>
	</div>
	<?php
}


function echo_pb_template_content()
{
	?>
	<div class="post_content">
	<?php the_excerpt(); ?>
		<!--p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vitae dui et nunc ornare vulputate non fringilla massa. Praesent sit amet erat sapien, auctor consectetur ligula. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non ligula augue. Praesent imperdiet magna at risus lobortis ac accumsan lorem ornare. In aliquam, sapien ac vehicula vestibulum, arcu magna aliquet velit,...</p-->
	</div>
	<?php
}


function echo_pb_template_social()
{
	?>
	<div class="post_social">
		<span class="social_share_holder">
			<a href="#"><i class="fa fa-facebook"></i></a>
			<a href="#"><i class="fa fa-twitter"></i></a>
			<a href="#"><i class="fa fa-pinterest"></i></a>
			<a href="#"><i class="fa fa-envelope"></i></a>
		</span>
	</div>
	<?php
}

