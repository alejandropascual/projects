<?php
/*
Plugin Name: ELAP - Shortcodes Builder
Plugin URL: http://elapsl.com
Description: Page-shortcodes Builder for PROJECTS theme.
Version: 1.0.0
Author: ELAP
Author URI: http://elapsl.com
*/


// =============================================================================
//	Constants
// =============================================================================

define( 'APS_PAGEBUILDER_URL', plugins_url( '', __FILE__ ) );

if ( !defined( 'APS_PAGEBUILDER_DIR' ) ) {
    define( 'APS_PAGEBUILDER_DIR', plugin_dir_path(__FILE__) );
}

if ( !defined( 'APS_PAGEBUILDER_DIR_URI' ) ) {
    define( 'APS_PAGEBUILDER_DIR_URI', plugin_dir_url(__FILE__) );
}


// =============================================================================
//	Locale
// =============================================================================

define( 'APS_PB_LANG' , 'aps_pagebuilder');

function aps_pagebuilder_load_lang() {
    load_plugin_textdomain('aps_pagebuilder', false, basename(dirname(__FILE__)) . '/languages/' );
}

add_action('plugins_loaded', 'aps_pagebuilder_load_lang');



// =============================================================================
//	Clean up shortcodes
// =============================================================================

//
// Remove empty <p> and <br> tags from shortcodes.
//
if ( ! function_exists( 'aps_clean_shortcodes' ) ) :
  function aps_clean_shortcodes( $content ) {

    $array = array (
      '<p>['    => '[',
      ']</p>'   => ']',
      ']<br />' => ']'
    );

    $content = strtr( $content, $array );
	//echo '<pre>'; print_r(esc_attr($content)); echo '</pre>';
    return $content;

  }
  add_filter( 'the_content', 'aps_clean_shortcodes' );
endif;



//remove_filter( 'the_content', 'wpautop' );
//remove_filter( 'the_excerpt', 'wpautop' );

//http://stackoverflow.com/questions/15795142/is-there-anyway-to-stop-ckeditor-4-from-filtering-my-anchor-tag-attributes
//http://css-tricks.com/snippets/wordpress/remove-paragraph-tags-from-around-images/
/*
function filter_ptags_on_images($content){
   return preg_replace('/<p>\s*(<a .*>)?\s*(<img .* \/>)\s*(<\/a>)?\s*<\/p>/iU', '\1\2\3', $content);
}

add_filter('the_content', 'filter_ptags_on_images');
*/


//http://wordpress.stackexchange.com/questions/96725/html5-wordpress-and-tiny-mce-issue-wrapping-anchor-tag-around-div-results-in
/*add_filter('tiny_mce_before_init', 'modify_valid_children');
function modify_valid_children($settings){
    $settings['valid_children']="+a[div|p|ul|ol|li|h1|h2|h3|h4|h5|h5|h6]";
    return $settings;
}
*/


// =============================================================================
//	Require files
// =============================================================================


require_once( 'includes/php/class-pagebuilder.php' );
require_once( 'includes/php/class-shortcode.php' );
require_once( 'includes/php/class-htmlbuilder.php' );
require_once( 'includes/php/class-tinymce.php' );
require_once( 'includes/php/ajax.php' );
require_once( 'includes/php/template-tags.php' );
require_once( 'includes/php/shortcode-utils.php' );

global $aps_config;
$aps_config['pagebuilder'] = new APSPageBuilder();





function aps_cargar_page_metabox()
{
    // Metaboxes para pages, facilita el shortcode gallery_template
    if (class_exists('APSMetaBox') && class_exists('APSHtmlHelper')) {
        new APSMetaBox(APS_PAGEBUILDER_DIR . '/includes/php/page-metabox-data.php');
    }
}

add_action('admin_init', 'aps_cargar_page_metabox' );






// =============================================================================
//	Enqueue Frontend
// =============================================================================


function aps_builder_shortcodes_enqueue_scripts() {

    wp_register_script( 'aps-bootstrap', APS_PAGEBUILDER_URL.'/includes/vendors/bootstrap/bootstrap.js', array('jquery'), NULL, true );
    wp_enqueue_script( 'aps-bootstrap');

    // Lo tengo que echar siempre porque en caso de load more puede aparecer un video o audio nuevo
    wp_register_script( 'aps-jplayer', APS_PAGEBUILDER_URL.'/includes/vendors/jplayer/jquery.jplayer.min.js', array('jquery'), NULL, true );
    wp_enqueue_script( 'aps-jplayer');

    //Para el bigvideo
    //imagesloaded lo carga ya el theme tambien
    wp_register_script( 'vendor-imagesloaded', APS_PAGEBUILDER_URL . '/includes/vendors/bigvideo/imagesloaded.js', array( 'jquery' ),NULL,true);
    wp_register_script( 'vendor-video', APS_PAGEBUILDER_URL . '/includes/vendors/bigvideo/video.js', array( 'jquery' ),NULL,true);
    wp_register_script( 'vendor-bigvideo', APS_PAGEBUILDER_URL . '/includes/vendors/bigvideo/bigvideo.js', array( 'jquery','jquery-ui-core','vendor-imagesloaded','vendor-video' ),NULL,true);
	
	//Enqueue el mio
	wp_enqueue_script( 'aps-shortcodes', APS_PAGEBUILDER_URL.'/includes/js/shortcodes.js', array('jquery'), NULL, true );

}

add_action( 'wp_enqueue_scripts', 'aps_builder_shortcodes_enqueue_scripts' );


// =============================================================================
//	Enqueue Frontend Styles
// =============================================================================

function aps_builder_shortcodes_enqueue_styles()
{
	wp_register_style( 'aps-shortcodes',  APS_PAGEBUILDER_URL . '/includes/styles/css/aps-shortcodes.css', NULL, '1.0.0', 'all' );
	wp_enqueue_style( 'aps-shortcodes' );
}


add_action( 'wp_enqueue_scripts', 'aps_builder_shortcodes_enqueue_styles' );


// =============================================================================
//	Enqueue BACKEND STYLES
// =============================================================================

function aps_builder_admin_scripts_styles()
{
    wp_register_script('chosen', APS_PAGEBUILDER_URL.'/includes/vendors/chosen/chosen.jquery.js', array('jquery'));
    wp_enqueue_script('chosen');

    wp_register_style('chosen', APS_PAGEBUILDER_URL.'/includes/vendors/chosen/chosen.css');
    wp_enqueue_style( 'chosen' );

    //wp_register_style( 'aps-font-awesome', 'http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css');
    //wp_enqueue_style( 'aps-font-awesome' );

    wp_register_style('aps-font-awesome', APS_PAGEBUILDER_URL.'/includes/styles/css/font-awesome.min.css');
    wp_enqueue_style( 'aps-font-awesome' );
}

add_action( 'admin_enqueue_scripts', 'aps_builder_admin_scripts_styles');