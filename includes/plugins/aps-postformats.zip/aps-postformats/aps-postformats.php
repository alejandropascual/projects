<?php
/*
Plugin Name: ELAP - Post Formats
Plugin URL: http://elapsl.com
Description: Post Formats for PROJECTS Theme.
Version: 1.0.0
Author: ELAP
Author URI: http://elapsl.com
*/


// CONSTANTS

if ( !defined( 'APS_POSTFORMATS_URL' ) ) {
    define( 'APS_POSTFORMATS_URL', plugins_url( '', __FILE__ ) );
}

if ( !defined( 'APS_POSTFORMATS_DIR' ) ) {
	define( 'APS_POSTFORMATS_DIR', plugin_dir_path(__FILE__) );
}

if ( !defined( 'APS_POSTFORMATS_DIR_URI' ) ) {
	define( 'APS_POSTFORMATS_DIR_URI', plugin_dir_url(__FILE__) );
}



// =============================================================================
//	Locale
// =============================================================================

define( 'APS_PF_LANG' , 'aps_postformats');

function aps_postformats_load_lang() {
    load_plugin_textdomain('aps_postformats', false, basename(dirname(__FILE__)) . '/languages/' );
}

add_action('plugins_loaded', 'aps_postformats_load_lang');



// FORMATS
add_action( 'after_setup_theme', 'aps_childtheme_formats', 11 );
function aps_childtheme_formats(){
     add_theme_support( 'post-formats', array( 'image', 'gallery', 'video', 'audio', 'link', 'quote' ) );
}



// METABOXES
require(APS_POSTFORMATS_DIR.'/includes/php/ajax.php');
//require(APS_POSTFORMATS_DIR.'/includes/php/class-htmlhelper.php'); //Repetida del tema
require(APS_POSTFORMATS_DIR.'/includes/php/class-metabox.php');
new APSMetaBox(APS_POSTFORMATS_DIR.'/includes/php/config-metabox.php');


// MEDIA utils (categories and custom columns)
require(APS_POSTFORMATS_DIR.'/includes/php/media-utils.php');


// POSTS CUSTOM COLUMNS
require(APS_POSTFORMATS_DIR.'/includes/php/posts-custom-columns.php');


// SCRIPTS BACKEND
if ( ! function_exists( 'aps_postformats_scripts_backend' ) ) :
  function aps_postformats_scripts_backend()
  {
        $css = APS_POSTFORMATS_DIR_URI . 'includes/css/';
        $js = APS_POSTFORMATS_DIR_URI . 'includes/js/';

        $screen = get_current_screen();

        if ($screen->post_type=='post')
        {
            //Style
            wp_register_style( 'aps-back-postformats', $css.'aps-back-postformats.css' );
            wp_enqueue_style( 'aps-back-postformats');

            //Media library
            wp_enqueue_media();
            wp_enqueue_script('custom-header');

            //Mios
            wp_enqueue_script( 'aps-back-postformats', $js.'aps-back-postformats.js', array('jquery','custom-header'));
            wp_localize_script('aps-back-postformats', 'locals', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
        }
    
}
endif;
add_action( 'admin_enqueue_scripts', 'aps_postformats_scripts_backend' );


