///////////////////////////////////////////
// ABRIR / OCULTAR METABOXES SEGUN POST FORMAT
///////////////////////////////////////////


jQuery(document).ready(function($){

    "use strict";

	$('#post-formats-select').on('change',function(e){
		
		var value = $('#post-formats-select input[type="radio"]:checked').val();
		//console.log('Select post format changed to : '+value);
		
		$('#box_audio_post_format').hide();
		$('#box_gallery_post_format').hide();
		$('#box_image_post_format').hide();
		$('#box_link_post_format').hide();
		$('#box_quote_post_format').hide();
		$('#box_video_post_format').hide();
		
		$('#box_'+value+'_post_format').show();
	});
	
	$('#post-formats-select').trigger('change');
	
	
});




// ES UNA COPIA PARCIAL DEL backend-all.js usado en theme ap-foto
// he quitado algunos metodos que no me hacen falta

///////////////////////////////////////////
// PANEL DE OPCIONES
///////////////////////////////////////////

// Panel de opciones. Opciones se abren / cierran en funcion de algun select


(function($){

    "use strict";

    var panel_opciones = {

        //Opciones abren / cierran en funcion de select
        bind_change_select: function(){
            $('.aps-section-field select').live('change',function(){
                var id = $(this).attr('id');
                var val = $(this).val();
                panel_opciones.comprobar_required(id,val);
            });
        },

        bind_change_tab: function(){
            $('.aps-section-field input[type="radio"]').live('change',function(){
                var id = $(this).data('id');
                var val = $(this).val();
                panel_opciones.comprobar_required(id,val);

                //Trigger selet para que oculte dependencias
                //pero solo de los que estan dentro del tab
                //que son los que estan visibles
                var required_tab = id+'::'+val;
                $('.aps-section-field select').each(function(){
                    var $required = $(this).closest('.aps-section-field').find('.required-tab');
                    if ($required && $required.val()==required_tab)
                    {
                        $(this).trigger('change');
                    }

                });
            });
        },


        comprobar_required: function(id, val)
        {

            $('.aps-field-required').each(function(index,el)
            {
                var el_required = $(el).val();
                var res = el_required.split("::");

                //Coincide la id y por tanto
                //esta condicionado
                if (res[0] == id)
                {
                    //Mi campo
                    var $parent = $(el).closest('.aps-section-field');

                    //La fila de la table en options
                    var $row = $parent.closest('tr');

                    //Para metaboxes es otros
                    if ($row.length == 0)
                        $row = $parent;

                    //Por si uso titulos que no tienen nada les asigni espacios
                    if (res[1] === '{true}' && val!== '' && val!== ' ' && val!== '  ' && val!== '   '){
                        $row.show();
                    }
                    else
                    {
                        var valores = res[1].split(",");
                        var coincide = false;
                        $.each(valores,function(index,item){
                            if (item == val)
                                coincide = true;
                        });

                        if (coincide==true){
                            $row.show();
                        }
                        else{
                            $row.hide();
                        }
                    }
                }
            });

        },


        bind_radio_image: function(){
            $('.input-radio-image').live('change', function(event){
                //console.log(this);
                $(this).closest('.aps-section-field')
                    .find('.aps-radio-image')
                    .removeClass('aps-radio-selected');
                $(this).closest('.aps-radio-image')
                    .addClass('aps-radio-selected');
            });
        },

        bind_option_tab: function(){
            $('.aps-option-tab').live('click', function(event){
                //console.log(this);
                $(this).closest('.aps-section-field')
                    .find('label').removeClass('selected');
                $(this).closest('.aps-option-tab').addClass('selected');
            });
        }



    };

    $(function(){
        panel_opciones.bind_change_select();
        //console.log('TRIGGERING SELECT');
        $('.aps-section-field select').trigger('change');

        panel_opciones.bind_radio_image();
        panel_opciones.bind_option_tab();
        panel_opciones.bind_change_tab();
        //console.log('TRIGGERING TABS');
        $('.aps-section-field input[type="radio"]:checked').trigger('change');

    });


})(jQuery);







// ES UNA COPIA PARCIAL DEL backend-all.js usado en theme ap-foto */



///////////////////////////////////////////
// GALLERY IN METABOXES
///////////////////////////////////////////


(function($){

    $(window).load(function(){

        wp.media.EditApsGallery = {

            frame: function() {
                if ( this._frame )
                    return this._frame;

                var selection = this.select();

                this._frame = wp.media({
                    displaySettings:    false,
                    id:                 'editapsgallery-frame',
                    title:              'apsgallery',
                    filterable:         'uploaded',
                    frame:              'post',
                    state:              'gallery-edit',
                    library:            { type : 'image' },
                    multiple:           true,
                    editing:            true,
                    selection:          selection
                });

                this._frame.on( 'update',
                    function() {
                        var controller = wp.media.EditApsGallery._frame.states.get('gallery-edit');
                        var library = controller.get('library');

                        var ids = library.pluck('id');

                        //console.log(ids);

                        $('#gallery_images').val( ids.join(',') );

                        // update the galllery_preview
                        aps_gallery_ajax_preview();

                        return false;
                    });

                return this._frame;
            },

            init: function() {

                $('.aps-upload-gallery').click( function(e){
                    //console.log(this);
                    e.preventDefault();
                    wp.media.EditApsGallery.frame().open();
                });
            },

            select: function(){
                var gallery_ids = $('#gallery_images').val(),
                    shortcode = wp.shortcode.next('gallery', '[gallery ids="'+gallery_ids+'"]'),
                    defaultPostId = wp.media.gallery.defaults.id,
                    attachments, selection;

                if (!shortcode)
                    return;

                // Ignore the rest of the match object.
                shortcode = shortcode.shortcode;
                //console.log(shortcode);

                if ( _.isUndefined( shortcode.get('id') ) && ! _.isUndefined( defaultPostId ) )
                    shortcode.set( 'id', defaultPostId );

                attachments = wp.media.gallery.attachments( shortcode );
                selection = new wp.media.model.Selection( attachments.models, {
                    props:    attachments.props.toJSON(),
                    multiple: true
                });

                selection.gallery = attachments.gallery;

                // Fetch the query's attachments, and then break ties from the
                // query to allow for sorting.
                selection.more().done( function() {
                    // Break ties with the query.
                    selection.props.set({ query: false });
                    selection.unmirror();
                    selection.props.unset('orderby');
                });

                //console.log(selection);
                return selection;

            }

        }

        aps_gallery_ajax_preview();
        $( wp.media.EditApsGallery.init );

    });


    var aps_gallery_ajax_preview = function() {

        $gallery = $('#gallery_images');
        if( $gallery.length==0 ) return;

        var ids = '';
        ids = $gallery.val();

        $.ajax({
            type: 'post',
            url: locals.ajax_url,
            data: {
                action: 'aps_gallery_preview',
                attachments_ids: ids
            },
            beforeSend: function() {

            },
            complete: function() {

            },
            success: function( response ) {
                var result = JSON.parse(response);
                if (result.success){
                    $('#aps-upload-gallery')
                        .parent().find('ul').html(result.output);
                }
            }
        });

    };


})(jQuery);


