<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

global $aps_config;

$boxes = array(
	array(
		'id' 		=> 'box_gallery_post_format',
		'title' 	=> __('Gallery - Post Format',APS_PF_LANG),
		'page' 		=> array('post'),
		'context' 	=> 'normal',
		'priority'	=> 'high'
	),
	array(
		'id' 		=> 'box_link_post_format',
		'title' 	=> __('Link - Post Format',APS_PF_LANG),
		'page' 		=> array('post'),
		'context' 	=> 'normal',
		'priority'	=> 'high'
	),
	array(
		'id' 		=> 'box_quote_post_format',
		'title' 	=> __('Quote - Post Format',APS_PF_LANG),
		'page' 		=> array('post'),
		'context' 	=> 'normal',
		'priority'	=> 'high'
	),
	array(
		'id' 		=> 'box_video_post_format',
		'title' 	=> __('Video - Post Format',APS_PF_LANG),
		'page' 		=> array('post'),
		'context' 	=> 'normal',
		'priority'	=> 'high'
	),
	array(
		'id' 		=> 'box_audio_post_format',
		'title' 	=> __('Audio - Post Format',APS_PF_LANG),
		'page' 		=> array('post'),
		'context' 	=> 'normal',
		'priority'	=> 'high'
	),
    array(
        'id' 		=> 'box_layout',
        'title' 	=> __('POST LAYOUT',APS_PF_LANG),
        'page' 		=> array('post'),
        'context' 	=> 'normal',
        'priority'	=> 'high'
    ),
);

$fields = array(
	
	//GALLERY
	array(
		'box_id'=> 'box_gallery_post_format',
		'title'	=>	__('Use images',APS_PF_LANG),
		'desc'	=>	__('Select the source of your images to show the gallery', APS_PF_LANG),
		'id'	=>	'gallery_images_src',
		'type'	=>	'select',
		'options' => array(
			'images_attach' => 'Images attached to this post',
			'images_select' => 'Images selected'
					),
		'class'	=> 	'',
		'value' =>  ''
	),
	array(
		'box_id'=> 'box_gallery_post_format',
		'title'	=>	__('Gallery images',APS_PF_LANG),
		'desc'	=>	__('', APS_PF_LANG),
		'id'	=>	'gallery_images',
		'type'	=>	'gallery',
		'class'	=> 	'',
		'value' =>  '',
		'required'	=> array('gallery_images_src','images_select')
	),
	
	//LINK
    array(
        'box_id'=> 'box_link_post_format',
        'title'	=>	__('Open link in a new window',APS_PF_LANG),
        'desc'	=>	__('', APS_PF_LANG),
        'id'	=>	'pf_link_open',
        'type'	=>	'yes_no',
        'class'	=> 	'widefat no-border-bottom',
        'value' =>  'yes',
    ),
	array(
		'box_id'=> 'box_link_post_format',
		'title'	=>	__('The link',APS_PF_LANG),
		'desc'	=>	__('Insert your link here, e.g. http://themeforest.net.<br>In case you have a featured image it will also be used for the link', APS_PF_LANG),
		'id'	=>	'pf_link',
		'type'	=>	'input',
		'class'	=> 	'widefat no-border-bottom',
		'value' =>  ''
	),
	array(
		'box_id'=> 'box_link_post_format',
		'title'	=>	__('Link text',APS_PF_LANG),
		'desc'	=>	__('Insert the text for the link here. Leave it blank to use the same as the link.', APS_PF_LANG),
		'id'	=>	'pf_link_text',
		'type'	=>	'input',
		'class'	=> 	'widefat no-border-bottom',
		'value' =>  ''
	),

    array(
        'box_id'=> 'box_link_post_format',
        'title'	=>	__('Background',APS_PF_LANG),
        'desc'	=>	__('', APS_PF_LANG),
        'id'	=>	'pf_link_background',
        'type'	=>	'select',
        'class'	=> 	'no-border-bottom',
        'value' =>  'none',
        'options' => array(
            'none'       => 'None',
            'featured'   => 'Featured image',
            'pattern'    => 'Icon pattern',
            'backcolor'  => 'Background color'
        ),
    ),
    array(
        'box_id'=> 'box_link_post_format',
        'title'	=>	__('Background color',APS_PF_LANG),
        'desc'	=>	__('', APS_PF_LANG),
        'id'	=>	'pf_link_back_color',
        'type'	=>	'color',
        'class'	=> 	'no-border-bottom',
        'required' => array('pf_link_background','backcolor')
    ),
    array(
        'box_id'=> 'box_link_post_format',
        'title'	=>	__('Override default text color',APS_PF_LANG),
        'desc'	=>	__('', APS_PF_LANG),
        'id'	=>	'pf_link_override_color',
        'type'	=>	'yes_no',
        'class'	=> 	'no-border-bottom',
    ),
    array(
        'box_id'=> 'box_link_post_format',
        'title'	=>	__('Text color',APS_PF_LANG),
        'desc'	=>	__('', APS_PF_LANG),
        'id'	=>	'pf_link_color',
        'type'	=>	'color',
        'class'	=> 	'no-border-bottom',
        'required' => array('pf_link_override_color','yes')
    ),

	//QUOTE
	array(
		'box_id'=> 'box_quote_post_format',
		'title'	=>	__('The Quote',APS_PF_LANG),
		'desc'	=>	__('Insert your quote here', APS_PF_LANG),
		'id'	=>	'pf_quote',
		'type'	=>	'textarea',
		'class'	=> 	'widefat no-border-bottom',
		'value' =>  ''
	),
	array(
		'box_id'=> 'box_quote_post_format',
		'title'	=>	__('Citation',APS_PF_LANG),
		'desc'	=>	__('The author of the quote ?', APS_PF_LANG),
		'id'	=>	'pf_quote_cite',
		'type'	=>	'input',
		'class'	=> 	'widefat no-border-bottom',
		'value' =>  ''
	),
	array(
		'box_id'=> 'box_quote_post_format',
		'title'	=>	__('Text align',APS_PF_LANG),
		'desc'	=>	__('', APS_PF_LANG),
		'id'	=>	'pf_quote_align',
		'type'	=>	'select',
		'class'	=> 	'no-border-bottom',
		'value' =>  '',
		'options'	=>  array(
							'left'=> 'Left',
							'center'	=> 'Center',
							'right' => 'Right'
						),
	),
    array(
        'box_id'=> 'box_quote_post_format',
        'title'	=>	__('Background',APS_PF_LANG),
        'desc'	=>	__('', APS_PF_LANG),
        'id'	=>	'pf_quote_background',
        'type'	=>	'select',
        'class'	=> 	'no-border-bottom',
        'value' =>  'none',
        'options' => array(
            'none'       => 'None',
            'featured'   => 'Featured image',
            'pattern'    => 'Icon pattern',
            'backcolor'  => 'Background color'
        ),
    ),
    array(
        'box_id'=> 'box_quote_post_format',
        'title'	=>	__('Background color',APS_PF_LANG),
        'desc'	=>	__('', APS_PF_LANG),
        'id'	=>	'pf_quote_back_color',
        'type'	=>	'color',
        'class'	=> 	'no-border-bottom',
        'required' => array('pf_quote_background','backcolor')
    ),
    array(
        'box_id'=> 'box_quote_post_format',
        'title'	=>	__('Override default text color',APS_PF_LANG),
        'desc'	=>	__('', APS_PF_LANG),
        'id'	=>	'pf_quote_override_color',
        'type'	=>	'yes_no',
        'class'	=> 	'no-border-bottom',
    ),
    array(
        'box_id'=> 'box_quote_post_format',
        'title'	=>	__('Text color',APS_PF_LANG),
        'desc'	=>	__('', APS_PF_LANG),
        'id'	=>	'pf_quote_color',
        'type'	=>	'color',
        'class'	=> 	'no-border-bottom',
        'required' => array('pf_quote_override_color','yes')
    ),
	
	//VIDEO
	array(
		'box_id'	=> 'box_video_post_format',
		'title'		=> __('Self Hosted Video / Embed Video',APS_PF_LANG),
        'desc'		=> __('For hosted video featured image of the post will be used', APS_PF_LANG),
		'id'		=> 'pf_video_hosted',
		'type' 		=> 'select',
		'class'		=> 'no-border-bottom',
		'value'		=> 'yes',
		'options'	=>  array(
							'yes'=> 'Self Hosted',
							'no'	=> 'Embed'
						)
	),
	array(
		'box_id'	=> 'box_video_post_format',
		'title'		=> __('Aspect Ratio',APS_PF_LANG),
		'desc'		=> __('Select the aspect ratio of your video', APS_PF_LANG),
		'id'		=> 'pf_video_ratio',
		'type' 		=> 'select',
		'class'		=> 'no-border-bottom',
		'value'		=> '16_9',
		'options'	=>  array(
						'video-16_9' => '16 : 9',
						'video-5_3' => '5 : 3',
						'video-5_4' => '5 : 4',
						'video-4_3' => '4 : 3',
						'video-3_2' => '3 : 2'
						)
	),
	/*array(
		'box_id'	=> 'box_video_post_format',
		'title'		=> __('Border frame',APS_PF_LANG),
		'desc'		=> __('', APS_PF_LANG),
		'id'		=> 'pf_video_frame',
		'type' 		=> 'select',
		'class'		=> '',
		'value'		=> 'yes',
		'options'	=>  array(
							'true'=> 'yes',
							'false'	=> 'no'
						)
	),*/
	array(
		'box_id'	=> 'box_video_post_format',
		'title'		=> __('Skin color',APS_PF_LANG),
		'desc'		=> __('', APS_PF_LANG),
		'id'		=> 'pf_video_skin',
		'type' 		=> 'select',
		'class'		=> 'no-border-bottom',
		'value'		=> 'black',
		'options'	=>  array(
							'black'=> 'Black',
							'gray'	=> 'Gray',
							'white' => 'White'
						),
		'required'	=> array('pf_video_hosted','yes')
	),
	array(
		'box_id'	=> 'box_video_post_format',
		'title'		=> __('Autoplay',APS_PF_LANG),
		'desc'		=> __('', APS_PF_LANG),
		'id'		=> 'pf_video_autoplay',
		'type' 		=> 'select',
		'class'		=> 'no-border-bottom',
		'value'		=> 'no',
		'options'	=>  array(
							'yes'=> 'yes',
							'no'	=> 'no'
						),
		'required'	=> array('pf_video_hosted','yes')
	),
	array(
		'box_id'=> 'box_video_post_format',
		'title'	=>	__('URL M4V File',APS_PF_LANG),
		'desc'	=>	__('The URL to the .m4v file', APS_PF_LANG),
		'id'	=>	'pf_video_m4v',
		'type'	=>	'input',
		'class'	=> 	'widefat',
		'value' =>  '',
		'required'	=> array('pf_video_hosted','yes')
	),
	array(
		'box_id'=> 'box_video_post_format',
		'title'	=>	__('URL OGV File',APS_PF_LANG),
		'desc'	=>	__('The URL to the .ogv file', APS_PF_LANG),
		'id'	=>	'pf_video_ogv',
		'type'	=>	'input',
		'class'	=> 	'widefat no-border-bottom',
		'value' =>  '',
		'required'	=> array('pf_video_hosted','yes')
	),
	array(
		'box_id'=> 'box_video_post_format',
		'title'	=>	__('URL WEBM File',APS_PF_LANG),
		'desc'	=>	__('The URL to the .webm file', APS_PF_LANG),
		'id'	=>	'pf_video_webm',
		'type'	=>	'input',
		'class'	=> 	'widefat no-border-bottom',
		'value' =>  '',
		'required'	=> array('pf_video_hosted','yes')
	),
	array(
		'box_id'=> 'box_video_post_format',
		'title'	=>	__('Embedded Video Code',APS_PF_LANG),
		'desc'	=>	__('Paste the embed code here for other video from YouTube, Vimeo, Wistia, etc.', APS_PF_LANG),
		'id'	=>	'pf_video_embed',
		'type'	=>	'textarea',
		'class'	=> 	'widefat no-border-bottom',
		'value' =>  '',
		'required'	=> array('pf_video_hosted','no')
	),
	
	//AUDIO
		array(
		'box_id'	=> 'box_audio_post_format',
		'title'		=> __('Self Hosted Audio / Embed Audio',APS_PF_LANG),
		'desc'		=> __('For hosted audio featured image of the post will be used', APS_PF_LANG),
		'id'		=> 'pf_audio_hosted',
		'type' 		=> 'select',
		'class'		=> 'no-border-bottom',
		'value'		=> 'yes',
		'options'	=>  array(
							'yes'=> 'Self Hosted',
							'no'	=> 'Embed'
						)
	),
	/*array(
		'box_id'	=> 'box_audio_post_format',
		'title'		=> __('Border frame',APS_PF_LANG),
		'desc'		=> __('', APS_PF_LANG),
		'id'		=> 'pf_audio_frame',
		'type' 		=> 'select',
		'class'		=> '',
		'value'		=> 'yes',
		'options'	=>  array(
							'true'=> 'yes',
							'false'	=> 'no'
						)
	),*/
	array(
		'box_id'	=> 'box_audio_post_format',
		'title'		=> __('Skin color',APS_PF_LANG),
		'desc'		=> __('', APS_PF_LANG),
		'id'		=> 'pf_audio_skin',
		'type' 		=> 'select',
		'class'		=> 'no-border-bottom',
		'value'		=> 'black',
		'options'	=>  array(
							'black'=> 'Black',
							'gray'	=> 'Gray',
							'white' => 'White'
						),
		'required'	=> array('pf_audio_hosted','yes')
	),
	array(
		'box_id'	=> 'box_audio_post_format',
		'title'		=> __('Autoplay',APS_PF_LANG),
		'desc'		=> __('', APS_PF_LANG),
		'id'		=> 'pf_audio_autoplay',
		'type' 		=> 'select',
		'class'		=> 'no-border-bottom',
		'value'		=> 'no',
		'options'	=>  array(
							'yes'=> 'yes',
							'no'	=> 'no'
						),
		'required'	=> array('pf_audio_hosted','yes')
	),
	array(
		'box_id'=> 'box_audio_post_format',
		'title'	=>	__('URL MP3 File',APS_PF_LANG),
		'desc'	=>	__('The URL to the .mp3 file', APS_PF_LANG),
		'id'	=>	'pf_audio_mp3',
		'type'	=>	'input',
		'class'	=> 	'widefat no-border-bottom',
		'value' =>  '',
		'required'	=> array('pf_audio_hosted','yes')
	),
	array(
		'box_id'=> 'box_audio_post_format',
		'title'	=>	__('URL OGA File',APS_PF_LANG),
		'desc'	=>	__('The URL to the .ogg or .oga file', APS_PF_LANG),
		'id'	=>	'pf_audio_oga',
		'type'	=>	'input',
		'class'	=> 	'widefat no-border-bottom',
		'value' =>  '',
		'required'	=> array('pf_audio_hosted','yes')
	),
	array(
		'box_id'=> 'box_audio_post_format',
		'title'	=>	__('URL M4A File',APS_PF_LANG),
		'desc'	=>	__('The URL to the .m4a file', APS_PF_LANG),
		'id'	=>	'pf_audio_m4a',
		'type'	=>	'input',
		'class'	=> 	'widefat no-border-bottom',
		'value' =>  '',
		'required'	=> array('pf_audio_hosted','yes')
	),
	array(
		'box_id'=> 'box_audio_post_format',
		'title'	=>	__('Embedded Audio Code',APS_PF_LANG),
		'desc'	=>	__('Paste the embed code here for other audio from Soundcloud, etc.', APS_PF_LANG),
		'id'	=>	'pf_audio_embed',
		'type'	=>	'textarea',
		'class'	=> 	'widefat no-border-bottom',
		'value' =>  '',
		'required'	=> array('pf_audio_hosted','no')
	),

    //POST LAYOUT
    array(
        'box_id'=> 'box_layout',
        'title'	=>	__('Override default post layout ?',APS_PF_LANG),
        'desc'	=>	__('Default layout display the featured image above the title.<br>You can change the layout here.', APS_PF_LANG),
        'id'	=>	'post_layout_override',
        'type'	=>	'yes_no',
        'class'	=> 	'',
        'value' =>  'no',
    ),

    array(
        'box_id'=> 'box_layout',
        'title'	=>	__('Layout Type',APS_PF_LANG),
        'desc'	=>	__('', APS_PF_LANG),
        'id'	=>	'post_layout_type',
        'type'	=>	'radio_image',
        'class'	=> 	'max-90',
        'value' =>  '1',
        'options' => array(
            'lay_1' => 'Featured above title',
            'lay_2' => 'Featured below title',
            'lay_3' => 'No featured image',
            //'lay_4' => '4',
            //'lay_5' => '5',
        ),
        'images' => array(
            APS_POSTFORMATS_URL.'/includes/images/lay_1.png',
            APS_POSTFORMATS_URL.'/includes/images/lay_2.png',
            APS_POSTFORMATS_URL.'/includes/images/lay_3.png',
            //APS_POSTFORMATS_URL.'/includes/images/lay_4.png',
            //APS_POSTFORMATS_URL.'/includes/images/lay_5.png',
        ),
        'required'	=> array('post_layout_override','yes')
    ),

    array(
        'box_id'=> 'box_layout',
        'title'	=>	__('Use shortcode instead of featured image ?',APS_PF_LANG),
        'desc'	=>	__('This can be useful if for example you want to use an -Image with Markers- or a -Map- <br>instead of the Featured image at the top of the single post page, <br>but still showing the featured image in the blog page. :)', APS_PF_LANG),
        'id'	=>	'post_featured_as_shortcode',
        'type'	=>	'yes_no',
        'class'	=> 	'',
        'value' =>  'no',
    ),
    array(
        'box_id'=> 'box_layout',
        'title'	=>	__('Paste the shortcode here:',APS_PF_LANG),
        'desc'	=>	__('', APS_PF_LANG),
        'id'	=>	'post_featured_shortcode',
        'type'	=>	'textarea',
        'class'	=> 	'widefat',
        'value' =>  '',
        'required'	=> array('post_featured_as_shortcode','yes')
    ),
);