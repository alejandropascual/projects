<?php


// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }



// REGISTER CATEGORIES, TAGS LOCATIONS
//http://code.tutsplus.com/articles/applying-categories-tags-and-custom-taxonomies-to-media-attachments--wp-32319

function aps_add_taxonomies_to_attachments()
{
    register_taxonomy_for_object_type( 'category', 'attachment' );

    register_taxonomy_for_object_type( 'post_tag', 'attachment' );

    $labels = array(
        'name'              => 'Locations',
        'singular_name'     => 'Location',
        'search_items'      => 'Search Locations',
        'all_items'         => 'All Locations',
        'parent_item'       => 'Parent Location',
        'parent_item_colon' => 'Parent Location:',
        'edit_item'         => 'Edit Location',
        'update_item'       => 'Update Location',
        'add_new_item'      => 'Add New Location',
        'new_item_name'     => 'New Location Name',
        'menu_name'         => 'Location',
    );

    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
        'query_var' => 'true',
        'rewrite' => 'true',
        'show_admin_column' => 'true',
    );

    //register_taxonomy( 'location', 'attachment', $args );
}

add_action( 'init' , 'aps_add_taxonomies_to_attachments' );


//CUSTOM COLUMNS

add_filter('manage_media_columns', 'aps_media_columns_head');
add_filter('manage_media_custom_column', 'aps_media_columns_content', 10, 2);

function aps_media_columns_head( $columns )
{
    $prev_columns = array(
      'cb' => $columns['cb'],
      'ID' => 'ID'
    );
    unset($columns['cb']);
    return array_merge($prev_columns, $columns);
}

function aps_media_columns_content( $column, $post_id)
{
    if ($column == 'ID') {
        echo $post_id;
    }
}


// FILTER MEDIA LIST , pendiente

add_action('restrict_manage_posts', 'aps_media_filter_list');
//add_filter( 'parse_query','aps_media_filter_perform_query' ); //No hace falta


function aps_media_filter_list()
{
    $screen = get_current_screen();
    global $wp_query;
    //echo '<pre>'; print_r( $wp_query->query ); echo '</pre>';
    //if ( $screen->post_type == 'attachment' )
    if ( $wp_query->query['post_type'] == 'attachment' )
    {
        wp_dropdown_categories( array(
            'show_option_all' => 'Show All Categories',
            'taxonomy' => 'category',
            'name' => 'category__in',
            'orderby' => 'name',
            'selected' => ( isset( $wp_query->query['category__in'] ) ? $wp_query->query['category__in'] : '' ),
            'hierarchical' => true,
            'depth' => 3,
            'show_count' => false,
            'hide_empty' => true,
        ) );

        wp_dropdown_categories( array(
            'show_option_all' => 'Show All Tags',
            'taxonomy' => 'post_tag',
            'name' => 'tag__in',
            'orderby' => 'name',
            'selected' => ( isset( $wp_query->query['tag__in'] ) ? $wp_query->query['tag__in'] : '' ),
            'hierarchical' => false,
            'depth' => 3,
            'show_count' => false,
            'hide_empty' => true,
        ) );

    }
}

/*
function aps_media_filter_perform_query( $query )
{
    $qv = &$query->query_vars;
    //echo '<pre>'; print_r( $query ); echo '</pre>';


    if ( isset( $qv['category'] ) && is_numeric( $qv['category'] ) ) {
        $term = get_term_by( 'id', $qv['category'], 'category' );
        if ($term) { $qv['category'] = $term->slug; }
    }

    if ( isset( $qv['post_tag'] ) && is_numeric( $qv['post_tag'] ) ) {
        $term = get_term_by( 'id', $qv['post_tag'], 'post_tag' );
        if ($term) { $qv['post_tag'] = $term->slug; }
    }
}
*/

// STYLE
add_action('admin_head', 'aps_admin_media_custom_css');

function aps_admin_media_custom_css() {
    echo '<style type="text/css">
        .wp-list-table.media .manage-column.column-ID { width:35px; }
    </style>';
}