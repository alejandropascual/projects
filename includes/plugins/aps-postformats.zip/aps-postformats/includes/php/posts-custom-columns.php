<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }


//CUSTOM COLUMNS

add_filter('manage_post_posts_columns', 'aps_posts_columns_head');
add_filter('manage_post_posts_custom_column', 'aps_posts_columns_content', 10, 2);

function aps_posts_columns_head( $columns )
{
    $prev_columns = array(
        'cb' => $columns['cb'],
        'thumbnail' => ''
    );
    unset($columns['cb']);
    return array_merge($prev_columns, $columns);
}

function aps_posts_columns_content( $column, $post_id)
{
    if ($column == 'thumbnail')
    {
        if (has_post_thumbnail()){
            $post_thumbnail_id = get_post_thumbnail_id($post_id);
            if ($post_thumbnail_id)
            {
                $img_src = wp_get_attachment_image_src($post_thumbnail_id, 'thumbnail');
                $link = get_edit_post_link($post_id);
                echo '<a href="'.$link.'"><img src="'.$img_src[0].'" style="width:80px;height:auto;"></a>';
            }
        } else {
            echo 'No featured<br>Image';
        }
    }
}