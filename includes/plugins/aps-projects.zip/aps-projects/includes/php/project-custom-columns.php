<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }


//aps_project custom post
add_filter('manage_aps_project_posts_columns', 'aps_add_projects_custom_columns',10,2);
add_filter('manage_aps_project_posts_custom_column', 'aps_show_projects_custom_columns',100,3);

function aps_add_projects_custom_columns( $columns )
{
    $prev_columns = array(
        'cb' => $columns['cb'],
        'ID' => 'ID',
        'thumbnail' => ''
    );
    unset($columns['cb']);
    return array_merge($prev_columns, $columns);
}

function aps_show_projects_custom_columns( $column, $post_id)
{
    if ($column == 'ID') {
        echo $post_id;
    }
    else if ($column == 'thumbnail')
    {
        if (has_post_thumbnail()){
            $post_thumbnail_id = get_post_thumbnail_id($post_id);
            if ($post_thumbnail_id)
            {
                $img_src = wp_get_attachment_image_src($post_thumbnail_id, 'thumbnail');
                $link = get_edit_post_link($post_id);
                echo '<a href="'.$link.'"><img src="'.$img_src[0].'" style="width:80px;height:auto;"></a>';


            }
        } else {
            echo 'No featured<br>Image<br>';
        }

        $has_link       = get_post_meta($post_id, 'project_has_link',true);
        $has_gallery    = get_post_meta($post_id, 'project_has_gallery',true);
        $has_video      = get_post_meta($post_id, 'project_has_video',true);
        $has_map        = get_post_meta($post_id, 'project_has_map',true);

        $html_has_link       = '<span class="has-op fa fa-chain '.( ($has_link=='yes') ? 'has-yes':'has-no' ).'"></span>';
        $html_has_gallery    = '<span class="has-op fa fa-picture-o '.( ($has_gallery=='yes') ? 'has-yes':'has-no' ).'"></span>';
        $html_has_video      = '<span class="has-op fa fa-youtube-play '.( ($has_video=='yes') ? 'has-yes':'has-no' ).'"></span>';
        $html_has_map        = '<span class="has-op fa fa-map-marker '.( ($has_map=='yes') ? 'has-yes':'has-no' ).'"></span>';

        echo '<br>'.$html_has_link.$html_has_gallery.$html_has_video.$html_has_map;

    }
}

// FILTER PROJECTS LIST

add_action('restrict_manage_posts', 'aps_project_filter_list');
add_filter( 'parse_query','aps_project_filter_perform_query' );

function aps_project_filter_list()
{
    $screen = get_current_screen();
    global $wp_query;
    if ( $screen->post_type == 'aps_project' )
    {
        wp_dropdown_categories( array(
            'show_option_all' => 'Show All Categories',
            'taxonomy' => 'project_category',
            'name' => 'project_category',
            'orderby' => 'name',
            'selected' => ( isset( $wp_query->query['project_category'] ) ? $wp_query->query['project_category'] : '' ),
            'hierarchical' => true,
            'depth' => 3,
            'show_count' => false,
            'hide_empty' => true,
        ) );

        wp_dropdown_categories( array(
            'show_option_all' => 'Show All Skills',
            'taxonomy' => 'project_skill',
            'name' => 'project_skill',
            'orderby' => 'name',
            'selected' => ( isset( $wp_query->query['project_skill'] ) ? $wp_query->query['project_skill'] : '' ),
            'hierarchical' => true,
            'depth' => 3,
            'show_count' => false,
            'hide_empty' => true,
        ) );

        wp_dropdown_categories( array(
            'show_option_all' => 'Show All Tags',
            'taxonomy' => 'project_tag',
            'name' => 'project_tag',
            'orderby' => 'name',
            'selected' => ( isset( $wp_query->query['project_tag'] ) ? $wp_query->query['project_tag'] : '' ),
            'hierarchical' => false,
            'depth' => 3,
            'show_count' => false,
            'hide_empty' => true,
        ) );
    }
}

function aps_project_filter_perform_query( $query )
{
    $qv = &$query->query_vars;

    if ( isset( $qv['project_category'] ) && is_numeric( $qv['project_category'] ) ) {
        $term = get_term_by( 'id', $qv['project_category'], 'project_category' );
        if ($term) { $qv['project_category'] = $term->slug; }
    }

    if ( isset( $qv['project_skill'] ) && is_numeric( $qv['project_skill'] ) ) {
        $term = get_term_by( 'id', $qv['project_skill'], 'project_skill' );
        if ($term) { $qv['project_skill'] = $term->slug; }
    }

    if ( isset( $qv['project_tag'] ) && is_numeric( $qv['project_tag'] ) ) {
        $term = get_term_by( 'id', $qv['project_tag'], 'project_tag' );
        if ($term) { $qv['project_tag'] = $term->slug; }
    }

}


// STYLE
add_action('admin_head', 'aps_admin_project_custom_css');

function aps_admin_project_custom_css() {
    echo '<style type="text/css">
        .wp-list-table.posts .manage-column.column-thumbnail { width:80px; }
        .wp-list-table.posts .manage-column.column-ID { width:35px; }
        .wp-list-table.posts .column-thumbnail .has-op { display:inline-block; margin-right: 7px; }
        .wp-list-table.posts .column-thumbnail .has-op.has-yes { color:black; }
        .wp-list-table.posts .column-thumbnail .has-op.has-no { color:#dedede; }

    </style>';
}