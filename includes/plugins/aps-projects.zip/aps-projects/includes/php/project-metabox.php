<?php


// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }


// METABOXES
$boxes = array(
    array(
        'id' 		=> 'project_data',
        'title' 	=> __('PROJECT DATA',APS_PJ_LANG),
        'page' 		=> array('aps_project'),
        'context' 	=> 'normal',
        'priority'	=> 'high'
    ),
    array(
        'id' 		=> 'project_layout',
        'title' 	=> __('PROJECT LAYOUT',APS_PJ_LANG),
        'page' 		=> array('aps_project'),
        'context' 	=> 'normal',
        'priority'	=> 'high'
    ),
);



$subfields_link = array(
    array(
        'box_id'	=> 'project_data',
        'id'		=> 'project_link',
        'title'		=> __('Link',APS_PJ_LANG),
        'desc'		=> __('', APS_PJ_LANG),
        'type' 		=> 'input',
        'value'		=> '',
        'class'     => 'no-border-bottom aps-large-input',
    ),
    array(
        'box_id'	=> 'project_data',
        'id'		=> 'project_caption',
        'title'		=> __('Caption','_aps'),
        'desc'		=> __('', APS_PJ_LANG),
        'type' 		=> 'input',
        'value'		=> '',
        'class'     => 'no-border-bottom aps-large-input',
    ),
    array(
        'box_id'	=> 'project_data',
        'id'		=> 'project_target',
        'title'		=> __('Target link',APS_PJ_LANG),
        'desc'		=> __('', APS_PJ_LANG),
        'type' 		=> 'radio',
        'value'		=> '_self',
        'class'     => 'no-border-bottom',
        'options'   => array(
            '_self'=>'Open in same window',
            '_blank'=>'Open in a new window'),
    ),
);


$subfields_gallery = array(
    array(
        'box_id'    => 'project_data',
        'title'	    =>	__('Gallery images',APS_PJ_LANG),
        'desc'	    =>	__('', APS_PJ_LANG),
        'id'	    =>	'gallery_images',
        'type'	    =>	'gallery',
        'class'	    => 	'',
        'value'     =>  '',
    ),

    //Format gallery
    array(
        'box_id'    => 'project_data',
        'title'	    =>	__('Format of gallery',APS_PJ_LANG),
        'desc'	    =>	__('', APS_PJ_LANG),
        'id'	    =>	'type',
        'type'	    =>	'select',
        'class'	    => 	'',
        'value'     =>  'none',
        'required'	=> array('project_has_gallery','yes'),
        'options' => array(
            'masonry_image'                     => 'Masonry',
            'grid_image'                        => 'Grid',
            'justified_grid_image'              => 'Justified grid',
            'gallery_image'                     => 'Slider',
            'none'                              => 'None'
        ),
    ),
    array(
        'box_id'    => 'project_data',
        'title'	    =>	__('Masonry: image width in pixels',APS_PJ_LANG),
        'desc'	    =>	__('', APS_PJ_LANG),
        'id'	    =>	'masonry_width',
        'type'	    =>	'input',
        'class'	    => 	'',
        'value'     =>  '300',
        'required'	=> array('type','masonry_image')
    ),
    array(
        'box_id'    => 'project_data',
        'title'	    =>	__('Masonry: separation in pixels',APS_PJ_LANG),
        'desc'	    =>	__('', APS_PJ_LANG),
        'id'	    =>	'masonry_margin',
        'type'	    =>	'input',
        'class'	    => 	'',
        'value'     =>  '2',
        'required'	=> array('type','masonry_image')
    ),
    array(
        'box_id'    => 'project_data',
        'title'	    =>	__('Grid: number of columns',APS_PJ_LANG),
        'desc'	    =>	__('', APS_PJ_LANG),
        'id'	    =>	'grid_cols',
        'type'	    =>	'select',
        'class'	    => 	'',
        'value'     =>  '2',
        'options' => array('2'=>'2', '3'=>'3', '4'=>'4', '5'=>'5', '6'=>'6'),
        'required'	=> array('type','grid_image')
    ),
    array(
        'box_id'    => 'project_data',
        'title'	    =>	__('Grid: image width in pixels',APS_PJ_LANG),
        'desc'	    =>	__('', APS_PJ_LANG),
        'id'	    =>	'grid_width',
        'type'	    =>	'input',
        'class'	    => 	'',
        'value'     =>  '300',
        'required'	=> array('type','grid_image')
    ),
    array(
        'box_id'    => 'project_data',
        'title'	    =>	__('Grid: image separation in pixels',APS_PJ_LANG),
        'desc'	    =>	__('', APS_PJ_LANG),
        'id'	    =>	'grid_padding',
        'type'	    =>	'input',
        'class'	    => 	'',
        'value'     =>  '4',
        'required'	=> array('type','grid_image')
    ),
    array(
        'box_id'    => 'project_data',
        'title'	    =>	__('Grid: ratio image vertical/horizontal',APS_PJ_LANG),
        'desc'	    =>	__('examples: 1 (square)<br>0.5 (landscape)<br>2 (vertical)', APS_PJ_LANG),
        'id'	    =>	'grid_ratio',
        'type'	    =>	'input',
        'class'	    => 	'',
        'value'     =>  '0.75',
        'required'	=> array('type','grid_image')
    ),
    array(
        'box_id'    => 'project_data',
        'title'	    =>	__('Justified Grid: row height in pixels',APS_PJ_LANG),
        'desc'	    =>	__('', APS_PJ_LANG),
        'id'	    =>	'jgrid_height',
        'type'	    =>	'input',
        'class'	    => 	'',
        'value'     =>  '250',
        'required'	=> array('type','justified_grid_image')
    ),
    array(
        'box_id'    => 'project_data',
        'title'	    =>	__('Justified Grid: image separation in pixels',APS_PJ_LANG),
        'desc'	    =>	__('', APS_PJ_LANG),
        'id'	    =>	'jgrid_padding',
        'type'	    =>	'input',
        'class'	    => 	'',
        'value'     =>  '0',
        'required'	=> array('type','justified_grid_image')
    ),
    array(
        'box_id'    => 'project_data',
        'title'	    =>	__('Slider: image width in pixels',APS_PJ_LANG),
        'desc'	    =>	__('', APS_PJ_LANG),
        'id'	    =>	'gallery_width',
        'type'	    =>	'input',
        'class'	    => 	'',
        'value'     =>  '800',
        'required'	=>  array('type','gallery_image')
    ),
    array(
        'box_id'    => 'project_data',
        'title'	    =>	__('Slider: image height in pixels',APS_PJ_LANG),
        'desc'	    =>	__('', APS_PJ_LANG),
        'id'	    =>	'gallery_height',
        'type'	    =>	'input',
        'class'	    => 	'',
        'value'     =>  '500',
        'required'	=>  array('type','gallery_image')
    ),
    array(
        'box_id'    => 'project_data',
        'title'	    =>	__('Slider: image mode',APS_PJ_LANG),
        'desc'	    =>	__('', APS_PJ_LANG),
        'id'	    =>	'gallery_mode',
        'type'	    =>	'select',
        'class'	    => 	'',
        'value'     =>  'fill',
        'required'	=>  array('type','gallery_image'),
        'options'   =>  array(
            'fill'  => 'Fill: image will expand to fill the slider container',
            'fit'   => 'Fit: image will fit inside the slider container'
        )
    ),
);



$subfields_video = array(

    array(
        'box_id'	=> 'project_data',
        'title'		=> __('Aspect Ratio',APS_PJ_LANG),
        'desc'		=> __('Select the aspect ratio of your video', APS_PJ_LANG),
        'id'		=> 'project_video_ratio',
        'type' 		=> 'select',
        'class'		=> '',
        'value'		=> '16_9',
        'options'	=>  array(
            'video-16_9' => '16 : 9',
            'video-5_3' => '5 : 3',
            'video-5_4' => '5 : 4',
            'video-4_3' => '4 : 3',
            'video-3_2' => '3 : 2'
        ),
    ),
    array(
        'box_id'	=> 'project_data',
        'title'		=> __('Skin color',APS_PJ_LANG),
        'desc'		=> __('', APS_PJ_LANG),
        'id'		=> 'project_video_skin',
        'type' 		=> 'select',
        'class'		=> '',
        'value'		=> 'black',
        'options'	=>  array(
            'black'=> 'Black',
            'gray'	=> 'Gray',
            'white' => 'White'
        ),
    ),
    array(
        'box_id'	=> 'project_data',
        'title'		=> __('Autoplay',APS_PJ_LANG),
        'desc'		=> __('', APS_PJ_LANG),
        'id'		=> 'project_video_autoplay',
        'type' 		=> 'select',
        'class'		=> '',
        'value'		=> 'no',
        'options'	=>  array(
            'yes'=> 'yes',
            'no'	=> 'no'
        ),
    ),
    array(
        'box_id'=> 'project_data',
        'title'	=>	__('URL M4V File',APS_PJ_LANG),
        'desc'	=>	__('The URL to the .m4v file', APS_PJ_LANG),
        'id'	=>	'project_video_m4v',
        'type'	=>	'input',
        'class'	=> 	'widefat',
        'value' =>  '',
    ),
    array(
        'box_id'=> 'project_data',
        'title'	=>	__('URL OGV File',APS_PJ_LANG),
        'desc'	=>	__('The URL to the .ogv file', APS_PJ_LANG),
        'id'	=>	'project_video_ogv',
        'type'	=>	'input',
        'class'	=> 	'widefat',
        'value' =>  '',
    ),
    array(
        'box_id'=> 'project_data',
        'title'	=>	__('URL WEBM File',APS_PJ_LANG),
        'desc'	=>	__('The URL to the .webm file', APS_PJ_LANG),
        'id'	=>	'project_video_webm',
        'type'	=>	'input',
        'class'	=> 	'widefat',
        'value' =>  '',
    ),
    array(
        'box_id'=> 'project_data',
        'title'	=>	__('Poster Image',APS_PJ_LANG),
        'desc'	=>	__('The URL to the image', APS_PJ_LANG),
        'id'	=>	'project_video_use_poster',
        'type'	=>	'select',
        'class'	=> 	'',
        'value' =>  'featured',
        'options' => array(
            'featured'  => 'Use featured image as poster',
            'image'     => 'Use other image as poster'
        )
    ),
    array(
        'box_id'=> 'project_data',
        'title'	=>	__('Poster Image',APS_PJ_LANG),
        'desc'	=>	__('The URL to the image', APS_PJ_LANG),
        'id'	=>	'project_video_poster',
        'type'	=>	'input',
        'class'	=> 	'widefat',
        'value' =>  '',
        'required' => array('project_video_use_poster','image'),

    ),
);



$subfields_map = array(
    array(
        'box_id'=> 'project_data',
        'title'	=>	__('Map',APS_PJ_LANG),
        'desc'	=>	__('', APS_PJ_LANG),
        'id'	=>	'project_map',
        'type'	=>	'map',
        'value' => '',
    ),
    array(
        'box_id'=> 'project_data',
        'title'	=>	__('Geolocation',APS_PJ_LANG),
        'desc'	=>	__('', APS_PJ_LANG),
        'id'	=>	'project_coord',
        'class' => 'coordenadas aps-large-input no-border-bottom',
        'type'	=>	'input',
        'value' => '',
    ),
    array(
        'box_id'=> 'project_data',
        'title'	=>	__('Address',APS_PJ_LANG),
        'desc'	=>	__('', APS_PJ_LANG),
        'id'	=>	'project_address',
        'class' => 'direccion aps-large-input no-border-bottom',
        'type'	=>	'input',
        'value' => '',
    ),
    array(
        'box_id'=> 'project_data',
        'title'	=>	__('Zoom',APS_PJ_LANG),
        'desc'	=>	__('', APS_PJ_LANG),
        'id'	=>	'project_zoom',
        'class' => 'zoom aps-large-input no-border-bottom',
        'type'	=>	'input',
        'value' => '',
    ),
);





//LOs campos agrupados

$fields = array(
    //link
    array(
        'box_id'	=> 'project_data',
        'id'		=> 'project_has_link',
        'title'		=> __('Has external link ?',APS_PJ_LANG),
        'desc'		=> __('', APS_PJ_LANG),
        'type' 		=> 'yes_no',
        'value'		=> 'no',

    ),
    array(
        'box_id'	=> 'project_data',
        'title' => __('', APS_PJ_LANG),
        'desc'  => __('', APS_PJ_LANG),
        'id'    => 'subfields',
        'type'  => 'subfields',
        'required' => array('project_has_link','yes'),
        'subfields' => $subfields_link,
    ),

    //Division
    array(
        'box_id'	=> 'project_data',
        'id'		=> 'division',
        'title'		=> __('', APS_PJ_LANG),
        'desc'		=> __('', APS_PJ_LANG),
        'type' 		=> 'division',
    ),

    //Gallery
    array(
        'box_id'	=> 'project_data',
        'id'		=> 'project_has_gallery',
        'title'		=> __('Has gallery ?',APS_PJ_LANG),
        'desc'		=> __('', APS_PJ_LANG),
        'type' 		=> 'yes_no',
        'value'		=> 'no',
    ),
    array(
        'box_id'	=> 'project_data',
        'title' => __('', APS_PJ_LANG),
        'desc'  => __('', APS_PJ_LANG),
        'id'    => 'subfields',
        'type'  => 'subfields',
        'required' => array('project_has_gallery','yes'),
        'subfields' => $subfields_gallery,
    ),

    //Division
    array(
        'box_id'	=> 'project_data',
        'id'		=> 'division',
        'title'		=> __('', APS_PJ_LANG),
        'desc'		=> __('', APS_PJ_LANG),
        'type' 		=> 'division',
    ),

    //Video
    array(
        'box_id'	=> 'project_data',
        'id'		=> 'project_has_video',
        'title'		=> __('Has video ?',APS_PJ_LANG),
        'desc'		=> __('', APS_PJ_LANG),
        'type' 		=> 'yes_no',
        'value'		=> 'no',
    ),
    array(
        'box_id'	=> 'project_data',
        'title' => __('', APS_PJ_LANG),
        'desc'  => __('', APS_PJ_LANG),
        'id'    => 'subfields',
        'type'  => 'subfields',
        'required' => array('project_has_video','yes'),
        'subfields' => $subfields_video,
    ),

    //Division
    array(
        'box_id'	=> 'project_data',
        'id'		=> 'division',
        'title'		=> __('', APS_PJ_LANG),
        'desc'		=> __('', APS_PJ_LANG),
        'type' 		=> 'division',
    ),


    //MAP
    array(
        'box_id'=> 'project_data',
        'title'	=>	__('Has map?',APS_PJ_LANG),
        'desc'	=>	__('', APS_PJ_LANG),
        'id'	=>	'project_has_map',
        'type'	=>	'yes_no',
        'value' => 'no',
    ),
    array(
        'box_id'	=> 'project_data',
        'title' => __('', APS_PJ_LANG),
        'desc'  => __('', APS_PJ_LANG),
        'id'    => 'subfields',
        'type'  => 'subfields',
        'required' => array('project_has_map','yes'),
        'subfields' => $subfields_map,
    ),




    //Content layout
    array(
        'box_id'=> 'project_layout',
        'title'	=>	__('Layout type',APS_PJ_LANG),
        'desc'	=>	__('', APS_PJ_LANG),
        'id'	=>	'project_layout_type',
        'type'	=>	'radio_image',
        'class'	=> 	'max-90',
        'value' =>  '1',
        'options' => array(
            'lay_1' => '1',
            'lay_2' => '2',
            'lay_3' => '3',
            'lay_4' => '4',
            'lay_5' => '5',
            'lay_6' => '6',
            'lay_7' => '7',
            'lay_8' => '8',
        ),
        'images' => array(
            APS_PROJECTS_URL.'/includes/images/lay_1.png',
            APS_PROJECTS_URL.'/includes/images/lay_2.png',
            APS_PROJECTS_URL.'/includes/images/lay_3.png',
            APS_PROJECTS_URL.'/includes/images/lay_4.png',
            APS_PROJECTS_URL.'/includes/images/lay_5.png',
            APS_PROJECTS_URL.'/includes/images/lay_6.png',
            APS_PROJECTS_URL.'/includes/images/lay_7.png',
            APS_PROJECTS_URL.'/includes/images/lay_8.png'
        )
    ),


    array(
        'box_id'=> 'project_layout',
        'title'	=>	__('Show skills',APS_PJ_LANG),
        'desc'	=>	__('', APS_PJ_LANG),
        'id'	=>	'project_show_skills',
        'type'	=>	'yes_no',
        'class'	=> 	'',
        'value' =>  'yes',
    ),
    array(
        'box_id'=> 'project_layout',
        'title'	=>	__('Show categories',APS_PJ_LANG),
        'desc'	=>	__('', APS_PJ_LANG),
        'id'	=>	'project_show_categories',
        'type'	=>	'yes_no',
        'class'	=> 	'',
        'value' =>  'yes',
    ),
    array(
        'box_id'=> 'project_layout',
        'title'	=>	__('Show tags',APS_PJ_LANG),
        'desc'	=>	__('', APS_PJ_LANG),
        'id'	=>	'project_show_tags',
        'type'	=>	'yes_no',
        'class'	=> 	'',
        'value' =>  'yes',
    ),
    array(
        'box_id'=> 'project_layout',
        'title'	=>	__('Show social buttons',APS_PJ_LANG),
        'desc'	=>	__('', APS_PJ_LANG),
        'id'	=>	'project_show_social',
        'type'	=>	'yes_no',
        'class'	=> 	'',
        'value' =>  'yes',
    ),

    array(
        'box_id'=> 'project_layout',
        'title'	=>	__('Show related projects',APS_PJ_LANG),
        'desc'	=>	__('', APS_PJ_LANG),
        'id'	=>	'project_show_related',
        'type'	=>	'yes_no',
        'class'	=> 	'',
        'value' =>  'yes',
    ),
    /*array(
        'box_id'=> 'project_layout',
        'title'	=>	__('Show related projects of the same category',APS_PJ_LANG),
        'desc'	=>	__('', APS_PJ_LANG),
        'id'	=>	'project_related_type',
        'type'	=>	'select',
        'class'	=> 	'',
        'value' =>  'thumbnail::photo-slider',
        'options' => array(
            'portfolio-big::photo-slider'       => 'Image Large',
            'related-post::photo-slider'        => 'Image Medium',
            'thumbnail::photo-slider'           => 'Image Small',
            'portfolio-big::image-slider'       => 'Image Large - Top title',
            'related-post::image-slider'        => 'Image Medium - Top title',
            'thumbnail::image-slider'           => 'Image Small - Top title',
            'portfolio-big::featured-slider'    => 'Image Large - Bottom title + description',
            'related-post::featured-slider'     => 'Image Medium - Bottom title + description',
            'thumbnail::featured-slider'        => 'Image Small - Bottom title + description',
        ),
        'required'	=> array('project_show_related','yes')
    ),*/
    array(
        'box_id'=> 'project_layout',
        'id'		=> 'project_related_filter',
        'title'		=> __('Filter related projects with', APS_PJ_LANG),
        'desc'		=> __('', APS_PJ_LANG),
        'class'		=> '',
        'type' 		=> 'select',
        'options'	=> array(
            'categories'    => 'Same categories',
            'skills'        => 'Same skills',
            'tags'          => 'Same tags',
            'all'   => 'Same categories, tags and skills',
        ),
        'required'	=> array('project_show_related','yes')
    ),

    array(
        'box_id'=> 'project_layout',
        'id'		=> 'project_related_type',
        'title'		=> __('Type of carousel', APS_PJ_LANG),
        'desc'		=> __('', APS_PJ_LANG),
        'class'		=> '',
        'type' 		=> 'select',
        'options' => array(
            'photo-slider'      => 'Only images',
            'image-slider'      => 'Images with top title',
            'featured-slider'   => 'Images with bottom title and excerpt',
        ),
        'required'	=> array('project_show_related','yes')
    ),
    array(
        'box_id'=> 'project_layout',
        'id'		=> 'project_related_size',
        'title'		=> __('Image size for carousel', APS_PJ_LANG),
        'desc'		=> __('', APS_PJ_LANG),
        'class'		=> '',
        'type' 		=> 'select',
        'options' => array(
            'large'       => 'Large image',
            'medium'      => 'Medium image',
            'thumbnail'   => 'Small square image',
            'thumbnail-v' => 'Small vertical image'
        ),
        'required'	=> array('project_show_related','yes')
    ),
    array(
        'box_id'=> 'project_layout',
        'title'	=>	__('Number of related projects',APS_PJ_LANG),
        'desc'	=>	__('Input number of posts or -1 for all', APS_PJ_LANG),
        'id'	=>	'project_related_limit',
        'type'	=>	'input',
        'value' => '10',
        'required'	=> array('project_show_related','yes')
    ),
    array(
        'box_id'=> 'project_layout',
        'title'	=>	__('Order By',APS_PJ_LANG),
        'desc'	=>	__('', APS_PJ_LANG),
        'id'	=>	'project_related_orderby',
        'type'	=>	'select',
        'value' => 'date',
        'options' => array(
            'none'          => 'None',
            'title'         => __('Title', APS_PJ_LANG),
            'author'        => 'Author',
            'date'          => 'Date',
            'comment_count' => 'Popularity',
            'rand'          => 'Random'
        ),
        'required'	=> array('project_show_related','yes')
    ),
    array(
        'box_id'=> 'project_layout',
        'title'	=>	__('Order of projects',APS_PJ_LANG),
        'desc'	=>	__('', APS_PJ_LANG),
        'id'	=>	'project_related_order',
        'type'	=>	'select',
        'value' => 'date',
        'options' => array(
            'ASC' => 'Ascending',
            'DESC' => __('Descending', APS_PJ_LANG)
        ),
        'required'	=> array('project_show_related','yes')
    ),

);
