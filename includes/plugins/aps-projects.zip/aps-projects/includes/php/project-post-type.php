<?php

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

/////////////////////////////////////
// Register post types
/////////////////////////////////////


if ( ! function_exists( 'aps_register_post_type_project' ) ) :
    function aps_register_post_type_project()
    {
        // POST TYPE: page_content

        register_post_type(
            'aps_project',
            array(
                'labels' => array(
                    'name' => 'Project',
                    'singular_name' => 'Project'
                ),
                'public' => true,
                'has_archive' => true,
                'menu_position'  => 19,
                'rewrite' => array('slug' => 'project'),
                'supports' => array('title', 'editor', 'excerpt', 'author', 'thumbnail','revisions','comments'),
                'can_export' => true,
            )
        );


        register_taxonomy('project_category', 'aps_project',
            array(
                //'public' => true,
                'hierarchical' => true,
                'label' => 'Categories',
                'show_ui' => true,
                'show_admin_column' => true,
                'query_var' => true,
                'rewrite' => true)
        );
        register_taxonomy('project_skill', 'aps_project',
            array(
                'hierarchical' => true,
                'label' => 'Skills',
                'show_ui' => true,
                'show_admin_column' => true,
                'query_var' => true,
                'rewrite' => true)
        );
        register_taxonomy('project_tag', 'aps_project',
            array(
                'hierarchical' => false,
                'label' => 'Tags',
                'show_ui' => true,
                'show_admin_column' => true,
                'query_var' => true,
                'rewrite' => true)
        );

    }
endif;

add_action('init', 'aps_register_post_type_project');