<?php
/*
Plugin Name: ELAP - Projects
Plugin URL: http://elapsl.com
Description: Projects custom post for PROJECTS theme.
Version: 1.0.0
Author: ELAP
Author URI: http://elapsl.com
*/



// =============================================================================
//	Constants
// =============================================================================


if ( !defined( 'APS_PROJECTS_URL' ) ) {
    define( 'APS_PROJECTS_URL', plugins_url( '', __FILE__ ) );
}

if ( !defined( 'APS_PROJECTS_DIR' ) ) {
    define( 'APS_PROJECTS_DIR', plugin_dir_path(__FILE__) );
}

if ( !defined( 'APS_PROJECTS_DIR_URI' ) ) {
    define( 'APS_PROJECTS_DIR_URI', plugin_dir_url(__FILE__) );
}

// =============================================================================
//	Locale
// =============================================================================

define( 'APS_PJ_LANG' , 'aps_projects');

function aps_projects_load_lang() {
    load_plugin_textdomain('aps_projects', false, basename(dirname(__FILE__)) . '/languages/' );
}

add_action('plugins_loaded', 'aps_projects_load_lang');

// =============================================================================
//	Require files
// =============================================================================


// CLASSES
require( 'includes/php/class-htmlhelper.php' );
require( 'includes/php/class-metabox.php' );


// POST TYPE PROJECT
require( 'includes/php/project-ajax.php' );
require( 'includes/php/project-post-type.php' );
require( 'includes/php/project-custom-columns.php' );
new APSMetaBox( APS_PROJECTS_DIR.'/includes/php/project-metabox.php' );


function aps_projects_rewrite_flush() {
    aps_register_post_type_project();
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'aps_projects_rewrite_flush' );

